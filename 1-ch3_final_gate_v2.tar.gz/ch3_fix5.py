import bpy, math
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
from mathutils import Matrix
p=bpy.data.objects['frame1_scr']
root=bpy.data.objects['frame1']
# rigid ride like the bezel bars: parent-inverse = identity, local = offset from root origin
# root rest pose: (0.24, 0, 0.069) rot 0; desired plane rest world: (0.24, -0.0027, 0.069) rot (90deg,0,0)
p.parent=root
p.matrix_parent_inverse=Matrix.Identity(4)
p.location=(0.0,-0.0027,0.0)
p.rotation_euler=(math.pi/2,0,0)
# no independent animation on the plane
if p.animation_data: p.animation_data_clear()
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("FIX5 DONE")
