import bpy, math
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
p=bpy.data.objects['frame1_scr']
# bezel1 renders at x=0.26 (fix1 trio-tightening stuck for bars, not roots)
# plane must ride root1 with +0.02 local x so it sits inside bezel1 at every frame
p.location=(0.02,-0.0027,0.0)
p.rotation_euler=(math.pi/2,0,0)
if p.animation_data: p.animation_data_clear()
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("FIX6 DONE")
