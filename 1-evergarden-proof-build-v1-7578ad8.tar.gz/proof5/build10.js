/* v17: reservation lock -> travel down-counter -> footer lock (end of the counter).
   v16 lineage below; the reservation card + exp/gallery pages stay seated as continuity.
   Footer DOM truth (pixels from dom-footer.png): ink rgb(6,6,6); brand logo y295-332 right edge 726;
   brandP stone baselines ~430/~482 right 729; h4 gold Inter 22px baselines nav 584 / hours 1099 / contact 1464;
   nav links stone baselines 678/756/834/912/990 right 729; hours rows baselines 1186/1264/1342 (day cream right, time stone LEFT ltr);
   contact rows ~1614/1693/1771 (phone row OMITTED per no-phone gate; email+map ltr left, address right).
   One warm stone counter world; the reservation section is a cream paper card
   seated flush in a brass field; the toast-board photo sets down as a print;
   form rows reveal with the DOM's own delays; camera never leaves the counter.
   DOM truth (390x844 css, section top at y144.6 video under nav):
   page bg cream rgb(245,240,235); photo y199.4-784.4 full width + to-right ink .4 gradient;
   label 'שמרו מקום' y896.4 h37 moss #4a5240 Inter 22px ls 6.1px right edge 732 + line;
   title 'הזמינו שולחן' Cormorant 76.8 ink, em moss italic, baseline ~1062, right edge 732;
   body 2 lines Inter 27.2 stone #9e9188 baselines ~1195/1247;
   rows (label Inter 22.4 stone ls ~4; input Inter 28.8; underline rgba(10,10,10,.2) 2px):
   name lab 717.4 inp 743.6 h40.4 | phone 800/826.2 | date 887.4/913.6 h42.4 (mm/dd/yyyy + cal icon right)
   time 972/998.2 h39.4 select chevron left | guests 1058.4/1084.6 | type 1140/1166.2
   notes 1226.4/1252.6 | submit y1321.8 h46 gold #c9a96e ink text 24px Arial ls 4.8px centered */
import * as THREE from './vendor/three.module.js';

const CREAM = '#f5f0eb', GOLD = '#c9a96e', STONE = '#9e9188', MOSS = '#4a5240', INK = '#0a0a0a';
const FOV = 54, D_FINAL = 2.07;

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.0;
document.getElementById('stage').appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b0908);
const camera = new THREE.PerspectiveCamera(FOV, innerWidth / innerHeight, .05, 60);

scene.add(new THREE.AmbientLight(0x2a2118, .55));

const counter = new THREE.Mesh(
  new THREE.BoxGeometry(26, .12, 3.4),
  new THREE.MeshStandardMaterial({ color: 0x8a7663, roughness: .38, metalness: .08 }));
counter.position.set(5, -.06, 0); counter.receiveShadow = true; scene.add(counter);

const surround = new THREE.Mesh(new THREE.PlaneGeometry(80, 80),
  new THREE.MeshStandardMaterial({ color: 0x0b0908, roughness: 1 }));
surround.rotation.x = -Math.PI / 2; surround.position.y = -.125; scene.add(surround);

/* ---------- helpers ---------- */
function ctex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}
function drawSpaced(g, text, cx, cy, spacing) {
  const ch = [...text];
  const ws = ch.map(c => g.measureText(c).width);
  const total = ws.reduce((a, b) => a + b, 0) + spacing * (ch.length - 1);
  let x = cx + total / 2;
  const prevAlign = g.textAlign;
  g.textAlign = 'right';
  for (let i = 0; i < ch.length; i++) { g.fillText(ch[i], x, cy); x -= ws[i] + spacing; }
  g.textAlign = prevAlign;
}
function fitSpaced(g, text, rightX, cy, targetW) {
  const w0 = g.measureText(text).width;
  const n = [...text].length - 1;
  drawSpaced(g, text, rightX - targetW / 2, cy, Math.max(0, (targetW - w0) / n));
}
const clamp01 = t => Math.min(1, Math.max(0, t));
const easeOutCubic = t => 1 - Math.pow(1 - t, 3);
const easeInOutQ = t => t * t * (3 - 2 * t);
const dip = t => Math.sin(Math.PI * clamp01(t)) * -.012;
function loadImg(src) { return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = src; }); }

async function loadFonts() {
  await Promise.all([
    document.fonts.load("300 77px 'Cormorant Garamond'", 'חוויה'),
    document.fonts.load("italic 300 77px 'Cormorant Garamond'", 'לפני'),
    document.fonts.load("300 29px 'Inter'", 'דגים'),
    document.fonts.load("400 22px 'Inter'", 'גלריה'),
    document.fonts.load("400 54px 'Cormorant Garamond'", 'סושימי'),
    document.fonts.load("300 77px 'Cormorant Garamond'", 'הזמינו'),
    document.fonts.load("italic 300 77px 'Cormorant Garamond'", 'שולחן'),
    document.fonts.load("300 28px 'Inter'", 'מספר מקומות'),
    document.fonts.load("500 24px 'Arial'", 'אשרו'),
  ]);
  await document.fonts.ready;
}

/* ---------- glow sprites ---------- */
const glows = [];
function glowTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d');
  const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, 'rgba(255,214,150,.9)'); gr.addColorStop(.4, 'rgba(255,190,110,.32)'); gr.addColorStop(1, 'rgba(255,190,110,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
let glowTex = null;

function pendant(x, z, drop, glowS, intensity) {
  const g = new THREE.Group();
  const ceilY = 3.6;
  const cord = new THREE.Mesh(new THREE.CylinderGeometry(.006, .006, drop, 6),
    new THREE.MeshStandardMaterial({ color: 0x1a1512, roughness: .8 }));
  cord.position.set(0, ceilY - drop / 2, 0); g.add(cord);
  const shade = new THREE.Mesh(new THREE.ConeGeometry(.16, .14, 24, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x14100d, roughness: .6, metalness: .4, side: THREE.DoubleSide }));
  shade.position.set(0, ceilY - drop, 0); shade.castShadow = true; g.add(shade);
  const bulbY = ceilY - drop - .05;
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(.028, 12, 12),
    new THREE.MeshBasicMaterial({ color: 0xffd9a0 }));
  bulb.position.set(0, bulbY, 0); g.add(bulb);
  const pt = new THREE.PointLight(0xffc98a, intensity, 9, 2);
  pt.position.set(0, bulbY - .02, 0); pt.castShadow = true;
  pt.shadow.mapSize.set(512, 512); pt.shadow.bias = -.004;
  g.add(pt);
  if (!glowTex) glowTex = glowTexture();
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, transparent: true, opacity: .35, depthWrite: false, blending: THREE.AdditiveBlending }));
  spr.scale.set(glowS, glowS, 1); spr.position.set(0, bulbY, 0); g.add(spr);
  glows.push({ glow: spr, base: .35 });
  g.position.set(x, 0, z); scene.add(g);
}
pendant(-.6, -.7, 3.6, 1.8, 8);
pendant(2.3, -.7, 3.7, 1.3, 5.3);
pendant(2.55, 1.35, 2.4, .7, 8.8);
pendant(4.3, -.7, 3.7, 1.3, 5.3);
pendant(4.55, 1.35, 2.4, .7, 8.8);
pendant(7.7, -.7, 3.7, 1.3, 5.3);
pendant(8.2, 1.35, 2.4, .7, 8.8);
pendant(11.9, -.7, 3.7, 1.3, 5.3);   /* over the reservation card */
pendant(12.35, 1.35, 2.4, .7, 8.8); /* front strip by the reservation card */
pendant(15.2, -.7, 3.7, 1.3, 5.3);   /* over the footer card */
pendant(15.65, 1.35, 2.4, .7, 8.8); /* front strip by the footer card */

/* ---------- brass inlay fields ---------- */
const brass = new THREE.MeshStandardMaterial({ color: 0x9a7b4f, roughness: .3, metalness: .85 });
function brassRim(cx, lenX, widZ) {
  for (const [ox, oz, w, d] of [[0, widZ / 2 + .006, lenX + .024, .012], [0, -widZ / 2 - .006, lenX + .024, .012],
                                [lenX / 2 + .006, 0, .012, widZ + .024], [-lenX / 2 - .006, 0, .012, widZ + .024]]) {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(w, .005, d), brass);
    strip.position.set(cx + ox, .004, oz); strip.castShadow = true; scene.add(strip);
  }
}
brassRim(4.5, 2.13, .995);
brassRim(7.9595, 4.573, .995);
brassRim(12.109, 3.502, .995);   /* reservation field */
brassRim(15.36, 2.777, .995);    /* footer field */

/* ---------- page panels ---------- */
function panel(lenX, widZ, tex, texRot) {
  const geo = new THREE.BoxGeometry(lenX, .03, widZ);
  const side = new THREE.MeshStandardMaterial({ color: 0x14100d, roughness: .55, metalness: .2 });
  const face = new THREE.MeshBasicMaterial({ map: tex });
  const m = new THREE.Mesh(geo, [side, side, face, side, side, side]);
  if (texRot) { m.material[2].map.rotation = texRot; m.material[2].map.center.set(.5, .5); }
  m.castShadow = true; m.receiveShadow = true;
  scene.add(m);
  return m;
}

const parts = [];
function addPart(grp, win, from) { parts.push({ grp, win, from, to: grp.position.clone() }); }

/* ---------- the experience page (seated - continuity) ---------- */
const ROWY = [647.9, 788.1, 928.3, 1068.4];
const EXPROWS = [
  { icon: 'fish', lines: ['דגים מגיעים ישירות מהים בכל בוקר – ללא', 'מתווכים, ללא מלאי עודף.'] },
  { icon: 'knife', lines: ['חיתוך יד בלבד. כל פרוסה בזווית מדויקת של', '45° להגדלת שטח הפנים ועוצמת הטעם.'] },
  { icon: 'jar', lines: ['אורז מוכן פעמיים ביום. טמפרטורת גוף.', 'ולא פעם יותר מזה.'] },
  { icon: 'sticks', lines: ['שירות שקט. אף אחד לא ירוץ לשולחן שלך.', 'אנחנו פה, לא מעל.'] },
];
const ICONPATHS = {
  fish: ['M3.5 12c3-4.5 7-6.5 10.5-6.5 3 0 5.5 2.5 6.5 6.5-1 4-3.5 6.5-6.5 6.5-3.5 0-7.5-2-10.5-6.5z', 'M3.5 12l-2-3.5M3.5 12l-2 3.5'],
  knife: ['M3 21l8.5-8.5', 'M11 13.5C13 10 17 5.5 21.5 3c.5 4.5-3 8.5-7.5 10.5l-3 0z'],
  jar: ['M7 8h10v3.5c1 .8 1.5 2 1.5 3.5v4.5c0 1-1 2-2.5 2H8c-1.5 0-2.5-1-2.5-2V15c0-1.5.5-2.7 1.5-3.5V8z', 'M6.5 5.5h11V8h-11z', 'M8.5 14.5c2-1 5-1 7 0'],
  sticks: ['M5 3.5L19 20', 'M9.5 3L20.5 16.5'],
};
const ICONDOTS = { fish: [16.5, 10.5], knife: [5.5, 18.5] };
function drawIcon(g, name, cx, cy, size) {
  const s = size / 24;
  g.save(); g.translate(cx - 12 * s, cy - 12 * s); g.scale(s, s);
  g.strokeStyle = 'rgba(245,240,235,.8)'; g.lineWidth = 1.5; g.lineCap = 'round'; g.lineJoin = 'round';
  for (const d of ICONPATHS[name]) { const p = new Path2D(d); g.stroke(p); }
  if (ICONDOTS[name]) { g.fillStyle = 'rgba(245,240,235,.8)'; const p = new Path2D(); p.arc(ICONDOTS[name][0], ICONDOTS[name][1], .8, 0, 7); g.fill(p); }
  g.restore();
}

let expCanvas, expCtx, expTex, expImgEl = null;
function drawExp() {
  const g = expCtx, w = 780;
  g.globalAlpha = 1; g.setTransform(1, 0, 0, 1, 0, 0);
  g.fillStyle = 'rgb(18,19,17)'; g.fillRect(0, 0, w, 144);
  g.fillStyle = 'rgba(201,169,110,.12)'; g.fillRect(0, 143, w, 2);
  g.strokeStyle = CREAM; g.lineWidth = 2.5; g.lineCap = 'round';
  for (let i = 0; i < 3; i++) { const y = 60 + i * 10; g.beginPath(); g.moveTo(56, y); g.lineTo(107, y); g.stroke(); }
  g.fillStyle = GOLD; g.font = "400 54px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  fitSpaced(g, 'סושימי', 726, 87, 153);
  g.fillStyle = MOSS; g.fillRect(0, 145, w, 1256.6 - 145);
  g.fillStyle = 'rgba(245,240,235,.6)'; g.font = "400 22px 'Inter', system-ui, sans-serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  drawSpaced(g, 'למה סושימי', 644, 267, 6.2);
  g.strokeStyle = 'rgba(245,240,235,.3)'; g.lineWidth = 2; g.beginPath(); g.moveTo(508, 259); g.lineTo(584, 259); g.stroke();
  if (expImgEl) {
    const s2 = Math.max(780 / expImgEl.width, 624 / expImgEl.height);
    const dw = expImgEl.width * s2, dh = expImgEl.height * s2;
    g.save(); g.beginPath(); g.rect(0, 1256.6, 780, 1688 - 1256.6); g.clip();
    g.drawImage(expImgEl, (780 - dw) / 2, 1256.6 + (624 - dh) / 2, dw, dh);
    const gr = g.createLinearGradient(0, 1256.6, 780, 1688);
    gr.addColorStop(0, 'rgba(10,10,10,.2)'); gr.addColorStop(1, 'rgba(10,10,10,0)');
    g.fillStyle = gr; g.fillRect(0, 1256.6, 780, 1688 - 1256.6);
    g.restore();
  }
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = CREAM; g.font = "300 77px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('חוויה שמתחילה', 732, 408);
  g.fillStyle = GOLD; g.font = "italic 300 77px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('לפני הביס הראשון', 732, 492);
  for (let i = 0; i < 4; i++) {
    const y0 = ROWY[i];
    g.textAlign = 'right'; g.textBaseline = 'alphabetic';
    g.fillStyle = 'rgba(245,240,235,.8)'; g.font = "300 29px 'Inter', system-ui, sans-serif";
    g.fillText(EXPROWS[i].lines[0], 622, y0 + 34);
    g.fillText(EXPROWS[i].lines[1], 622, y0 + 80);
    g.strokeStyle = 'rgba(201,169,110,.4)'; g.lineWidth = 2; g.strokeRect(661, y0 + 4, 70, 70);
    drawIcon(g, EXPROWS[i].icon, 696, y0 + 39, 33);
  }
}

/* ---------- the gallery page (seated - continuity) ---------- */
let galCanvas, galCtx, galTex, galImgs = null;
const GALITEMS = [
  { x: 48, y: 675.7, w: 684, h: 456 },
  { x: 48, y: 1170.3, w: 684, h: 1026 },
  { x: 48, y: 2234.7, w: 684, h: 456 },
  { x: 48, y: 2729.1, w: 684, h: 400 },
  { x: 48, y: 3167.5, w: 684, h: 456 },
];
function drawGal() {
  const g = galCtx, w = 780;
  g.globalAlpha = 1; g.setTransform(1, 0, 0, 1, 0, 0);
  g.fillStyle = 'rgb(10,10,10)'; g.fillRect(0, 0, w, 3639);
  g.fillStyle = 'rgba(201,169,110,.12)'; g.fillRect(0, 143, w, 2);
  g.strokeStyle = CREAM; g.lineWidth = 2.5; g.lineCap = 'round';
  for (let i = 0; i < 3; i++) { const y = 60 + i * 10; g.beginPath(); g.moveTo(56, y); g.lineTo(107, y); g.stroke(); }
  g.fillStyle = GOLD; g.font = "400 54px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  fitSpaced(g, 'סושימי', 726, 87, 153);
  g.fillStyle = GOLD; g.font = "400 22px 'Inter', system-ui, sans-serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  drawSpaced(g, 'גלריה', 687, 329, 6.2);
  g.strokeStyle = GOLD; g.lineWidth = 2; g.beginPath(); g.moveTo(540, 321); g.lineTo(616, 321); g.stroke();
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = CREAM; g.font = "300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('ב', 732, 472);
  const wBet = g.measureText('ב').width;
  g.fillStyle = GOLD; g.font = "italic 300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('תוך', 732 - wBet, 472);
  const wTok = g.measureText('תוך').width;
  g.fillStyle = CREAM; g.font = "300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.letterSpacing = '3px'; g.fillText(' סושימי', 732 - wBet - wTok, 472); g.letterSpacing = '0px';
}

/* ---------- the reservation card (cream paper, 780x2792) ---------- */
let resCanvas, resCtx, resTex;
const RES_H = 2792;
function drawNavBand(g, w) {
  g.fillStyle = 'rgb(18,19,17)'; g.fillRect(0, 0, w, 144);
  g.fillStyle = 'rgba(201,169,110,.12)'; g.fillRect(0, 143, w, 2);
  g.strokeStyle = CREAM; g.lineWidth = 2.5; g.lineCap = 'round';
  for (let i = 0; i < 3; i++) { const y = 60 + i * 10; g.beginPath(); g.moveTo(56, y); g.lineTo(107, y); g.stroke(); }
  g.fillStyle = GOLD; g.font = "400 54px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  fitSpaced(g, 'סושימי', 726, 87, 153);
}
function field(g, st, label, labBase, input, ulY, chevron) {
  /* one form group: label + underline + input content, revealed together */
  if (st <= 0) return;
  g.save();
  g.globalAlpha = st; g.translate(0, (1 - st) * 48);
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = STONE; g.font = "300 22.4px 'Inter', system-ui, sans-serif";
  fitSpaced(g, label, 726, labBase, g.measureText(label).width + 4 * ([...label].length - 1));
  g.strokeStyle = 'rgba(10,10,10,.2)'; g.lineWidth = 2;
  g.beginPath(); g.moveTo(48, ulY); g.lineTo(732, ulY); g.stroke();
  if (input && input.kind === 'ph') {
    g.fillStyle = 'rgba(10,10,10,.3)'; g.font = "300 28.8px 'Inter', system-ui, sans-serif";
    if (input.ltr) { g.textAlign = 'left'; g.fillText(input.text, 50, ulY - 30); }
    else g.fillText(input.text, 728, ulY - 30);
  } else if (input && input.kind === 'sel') {
    g.fillStyle = INK; g.font = "300 28.8px 'Inter', system-ui, sans-serif";
    g.fillText(input.text, 728, ulY - 30);
    g.fillStyle = STONE;
    g.beginPath(); g.moveTo(64, ulY - 46); g.lineTo(84, ulY - 46); g.lineTo(74, ulY - 34); g.closePath(); g.fill();
  } else if (input && input.kind === 'date') {
    g.fillStyle = 'rgba(10,10,10,.55)'; g.font = "300 28.8px 'Inter', system-ui, sans-serif";
    g.textAlign = 'left'; g.fillText('mm/dd/yyyy', 50, ulY - 30);
    g.strokeStyle = 'rgba(10,10,10,.75)'; g.lineWidth = 2.4;
    const cy = ulY - 47;
    g.strokeRect(702, cy, 22, 22);
    g.beginPath(); g.moveTo(702, cy + 7); g.lineTo(724, cy + 7); g.stroke();
    g.beginPath(); g.moveTo(707.5, cy - 4); g.lineTo(707.5, cy + 4); g.stroke();
    g.beginPath(); g.moveTo(718.5, cy - 4); g.lineTo(718.5, cy + 4); g.stroke();
  }
  g.restore();
}
function drawRes(st) {
  const g = resCtx, w = 780;
  g.globalAlpha = 1; g.setTransform(1, 0, 0, 1, 0, 0);
  drawNavBand(g, w);
  g.fillStyle = 'rgb(245,240,235)'; g.fillRect(0, 144, w, RES_H - 144);
  /* photo slot stays cream: the print carries the photo (DOM y144..728) */
  g.save();
  g.globalAlpha = st.label; g.translate(0, (1 - st.label) * 48);
  g.fillStyle = MOSS; g.font = "300 21.8px 'Inter', system-ui, sans-serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  fitSpaced(g, 'שמרו מקום', 724, 866, 262);
  g.strokeStyle = MOSS; g.lineWidth = 2; g.globalAlpha = st.label * .55;
  g.beginPath(); g.moveTo(362, 860); g.lineTo(438, 860); g.stroke();
  g.restore();
  g.save();
  g.globalAlpha = st.title; g.translate(0, (1 - st.title) * 72);
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('הזמינו', 725, 1008);
  g.fillStyle = MOSS; g.font = "italic 300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('שולחן', 725 - g.measureText('הזמינו ').width + 4, 1008);
  g.restore();
  g.save();
  g.globalAlpha = st.body; g.translate(0, (1 - st.body) * 48);
  g.fillStyle = STONE; g.font = "300 27.2px 'Inter', system-ui, sans-serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillText('מספר מקומות מוגבל. אנחנו ממליצים להזמין לפחות 48', 729, 1134);
  g.fillText('שעות מראש.', 730, 1186);
  g.restore();
  field(g, st.f1a, 'שם מלא', 1404, { kind: 'ph', text: 'ישראל ישראלי' }, 1510.5);
  field(g, st.f1b, 'טלפון', 1570, { kind: 'ph', text: '050-0000000', ltr: true }, 1676.5);
  field(g, st.f2a, 'תאריך', 1742, { kind: 'date' }, 1854.3);
  field(g, st.f2b, 'שעה', 1911.2, { kind: 'sel', text: 'בחר שעה' }, 2018.7);
  field(g, st.f3a, 'מספר סועדים', 2084, { kind: 'sel', text: 'בחר' }, 2191.5);
  field(g, st.f3b, 'סוג ביקור', 2247.2, { kind: 'sel', text: 'בחר' }, 2354.7);
  field(g, st.f4, 'הערות מיוחדות', 2420, { kind: 'ph', text: 'אלרגיות, בקשות מיוחדות...' }, 2529.5);
  if (st.f5 > 0) {
    g.save();
    g.globalAlpha = st.f5; g.translate(0, (1 - st.f5) * 48);
    g.fillStyle = GOLD; g.fillRect(48, 2581, 684, 92);
    g.fillStyle = INK; g.font = "500 24px 'Arial', sans-serif"; g.textAlign = 'center'; g.textBaseline = 'alphabetic';
    drawSpaced(g, 'אשרו את ההזמנה', 390, 2639, 4.8);
    g.restore();
  }
}
window.__resStage = pr => {
  const r = (a, b) => easeOutCubic(clamp01((pr - a) / (b - a)));
  return { label: r(.40, .48), title: r(.44, .52), body: r(.50, .58),
    f1a: r(.54, .61), f1b: r(.57, .64), f2a: r(.60, .67), f2b: r(.63, .70),
    f3a: r(.66, .73), f3b: r(.69, .76), f4: r(.71, .77), f5: r(.74, .80) };
};
window.__drawResFull = () => { drawRes({ label: 1, title: 1, body: 1, f1a: 1, f1b: 1, f2a: 1, f2b: 1, f3a: 1, f3b: 1, f4: 1, f5: 1 }); return resCanvas.toDataURL('image/png'); };


/* ---------- the footer end-card (ink slab, 780x2203) ---------- */
let ftCanvas, ftCtx, ftTex;
const FT_H = 2203;
function drawFt() {
  const g = ftCtx, w = 780;
  g.globalAlpha = 1; g.setTransform(1, 0, 0, 1, 0, 0);
  drawNavBand(g, w);
  g.fillStyle = 'rgb(6,6,6)'; g.fillRect(0, 144, w, FT_H - 144);
  g.textBaseline = 'alphabetic';
  /* brand logo: 'סו' gold + 'שימי' cream, baseline 330, right edge 726 */
  g.textAlign = 'right';
  g.fillStyle = CREAM; g.font = "400 64px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('שימי', 726, 330);
  const wS = g.measureText('שימי').width;
  g.fillStyle = GOLD;
  g.fillText('סו', 726 - wS, 330);
  /* brand paragraph, two stone lines */
  g.fillStyle = STONE; g.font = "300 27.2px 'Inter', system-ui, sans-serif";
  g.fillText('מסעדת סושי פרימיום במרכז תל אביב. אוכל טוב, שירות', 729, 430);
  g.fillText('שקט, חוויה שלא נשכחת.', 729, 482);
  /* column heads */
  g.fillStyle = GOLD; g.font = "400 21.8px 'Inter', system-ui, sans-serif";
  fitSpaced(g, 'ניווט', 724, 584, 76);
  fitSpaced(g, 'שעות פעילות', 724, 1099, 160);
  fitSpaced(g, 'צור קשר', 724, 1464, 120);
  /* nav links */
  g.fillStyle = STONE; g.font = "300 28px 'Inter', system-ui, sans-serif";
  const links = ['על המסעדה', 'תפריט', 'חוויה', 'גלריה', 'הזמנת שולחן'];
  links.forEach((t, i) => g.fillText(t, 729, 678 + i * 78));
  /* hours rows: day cream right, time stone left (ltr digits) */
  const hours = [['א-ה', '18:00–23:30'], ['שישי', '17:00–23:30'], ['שבת', '19:00–23:30']];
  hours.forEach((hr, i) => {
    const y = 1186 + i * 78;
    g.fillStyle = CREAM; g.textAlign = 'right'; g.fillText(hr[0], 729, y);
    g.fillStyle = STONE; g.textAlign = 'left'; g.fillText(hr[1], 50, y);
    g.strokeStyle = 'rgba(245,240,235,.08)'; g.lineWidth = 1.5;
    if (i < 2) { g.beginPath(); g.moveTo(48, y + 24); g.lineTo(732, y + 24); g.stroke(); }
  });
  g.textAlign = 'right';
  /* contact rows: phone omitted per gate */
  g.fillStyle = STONE; g.font = "300 28px 'Inter', system-ui, sans-serif";
  g.textAlign = 'left'; g.fillText('hello@sushimi.co.il', 50, 1614);
  g.textAlign = 'right'; g.fillText('רחוב דיזנגוף 120, תל אביב', 729, 1693);
  g.fillText('הגעה במפה ↗', 729, 1771);
  /* bottom bar */
  g.strokeStyle = 'rgba(245,240,235,.08)'; g.lineWidth = 1.5;
  g.beginPath(); g.moveTo(48, 1960); g.lineTo(732, 1960); g.stroke();
  g.fillStyle = STONE; g.font = "300 24px 'Inter', system-ui, sans-serif";
  g.textAlign = 'right'; g.fillText('© 2025 סושימי. כל הזכויות שמורות.', 729, 2010);
  g.textAlign = 'left'; g.fillText('Instagram   Facebook   TikTok', 50, 2010);
}
window.__drawFtFull = () => { drawFt(); return ftCanvas.toDataURL('image/png'); };

/* ---------- build ---------- */
let built = false;
async function build() {
  await loadFonts();
  const [expImg, gal1Img, gal2Img, gal3Img, gal4Img, gal5Img, resImg] = await Promise.all(
    ['exp-interior.jpg', 'gal1.jpg', 'gal2.jpg', 'gal3.jpg', 'gal4.jpg', 'gal5.jpg', 'res-photo.jpg'].map(loadImg));
  expImgEl = expImg;

  expCanvas = document.createElement('canvas'); expCanvas.width = 780; expCanvas.height = 1688;
  expCtx = expCanvas.getContext('2d');
  drawExp();
  expTex = new THREE.CanvasTexture(expCanvas); expTex.colorSpace = THREE.SRGBColorSpace; expTex.anisotropy = 8;
  const tile = panel(2.11, .975, expTex, Math.PI / 2);
  tile.position.set(4.5, -.0145, 0);
  addPart(tile, [-1, -.5], { x: 0, y: 0, z: 0, rot: 0 });

  EXPROWS.forEach((r, i) => {
    const it = ctex(144, 144, (g2) => {
      g2.drawImage(expCanvas, 660, ROWY[i] + 3, 72, 72, 0, 0, 144, 144);
    });
    const t = panel(.18, .18, it, Math.PI / 2);
    const vy = ROWY[i] + 39, vx = 696;
    t.position.set(4.5 - 1.055 + vy / 800, -.0135 + .001, .4875 - vx / 800);
    addPart(t, [-1, -.5], { x: 0, y: 0, z: 0, rot: 0 });
  });

  galCanvas = document.createElement('canvas'); galCanvas.width = 780; galCanvas.height = 3639;
  galCtx = galCanvas.getContext('2d');
  galImgs = [gal1Img, gal2Img, gal3Img, gal4Img, gal5Img];
  drawGal();
  galTex = new THREE.CanvasTexture(galCanvas); galTex.colorSpace = THREE.SRGBColorSpace; galTex.anisotropy = 8;
  const gtile = panel(4.549, .975, galTex, Math.PI / 2);
  gtile.position.set(7.9595, -.0145, 0);
  addPart(gtile, [-1, -.5], { x: 0, y: 0, z: 0, rot: 0 });

  GALITEMS.forEach((it, i) => {
    const pt = ctex(it.w, it.h, (g2) => {
      const im = galImgs[i], sc = Math.max(it.w / im.width, it.h / im.height);
      const dw = im.width * sc, dh = im.height * sc;
      g2.drawImage(im, (it.w - dw) / 2, (it.h - dh) / 2, dw, dh);
    });
    const p = panel(it.h / 800, it.w / 800, pt, Math.PI / 2);
    p.position.set(5.685 + (it.y + it.h / 2) / 800, -.0135 + .001, .4875 - (it.x + it.w / 2) / 800);
    addPart(p, [-1, -.5], { x: 0, y: 0, z: 0, rot: 0 });
  });

  /* the reservation card: a cream paper sheet, slides in along the counter */
  resCanvas = document.createElement('canvas'); resCanvas.width = 780; resCanvas.height = RES_H;
  resCtx = resCanvas.getContext('2d');
  drawRes({ label: 1, title: 1, body: 1, f1a: 1, f1b: 1, f2a: 1, f2b: 1, f3a: 1, f3b: 1, f4: 1, f5: 1 });
  resTex = new THREE.CanvasTexture(resCanvas); resTex.colorSpace = THREE.SRGBColorSpace; resTex.anisotropy = 8;
  const rtile = panel(RES_H / 800, .975, resTex, Math.PI / 2);
  rtile.position.set(12.109, -.0145, 0);
  addPart(rtile, [-1, -.5], { x: 0, y: 0, z: 0, rot: 0 });

  /* the toast-board photo: a print set down on the card */
  const rp = ctex(780, 585, (g2) => {
    const sc = Math.max(780 / resImg.width, 585 / resImg.height);
    const dw = resImg.width * sc, dh = resImg.height * sc;
    g2.drawImage(resImg, (780 - dw) / 2, (585 - dh) / 2, dw, dh);
    const gr = g2.createLinearGradient(780, 0, 0, 0); /* to-right in rtl: darkest at right edge */
    gr.addColorStop(0, 'rgba(10,10,10,0)'); gr.addColorStop(1, 'rgba(10,10,10,.4)');
    g2.fillStyle = gr; g2.fillRect(0, 0, 780, 585);
  });
  const rprint = panel(584 / 800, .975, rp, Math.PI / 2);
  rprint.position.set(10.364 + 436 / 800, -.0135 + .001, 0);
  addPart(rprint, [-1, -.5], { x: 0, y: 0, z: 0, rot: 0 });

  drawRes({ label: 1, title: 1, body: 1, f1a: 1, f1b: 1, f2a: 1, f2b: 1, f3a: 1, f3b: 1, f4: 1, f5: 1 });
  resTex.needsUpdate = true;

  /* the footer end-card: slides in along the counter, seals the journey */
  ftCanvas = document.createElement('canvas'); ftCanvas.width = 780; ftCanvas.height = FT_H;
  ftCtx = ftCanvas.getContext('2d');
  drawFt();
  ftTex = new THREE.CanvasTexture(ftCanvas); ftTex.colorSpace = THREE.SRGBColorSpace; ftTex.anisotropy = 8;
  const ftile = panel(FT_H / 800, .975, ftTex, Math.PI / 2);
  ftile.position.set(15.36, -.0145, 0);
  addPart(ftile, [.30, .44], { x: 1.6, y: 0, z: 0, rot: -.06 });
  built = true;
}

/* ---------- camera: gallery lock -> travel -> reservation lock ---------- */
const K0p = new THREE.Vector3(11.419, D_FINAL, 0), K0u = new THREE.Vector3(-1, 0, 0), K0l = new THREE.Vector3(11.419, 0, 0);
const K1p = new THREE.Vector3(15.1, 1.75, 1.75), K1u = new THREE.Vector3(-1, 0, 0), K1l = new THREE.Vector3(13.95, 0, -.3);
const K2p = new THREE.Vector3(15.039, D_FINAL, 0), K2u = new THREE.Vector3(-1, 0, 0), K2l = new THREE.Vector3(15.039, 0, 0);
const easeInOut = t => t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;

let pr = 0;
function update() {
  const max = document.documentElement.scrollHeight - innerHeight;
  pr = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
  if (built) {
    for (const p of parts) {
      const t = clamp01((pr - p.win[0]) / (p.win[1] - p.win[0]));
      const e = easeOutCubic(t), eio = easeInOutQ(t), dp = dip(t);
      p.grp.position.set(
        p.to.x + (1 - e) * p.from.x,
        p.to.y + (1 - eio) * (p.from.y || 0) + dp,
        p.to.z + (1 - eio) * (p.from.z || 0) + dp * .5);
      p.grp.rotation.y = (1 - t * t) * (p.from.rot || 0);
    }
  }
  const t1 = easeInOut(clamp01((pr - .06) / .34));
  const tD = easeInOut(clamp01((pr - .44) / .42)) * .03;
  const t2 = easeInOut(clamp01((pr - .88) / .12));
  
  const tt = Math.min(1, t1 + tD);
  const px = new THREE.Vector3().lerpVectors(K0p, K1p, tt);
  const ux = new THREE.Vector3().lerpVectors(K0u, K1u, tt);
  const lx = new THREE.Vector3().lerpVectors(K0l, K1l, tt);
  for (const gl of glows) {
    const wp = gl.glow.getWorldPosition(new THREE.Vector3());
    const d = wp.distanceTo(camera.position);
    gl.glow.material.opacity = gl.base * Math.min(1, Math.max(0, (d - 1.0) / 1.6));
  }
  camera.position.lerpVectors(px, K2p, t2);
  camera.up.lerpVectors(ux, K2u, t2).normalize();
  const l = lx.lerp(K2l, t2);
  camera.lookAt(l);
  renderer.render(scene, camera);
}
addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });
window.__dbg = () => ({ built, parts: parts.length, pr, cam: camera.position.toArray().map(v=>+v.toFixed(2)), up: camera.up.toArray(), children: scene.children.length, renderCalls: renderer.info.render.calls, tris: renderer.info.render.triangles });
build().then(() => { window.__builtOk = true; }).catch(e => { window.__buildErr = String(e && e.stack || e); });
(function loop() { if (!window.__stop) { update(); requestAnimationFrame(loop); } })();
window.__renderOnce = () => update();
