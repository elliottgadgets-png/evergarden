/* v18: about lock -> travel right (toward menu/experience) -> philosophy lock.
   Chain geometry (world x, page video px / 800):
     hero slot (reserved) [-5.515,-3.405] | about tile [-3.275,-1.165] | phil tile [-1.035,1.075]
     | menu slot (reserved) [1.205,3.315] | exp tile [3.445,5.555] (v14+) ... .13 gaps throughout.
   Lock cams: about -2.22, phil 0.02 (tile start + 1.055, D_FINAL).
   DOM truth measured from dom-about.png / dom-philosophy.png (780x1688, screenshot pixels are truth):
   ABOUT (ink rgb(10,10,10)): nav 0-144; photo slot 144..534 full-bleed (LIVE IMG 404s — stand-in
     Takashi Saito CC BY-SA 4.0, disclosed); '01' ghost Cormorant 160 rgba(201,169,110,.18)
     glyphs y340-440 x86..200; label 'על המסעדה' gold Inter 21.8 ls 6.1 baseline ~660 right 723 +
     line ~x455-530 y652; title Cormorant 76.8 cream L1 'לא פשוט סושי.' baseline ~796 right 726,
     L2 em gold italic 'מסע.' baseline ~880 right 726;
     body Inter 30.4 stone #9e9188 baselines 998/1056/1108 + 1268/1322 right 729;
     divider y1440 rgba(245,240,235,.08); stats numerals Cormorant 83.2 gold baseline 1590
     right edges 730/525/290 ('12','38','100'), labels Inter 22.4 stone ls 4 baseline 1637
     right edges 730/525/290.
   PHILOSOPHY (cream rgb(245,240,235) 144..970, then menu ink): kanji '寿司' Noto Serif JP 200
     320px rgba(10,10,10,.04) centered x390 middles ~418/~726; label 'הפילוסופיה שלנו' gold
     centered group baseline ~330 + line; title Cormorant 70.4 ink L1 '"הטעם הכי טוב הוא זה'
     baseline 465, L2 'שלא' baseline 545, L3 em moss italic 'צריך הסבר.' + ink '"' baseline 637,
     all centered x390; sub Inter 28.8 stone ls 2.3 baselines 744/790 centered.
   MENU top (ink from y970): label 'תפריט נבחר' gold baseline 1284 right 723 + line 455..530 y1277;
     title Cormorant 76.8 'המנות' cream + em 'שלנו' gold italic baseline 1422 right 723;
     link 'לתפריט המלא' gold Inter 24 ls 4.3 baseline 1558 right 723 + arrow svg left of text. */
import * as THREE from './vendor/three.module.js';

const CREAM = '#f5f0eb', GOLD = '#c9a96e', STONE = '#9e9188', MOSS = '#4a5240', INK = '#0a0a0a';
const FOV = 54, D_FINAL = 2.07;

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.0;
document.getElementById('stage').appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b0908);
const camera = new THREE.PerspectiveCamera(FOV, innerWidth / innerHeight, .05, 60);

scene.add(new THREE.AmbientLight(0x2a2118, .55));

const counter = new THREE.Mesh(
  new THREE.BoxGeometry(26, .12, 3.4),
  new THREE.MeshStandardMaterial({ color: 0x8a7663, roughness: .38, metalness: .08 }));
counter.position.set(5, -.06, 0); counter.receiveShadow = true; scene.add(counter);

const surround = new THREE.Mesh(new THREE.PlaneGeometry(80, 80),
  new THREE.MeshStandardMaterial({ color: 0x0b0908, roughness: 1 }));
surround.rotation.x = -Math.PI / 2; surround.position.y = -.125; scene.add(surround);

/* ---------- helpers ---------- */
function ctex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}
function drawSpaced(g, text, cx, cy, spacing) {
  const ch = [...text];
  const ws = ch.map(c => g.measureText(c).width);
  const total = ws.reduce((a, b) => a + b, 0) + spacing * (ch.length - 1);
  let x = cx + total / 2;
  const prevAlign = g.textAlign;
  g.textAlign = 'right';
  for (let i = 0; i < ch.length; i++) { g.fillText(ch[i], x, cy); x -= ws[i] + spacing; }
  g.textAlign = prevAlign;
}
function spacedW(g, text, spacing) {
  const ch = [...text];
  return ch.reduce((a, c) => a + g.measureText(c).width, 0) + spacing * (ch.length - 1);
}
function drawSpacedRight(g, text, rightX, cy, spacing) {
  drawSpaced(g, text, rightX - spacedW(g, text, spacing) / 2, cy, spacing);
}
const clamp01 = t => Math.min(1, Math.max(0, t));
const easeOutCubic = t => 1 - Math.pow(1 - t, 3);
const easeInOutQ = t => t * t * (3 - 2 * t);
const dip = t => Math.sin(Math.PI * clamp01(t)) * -.012;
function loadImg(src) { return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = src; }); }

async function loadFonts() {
  await Promise.all([
    document.fonts.load("300 77px 'Cormorant Garamond'", 'לא פשוט'),
    document.fonts.load("italic 300 77px 'Cormorant Garamond'", 'מסע'),
    document.fonts.load("300 83px 'Cormorant Garamond'", '12038'),
    document.fonts.load("300 70px 'Cormorant Garamond'", 'הטעם שלא'),
    document.fonts.load("italic 300 70px 'Cormorant Garamond'", 'צריך'),
    document.fonts.load("300 160px 'Cormorant Garamond'", '01'),
    document.fonts.load("200 320px 'Noto Serif JP'", '寿司'),
    document.fonts.load("300 30px 'Inter'", 'סושימי נולדה'),
    document.fonts.load("300 29px 'Inter'", 'כשהחומר מושלם'),
    document.fonts.load("300 22px 'Inter'", 'הפילוסופיה שלנו'),
    document.fonts.load("400 54px 'Cormorant Garamond'", 'סושימי'),
  ]);
  await document.fonts.ready;
}

/* ---------- glow sprites ---------- */
const glows = [];
function glowTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d');
  const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, 'rgba(255,214,150,.9)'); gr.addColorStop(.4, 'rgba(255,190,110,.32)'); gr.addColorStop(1, 'rgba(255,190,110,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
let glowTex = null;

function pendant(x, z, drop, glowS, intensity) {
  const g = new THREE.Group();
  const ceilY = 3.6;
  const cord = new THREE.Mesh(new THREE.CylinderGeometry(.006, .006, drop, 6),
    new THREE.MeshStandardMaterial({ color: 0x1a1512, roughness: .8 }));
  cord.position.set(0, ceilY - drop / 2, 0); g.add(cord);
  const shade = new THREE.Mesh(new THREE.ConeGeometry(.16, .14, 24, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x14100d, roughness: .6, metalness: .4, side: THREE.DoubleSide }));
  shade.position.set(0, ceilY - drop, 0); shade.castShadow = true; g.add(shade);
  const bulbY = ceilY - drop - .05;
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(.028, 12, 12),
    new THREE.MeshBasicMaterial({ color: 0xffd9a0 }));
  bulb.position.set(0, bulbY, 0); g.add(bulb);
  const pt = new THREE.PointLight(0xffc98a, intensity, 9, 2);
  pt.position.set(0, bulbY - .02, 0); pt.castShadow = true;
  pt.shadow.mapSize.set(512, 512); pt.shadow.bias = -.004;
  g.add(pt);
  if (!glowTex) glowTex = glowTexture();
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, transparent: true, opacity: .35, depthWrite: false, blending: THREE.AdditiveBlending }));
  spr.scale.set(glowS, glowS, 1); spr.position.set(0, bulbY, 0); g.add(spr);
  glows.push({ glow: spr, base: .35 });
  g.position.set(x, 0, z); scene.add(g);
}
pendant(-2.55, -.7, 3.7, 1.3, 5.3);   /* over the about card */
pendant(-2.1, 1.35, 2.4, .7, 8.8);    /* front strip by the about card */
pendant(-.15, -.7, 3.7, 1.3, 5.3);    /* over the philosophy card */
pendant(.3, 1.35, 2.4, .7, 8.8);      /* front strip by the philosophy card */
pendant(1.9, -.7, 3.7, 1.3, 5.3);     /* over the reserved menu slot */
pendant(2.35, 1.35, 2.4, .7, 8.8);    /* front strip by the reserved menu slot */

/* ---------- brass inlay fields ---------- */
const brass = new THREE.MeshStandardMaterial({ color: 0x9a7b4f, roughness: .3, metalness: .85 });
function brassRim(cx, lenX, widZ) {
  for (const [ox, oz, w, d] of [[0, widZ / 2 + .006, lenX + .024, .012], [0, -widZ / 2 - .006, lenX + .024, .012],
                                [lenX / 2 + .006, 0, .012, widZ + .024], [-lenX / 2 - .006, 0, .012, widZ + .024]]) {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(w, .005, d), brass);
    strip.position.set(cx + ox, .004, oz); strip.castShadow = true; scene.add(strip);
  }
}
brassRim(-2.22, 2.13, .995);   /* about field */
brassRim(0.02, 2.13, .995);    /* philosophy field */

/* ---------- page panels ---------- */
function panel(lenX, widZ, tex, texRot) {
  const geo = new THREE.BoxGeometry(lenX, .03, widZ);
  const side = new THREE.MeshStandardMaterial({ color: 0x14100d, roughness: .55, metalness: .2 });
  const face = new THREE.MeshBasicMaterial({ map: tex });
  const m = new THREE.Mesh(geo, [side, side, face, side, side, side]);
  if (texRot) { m.material[2].map.rotation = texRot; m.material[2].map.center.set(.5, .5); }
  m.castShadow = true; m.receiveShadow = true;
  scene.add(m);
  return m;
}

const parts = [];
function addPart(grp, win, from) { parts.push({ grp, win, from, to: grp.position.clone() }); }

function drawNavBand(g, w) {
  g.fillStyle = 'rgb(18,19,17)'; g.fillRect(0, 0, w, 144);
  g.fillStyle = 'rgba(201,169,110,.12)'; g.fillRect(0, 143, w, 2);
  g.strokeStyle = CREAM; g.lineWidth = 2.5; g.lineCap = 'round';
  for (let i = 0; i < 3; i++) { const y = 60 + i * 10; g.beginPath(); g.moveTo(56, y); g.lineTo(107, y); g.stroke(); }
  g.fillStyle = GOLD; g.font = "400 54px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  drawSpacedRight(g, 'סושימי', 726, 87, (153 - g.measureText('סושימי').width) / 4);
}

/* ---------- the about page (ink sheet, 780x1688) ---------- */
let aboutCanvas, aboutCtx, aboutTex;
function drawAbout(chefImg) {
  const g = aboutCtx, w = 780;
  g.globalAlpha = 1; g.setTransform(1, 0, 0, 1, 0, 0);
  g.fillStyle = 'rgb(10,10,10)'; g.fillRect(0, 0, w, 1688);
  /* chef photo, full-bleed slot 144..534 (stand-in: live img 404s) */
  if (chefImg) g.drawImage(chefImg, 0, 144, 780, 390);
  /* float numeral '01' over the photo, bottom-left */
  g.fillStyle = 'rgba(201,169,110,.18)'; g.font = "300 160px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.textAlign = 'left'; g.textBaseline = 'alphabetic';
  g.fillText('01', 86, 426);
  drawNavBand(g, w);
  /* section label */
  g.fillStyle = GOLD; g.font = "300 21.76px 'Inter', system-ui, sans-serif";
  drawSpacedRight(g, 'על המסעדה', 723, 660, 6.1);
  const lw = spacedW(g, 'על המסעדה', 6.1);
  g.strokeStyle = GOLD; g.lineWidth = 2;
  g.beginPath(); g.moveTo(723 - lw - 108, 653); g.lineTo(723 - lw - 18, 653); g.stroke();
  /* title */
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = CREAM; g.font = "300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('לא פשוט סושי.', 726, 796);
  g.fillStyle = GOLD; g.font = "italic 300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('מסע.', 734, 880);
  /* body */
  g.fillStyle = STONE; g.font = "300 30.4px 'Inter', system-ui, sans-serif";
  g.fillText('סושימי נולדה מתוך אובססיה לדיוק. כל מנה מוכנה', 729, 994);
  g.fillText('ברגע שהיא מוזמנת, מחומרים שמגיעים כל בוקר', 729, 1052);
  g.fillText('ישירות מהים. אין מלאי. אין פשרות.', 729, 1106);
  g.fillText('השף קנו ימאדה עלה לישראל אחרי 12 שנה בטוקיו', 729, 1268);
  g.fillText('ועשה דבר פשוט: הביא את הסוד איתו.', 729, 1322);
  /* divider */
  g.fillStyle = 'rgba(245,240,235,.08)'; g.fillRect(48, 1439, 684, 2);
  /* stats */
  g.fillStyle = GOLD; g.font = "300 83.2px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('12', 730, 1590); g.fillText('38', 525, 1590); g.fillText('100', 290, 1590);
  g.fillStyle = STONE; g.font = "300 22.4px 'Inter', system-ui, sans-serif";
  drawSpacedRight(g, 'שנות ניסיון', 730, 1637, 4.03);
  drawSpacedRight(g, 'מנות בתפריט', 525, 1637, 4.03);
  drawSpacedRight(g, '% טרי', 290, 1637, 4.03);
}
window.__drawAboutFull = () => { drawAbout(window.__chefImg); return aboutCanvas.toDataURL('image/png'); };

/* ---------- the philosophy page (cream sheet + menu top, 780x1688) ---------- */
let philCanvas, philCtx, philTex;
function drawPhil() {
  const g = philCtx, w = 780;
  g.globalAlpha = 1; g.setTransform(1, 0, 0, 1, 0, 0);
  g.fillStyle = 'rgb(245,240,235)'; g.fillRect(0, 0, w, 970);
  g.fillStyle = 'rgb(10,10,10)'; g.fillRect(0, 970, w, 1688 - 970);
  /* ghost kanji */
  g.fillStyle = 'rgba(10,10,10,.04)'; g.font = "200 320px 'Noto Serif JP', serif";
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText('寿', 390, 418); g.fillText('司', 390, 726);
  drawNavBand(g, w);
  /* label, centered with line */
  g.fillStyle = GOLD; g.font = "300 21.76px 'Inter', system-ui, sans-serif";
  const lw = spacedW(g, 'הפילוסופיה שלנו', 6.1);
  const gw = 96 + lw;
  drawSpacedRight(g, 'הפילוסופיה שלנו', 386 + gw / 2, 330, 6.1);
  g.strokeStyle = GOLD; g.lineWidth = 2;
  g.beginPath(); g.moveTo(386 - gw / 2, 322); g.lineTo(386 - gw / 2 + 80, 322); g.stroke();
  /* title, 3 centered lines */
  g.textBaseline = 'alphabetic'; g.textAlign = 'center';
  g.fillStyle = INK; g.font = "300 70.4px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('"הטעם הכי טוב הוא זה', 390, 465);
  g.fillText('שלא', 390, 545);
  const em = 'צריך הסבר.';
  g.font = "italic 300 70.4px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  const wEm = g.measureText(em).width;
  g.font = "300 70.4px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  const wQ = g.measureText('"').width;
  g.textAlign = 'right';
  const rx = 390 + (wEm + wQ) / 2;
  g.fillStyle = INK; g.fillText('"', rx - wEm, 629);
  g.fillStyle = MOSS; g.font = "italic 300 70.4px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText(em, rx, 629);
  g.textAlign = 'center';
  /* sub */
  g.fillStyle = STONE; g.font = "300 28.8px 'Inter', system-ui, sans-serif";
  drawSpaced(g, 'כשהחומר מושלם – לא מוסיפים. לא מסתירים.', 390, 744, 2.3);
  drawSpaced(g, 'מגישים.', 390, 790, 2.3);
  /* ---- menu section top (ink, from y970) ---- */
  g.fillStyle = GOLD; g.font = "300 21.76px 'Inter', system-ui, sans-serif";
  drawSpacedRight(g, 'תפריט נבחר', 723, 1284, 6.1);
  const mlw = spacedW(g, 'תפריט נבחר', 6.1);
  g.strokeStyle = GOLD; g.lineWidth = 2;
  g.beginPath(); g.moveTo(723 - mlw - 118, 1277); g.lineTo(723 - mlw - 18, 1277); g.stroke();
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = GOLD; g.font = "italic 300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('שלנו', 723, 1422);
  const wShe = g.measureText('שלנו ').width;
  g.fillStyle = CREAM; g.font = "300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('המנות', 723 - wShe + 6, 1422);
  /* full-menu link with arrow */
  g.fillStyle = GOLD; g.font = "300 24px 'Inter', system-ui, sans-serif";
  drawSpacedRight(g, 'לתפריט המלא', 723, 1558, 4.32);
  const lnkw = spacedW(g, 'לתפריט המלא', 4.32);
  g.strokeStyle = GOLD; g.lineWidth = 2.2; g.lineCap = 'round'; g.lineJoin = 'round';
  const ax = 723 - lnkw - 56, ay = 1549;
  g.beginPath(); g.moveTo(ax, ay); g.lineTo(ax + 28, ay); g.stroke();
  g.beginPath(); g.moveTo(ax + 16, ay - 8); g.lineTo(ax + 28, ay); g.lineTo(ax + 16, ay + 8); g.stroke();
}
window.__drawPhilFull = () => { drawPhil(); return philCanvas.toDataURL('image/png'); };

/* ---------- build ---------- */
let built = false;
async function build() {
  await loadFonts();
  const chefImg = await loadImg('about-chef.jpg');
  window.__chefImg = chefImg;

  aboutCanvas = document.createElement('canvas'); aboutCanvas.width = 780; aboutCanvas.height = 1688;
  aboutCtx = aboutCanvas.getContext('2d');
  drawAbout(chefImg);
  aboutTex = new THREE.CanvasTexture(aboutCanvas); aboutTex.colorSpace = THREE.SRGBColorSpace; aboutTex.anisotropy = 8;
  const atile = panel(2.11, .975, aboutTex, Math.PI / 2);
  atile.position.set(-2.22, -.0145, 0);
  addPart(atile, [-1, -.5], { x: 0, y: 0, z: 0, rot: 0 });

  philCanvas = document.createElement('canvas'); philCanvas.width = 780; philCanvas.height = 1688;
  philCtx = philCanvas.getContext('2d');
  drawPhil();
  philTex = new THREE.CanvasTexture(philCanvas); philTex.colorSpace = THREE.SRGBColorSpace; philTex.anisotropy = 8;
  const ptile = panel(2.11, .975, philTex, Math.PI / 2);
  ptile.position.set(0.02, -.0145, 0);
  addPart(ptile, [.30, .44], { x: 1.6, y: 0, z: 0, rot: -.06 });
  built = true;
}

/* ---------- camera: about lock -> travel right -> philosophy lock ---------- */
const K0p = new THREE.Vector3(-2.22, D_FINAL, 0), K0u = new THREE.Vector3(-1, 0, 0), K0l = new THREE.Vector3(-2.22, 0, 0);
const K1p = new THREE.Vector3(0.10, 1.75, 1.75), K1u = new THREE.Vector3(-1, 0, 0), K1l = new THREE.Vector3(-1.05, 0, -.3);
const K2p = new THREE.Vector3(0.02, D_FINAL, 0), K2u = new THREE.Vector3(-1, 0, 0), K2l = new THREE.Vector3(0.02, 0, 0);
const easeInOut = t => t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;

let pr = 0;
function update() {
  const max = document.documentElement.scrollHeight - innerHeight;
  pr = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
  if (built) {
    for (const p of parts) {
      const t = clamp01((pr - p.win[0]) / (p.win[1] - p.win[0]));
      const e = easeOutCubic(t), eio = easeInOutQ(t), dp = dip(t);
      p.grp.position.set(
        p.to.x + (1 - e) * p.from.x,
        p.to.y + (1 - eio) * (p.from.y || 0) + dp,
        p.to.z + (1 - eio) * (p.from.z || 0) + dp * .5);
      p.grp.rotation.y = (1 - t * t) * (p.from.rot || 0);
    }
  }
  const t1 = easeInOut(clamp01((pr - .06) / .34));
  const tD = easeInOut(clamp01((pr - .44) / .42)) * .03;
  const t2 = easeInOut(clamp01((pr - .88) / .12));

  const tt = Math.min(1, t1 + tD);
  const px = new THREE.Vector3().lerpVectors(K0p, K1p, tt);
  const ux = new THREE.Vector3().lerpVectors(K0u, K1u, tt);
  const lx = new THREE.Vector3().lerpVectors(K0l, K1l, tt);
  for (const gl of glows) {
    const wp = gl.glow.getWorldPosition(new THREE.Vector3());
    const d = wp.distanceTo(camera.position);
    gl.glow.material.opacity = gl.base * Math.min(1, Math.max(0, (d - 1.0) / 1.6));
  }
  camera.position.lerpVectors(px, K2p, t2);
  camera.up.lerpVectors(ux, K2u, t2).normalize();
  const l = lx.lerp(K2l, t2);
  camera.lookAt(l);
  renderer.render(scene, camera);
}
addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });
window.__dbg = () => ({ built, parts: parts.length, pr, cam: camera.position.toArray().map(v=>+v.toFixed(2)), up: camera.up.toArray(), children: scene.children.length, renderCalls: renderer.info.render.calls, tris: renderer.info.render.triangles });
build().then(() => { window.__builtOk = true; }).catch(e => { window.__buildErr = String(e && e.stack || e); });
(function loop() { if (!window.__stop) { update(); requestAnimationFrame(loop); } })();
window.__renderOnce = () => update();
