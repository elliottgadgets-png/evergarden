/* v15 (rebuilt after sandbox loss): experience lock -> travel down-counter -> gallery lock.
   One warm stone counter world; pages are physical tiles seated flush in brass frames;
   content assembles with the DOM's own reveal delays; camera never leaves the counter. */
import * as THREE from './vendor/three.module.js';

const CREAM = '#f5f0eb', GOLD = '#c9a96e', STONE = '#9e9188';
const FOV = 54, D_FINAL = 2.07; /* verified: fills 780x1688 frame with a 2.11 x .975 page tile */

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.0;
document.getElementById('stage').appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b0908);
const camera = new THREE.PerspectiveCamera(FOV, innerWidth / innerHeight, .05, 60);

scene.add(new THREE.AmbientLight(0x2a2118, .55));

/* ---------- the counter: one continuous warm stone surface ---------- */
const counter = new THREE.Mesh(
  new THREE.BoxGeometry(26, .12, 3.4),
  new THREE.MeshStandardMaterial({ color: 0x8a7663, roughness: .38, metalness: .08 }));
counter.position.set(5, -.06, 0); counter.receiveShadow = true; scene.add(counter);

/* soft dark surround so the practical light pools on the stone */
const surround = new THREE.Mesh(new THREE.PlaneGeometry(80, 80),
  new THREE.MeshStandardMaterial({ color: 0x0b0908, roughness: 1 }));
surround.rotation.x = -Math.PI / 2; surround.position.y = -.125; scene.add(surround);

/* ---------- helpers ---------- */
function ctex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}
function drawSpaced(g, text, cx, cy, spacing) {
  const ch = [...text];
  const ws = ch.map(c => g.measureText(c).width);
  const total = ws.reduce((a, b) => a + b, 0) + spacing * (ch.length - 1);
  let x = cx + total / 2;
  const prevAlign = g.textAlign;
  g.textAlign = 'right';
  for (let i = 0; i < ch.length; i++) { g.fillText(ch[i], x, cy); x -= ws[i] + spacing; }
  g.textAlign = prevAlign;
}
function fitSpaced(g, text, rightX, cy, targetW) {
  const w0 = g.measureText(text).width;
  const n = [...text].length - 1;
  drawSpaced(g, text, rightX - targetW / 2, cy, Math.max(0, (targetW - w0) / n));
}
const clamp01 = t => Math.min(1, Math.max(0, t));
const easeOutCubic = t => 1 - Math.pow(1 - t, 3);
const easeInOutQ = t => t * t * (3 - 2 * t);
const dip = t => Math.sin(Math.PI * clamp01(t)) * -.012;
function loadImg(src) { return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = src; }); }

async function loadFonts() {
  await Promise.all([
    document.fonts.load("300 77px 'Cormorant Garamond'", 'חוויה'),
    document.fonts.load("italic 300 77px 'Cormorant Garamond'", 'לפני'),
    document.fonts.load("300 29px 'Inter'", 'דגים'),
    document.fonts.load("400 22px 'Inter'", 'גלריה'),
    document.fonts.load("400 54px 'Cormorant Garamond'", 'סושימי'),
  ]);
  await document.fonts.ready;
}

/* ---------- glow sprites (proximity-faded in update) ---------- */
const glows = [];
function glowTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d');
  const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, 'rgba(255,214,150,.9)'); gr.addColorStop(.4, 'rgba(255,190,110,.32)'); gr.addColorStop(1, 'rgba(255,190,110,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
let glowTex = null;

/* ---------- pendants: the warm practicals ---------- */
function pendant(x, z, drop, glowS, intensity) {
  const g = new THREE.Group();
  const ceilY = 3.6;
  const cord = new THREE.Mesh(new THREE.CylinderGeometry(.006, .006, drop, 6),
    new THREE.MeshStandardMaterial({ color: 0x1a1512, roughness: .8 }));
  cord.position.set(0, ceilY - drop / 2, 0); g.add(cord);
  const shade = new THREE.Mesh(new THREE.ConeGeometry(.16, .14, 24, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x14100d, roughness: .6, metalness: .4, side: THREE.DoubleSide }));
  shade.position.set(0, ceilY - drop, 0); shade.castShadow = true; g.add(shade);
  const bulbY = ceilY - drop - .05;
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(.028, 12, 12),
    new THREE.MeshBasicMaterial({ color: 0xffd9a0 }));
  bulb.position.set(0, bulbY, 0); g.add(bulb);
  const pt = new THREE.PointLight(0xffc98a, intensity, 9, 2);
  pt.position.set(0, bulbY - .02, 0); pt.castShadow = true;
  pt.shadow.mapSize.set(512, 512); pt.shadow.bias = -.004;
  g.add(pt);
  if (!glowTex) glowTex = glowTexture();
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, transparent: true, opacity: .35, depthWrite: false, blending: THREE.AdditiveBlending }));
  spr.scale.set(glowS, glowS, 1); spr.position.set(0, bulbY, 0); g.add(spr);
  glows.push({ glow: spr, base: .35 });
  g.position.set(x, 0, z); scene.add(g);
}
pendant(-.6, -.7, 3.6, 1.8, 8);
pendant(2.3, -.7, 3.7, 1.3, 5.3);
pendant(2.55, 1.35, 2.4, .7, 8.8);
pendant(4.3, -.7, 3.7, 1.3, 5.3);   /* over the experience tile zone */
pendant(4.55, 1.35, 2.4, .7, 8.8);  /* front strip by the experience tile */
pendant(7.7, -.7, 3.7, 1.3, 5.3);   /* over the gallery page */
pendant(8.2, 1.35, 2.4, .7, 8.8);   /* front strip by the gallery page */

/* ---------- brass inlay fields ---------- */
const brass = new THREE.MeshStandardMaterial({ color: 0x9a7b4f, roughness: .3, metalness: .85 });
function brassRim(cx, lenX, widZ) {
  for (const [ox, oz, w, d] of [[0, widZ / 2 + .006, lenX + .024, .012], [0, -widZ / 2 - .006, lenX + .024, .012],
                                [lenX / 2 + .006, 0, .012, widZ + .024], [-lenX / 2 - .006, 0, .012, widZ + .024]]) {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(w, .005, d), brass);
    strip.position.set(cx + ox, .004, oz); strip.castShadow = true; scene.add(strip);
  }
}
brassRim(4.5, 2.13, .995);      /* experience field */
brassRim(7.9595, 4.573, .995);  /* gallery field (full-page tile 3639px long) */

/* ---------- page panels: .03 thick slabs, face flush at y=.0005 ---------- */
function panel(lenX, widZ, tex, texRot) {
  const geo = new THREE.BoxGeometry(lenX, .03, widZ);
  const side = new THREE.MeshStandardMaterial({ color: 0x14100d, roughness: .55, metalness: .2 });
  const face = new THREE.MeshBasicMaterial({ map: tex }); /* unlit: DOM-true colors at the lock */
  const m = new THREE.Mesh(geo, [side, side, face, side, side, side]);
  if (texRot) { m.material[2].map.rotation = texRot; m.material[2].map.center.set(.5, .5); }
  m.castShadow = true; m.receiveShadow = true;
  scene.add(m);
  return m;
}

/* ---------- parts: fly-in windows ---------- */
const parts = [];
function addPart(grp, win, from) { parts.push({ grp, win, from, to: grp.position.clone() }); }

/* ---------- the experience page (seated, fully revealed - continuity from v14) ----------
   DOM truth (390x844, section top under nav): nav band 0..143 rgb(18,19,17) + hairline;
   olive #4a5240 145..1112; title L1 right edge 733 baseline 264 cream, L2 737/361 gold italic;
   rows y0 503.9/644.1/784.3/924.4, baselines y0+34/y0+80, right edge x622, Inter 29px cream .8;
   icon boxes x661 y0+4 70x70 gold .4 border, SVG line glyphs (swap committed);
   photo strip 1112..1688 exp-interior cover + 135deg ink .2 gradient. */
const ROWY = [647.9, 788.1, 928.3, 1068.4];
const EXPROWS = [
  { icon: 'fish', lines: ['דגים מגיעים ישירות מהים בכל בוקר – ללא', 'מתווכים, ללא מלאי עודף.'] },
  { icon: 'knife', lines: ['חיתוך יד בלבד. כל פרוסה בזווית מדויקת של', '45° להגדלת שטח הפנים ועוצמת הטעם.'] },
  { icon: 'jar', lines: ['אורז מוכן פעמיים ביום. טמפרטורת גוף.', 'ולא פעם יותר מזה.'] },
  { icon: 'sticks', lines: ['שירות שקט. אף אחד לא ירוץ לשולחן שלך.', 'אנחנו פה, לא מעל.'] },
];
const ICONPATHS = {
  fish: ['M3.5 12c3-4.5 7-6.5 10.5-6.5 3 0 5.5 2.5 6.5 6.5-1 4-3.5 6.5-6.5 6.5-3.5 0-7.5-2-10.5-6.5z', 'M3.5 12l-2-3.5M3.5 12l-2 3.5'],
  knife: ['M3 21l8.5-8.5', 'M11 13.5C13 10 17 5.5 21.5 3c.5 4.5-3 8.5-7.5 10.5l-3 0z'],
  jar: ['M7 8h10v3.5c1 .8 1.5 2 1.5 3.5v4.5c0 1-1 2-2.5 2H8c-1.5 0-2.5-1-2.5-2V15c0-1.5.5-2.7 1.5-3.5V8z', 'M6.5 5.5h11V8h-11z', 'M8.5 14.5c2-1 5-1 7 0'],
  sticks: ['M5 3.5L19 20', 'M9.5 3L20.5 16.5'],
};
const ICONDOTS = { fish: [16.5, 10.5], knife: [5.5, 18.5] };
function drawIcon(g, name, cx, cy, size) {
  const s = size / 24;
  g.save(); g.translate(cx - 12 * s, cy - 12 * s); g.scale(s, s);
  g.strokeStyle = 'rgba(245,240,235,.8)'; g.lineWidth = 1.5; g.lineCap = 'round'; g.lineJoin = 'round';
  for (const d of ICONPATHS[name]) { const p = new Path2D(d); g.stroke(p); }
  if (ICONDOTS[name]) { g.fillStyle = 'rgba(245,240,235,.8)'; const p = new Path2D(); p.arc(ICONDOTS[name][0], ICONDOTS[name][1], .8, 0, 7); g.fill(p); }
  g.restore();
}

let expCanvas, expCtx, expTex, expImgEl = null;
function drawExp(st) {
  const g = expCtx, w = 780;
  g.globalAlpha = 1; g.setTransform(1, 0, 0, 1, 0, 0);
  g.fillStyle = 'rgb(18,19,17)'; g.fillRect(0, 0, w, 144);
  g.fillStyle = 'rgba(201,169,110,.12)'; g.fillRect(0, 143, w, 2);
  g.strokeStyle = CREAM; g.lineWidth = 2.5; g.lineCap = 'round';
  for (let i = 0; i < 3; i++) { const y = 60 + i * 10; g.beginPath(); g.moveTo(56, y); g.lineTo(107, y); g.stroke(); }
  g.fillStyle = GOLD; g.font = "400 54px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  fitSpaced(g, 'סושימי', 726, 87, 153);
  g.fillStyle = '#4a5240'; g.fillRect(0, 145, w, 1256.6 - 145);
  /* label: 'למה סושימי' gold, right edge 724, baseline ~267, line to its left */
  g.save();
  g.globalAlpha = st.title; g.translate(0, (1 - st.title) * 72);
  g.fillStyle = 'rgba(245,240,235,.6)'; g.font = "400 22px 'Inter', system-ui, sans-serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  drawSpaced(g, 'למה סושימי', 644, 267, 6.2);
  g.strokeStyle = 'rgba(245,240,235,.3)'; g.lineWidth = 2; g.beginPath(); g.moveTo(508, 259); g.lineTo(584, 259); g.stroke();
  g.restore();
  if (expImgEl) {
    const s2 = Math.max(780 / expImgEl.width, 624 / expImgEl.height);
    const dw = expImgEl.width * s2, dh = expImgEl.height * s2;
    g.save(); g.beginPath(); g.rect(0, 1256.6, 780, 1688 - 1256.6); g.clip();
    g.drawImage(expImgEl, (780 - dw) / 2, 1256.6 + (624 - dh) / 2, dw, dh);
    const gr = g.createLinearGradient(0, 1256.6, 780, 1688);
    gr.addColorStop(0, 'rgba(10,10,10,.2)'); gr.addColorStop(1, 'rgba(10,10,10,0)');
    g.fillStyle = gr; g.fillRect(0, 1256.6, 780, 1688 - 1256.6);
    g.restore();
  }
  g.save();
  g.globalAlpha = st.title; g.translate(0, (1 - st.title) * 72);
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = CREAM; g.font = "300 77px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('חוויה שמתחילה', 732, 408);
  g.fillStyle = GOLD; g.font = "italic 300 77px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('לפני הביס הראשון', 732, 492);
  g.restore();
  for (let i = 0; i < 4; i++) {
    const t = st.rows[i], y0 = ROWY[i];
    g.save();
    g.beginPath(); g.rect(0, y0 - 30, 780, 150); g.clip();
    g.globalAlpha = t; g.translate(0, (1 - t) * 72);
    g.textAlign = 'right'; g.textBaseline = 'alphabetic';
    g.fillStyle = 'rgba(245,240,235,.8)'; g.font = "300 29px 'Inter', system-ui, sans-serif";
    g.fillText(EXPROWS[i].lines[0], 622, y0 + 34);
    g.fillText(EXPROWS[i].lines[1], 622, y0 + 80);
    g.strokeStyle = 'rgba(201,169,110,.4)'; g.lineWidth = 2; g.strokeRect(661, y0 + 4, 70, 70);
    drawIcon(g, EXPROWS[i].icon, 696, y0 + 39, 33);
    g.restore();
  }
}
window.__expStage = pr => ({ title: 1, rows: [1, 1, 1, 1] });
window.__drawExpFull = () => { drawExp({ title: 1, rows: [1, 1, 1, 1] }); return expCanvas.toDataURL('image/png'); }; /* v15 opens on the finished experience lock */

/* ---------- the gallery page (full height 3639px, five prints set down one by one) ----------
   DOM truth (section top at 144.6 under nav): ink rgb(10,10,10); label y304.6 (gold 22px Inter,
   ls ~6.2, right-aligned center 687, gold line 540-616 y321); title baseline 472 right edge 732
   ('ב' cream + 'תוך' gold italic + ' סושימי' cream ls 3px);
   items x48 w684 y675.7/1170.3/2234.7/2729.1/3167.5 h456/1026/456/400/456; gap ~38. */
let galCanvas, galCtx, galTex, galImgs = null;
const GALITEMS = [
  { x: 48, y: 675.7, w: 684, h: 456 },
  { x: 48, y: 1170.3, w: 684, h: 1026 },
  { x: 48, y: 2234.7, w: 684, h: 456 },
  { x: 48, y: 2729.1, w: 684, h: 400 },
  { x: 48, y: 3167.5, w: 684, h: 456 },
];
function drawGal(st) {
  const g = galCtx, w = 780;
  g.globalAlpha = 1; g.setTransform(1, 0, 0, 1, 0, 0);
  g.fillStyle = 'rgb(10,10,10)'; g.fillRect(0, 0, w, 3639);
  g.fillStyle = 'rgba(201,169,110,.12)'; g.fillRect(0, 143, w, 2);
  g.strokeStyle = CREAM; g.lineWidth = 2.5; g.lineCap = 'round';
  for (let i = 0; i < 3; i++) { const y = 60 + i * 10; g.beginPath(); g.moveTo(56, y); g.lineTo(107, y); g.stroke(); }
  g.fillStyle = GOLD; g.font = "400 54px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  fitSpaced(g, 'סושימי', 726, 87, 153);
  g.save();
  g.globalAlpha = st.label; g.translate(0, (1 - st.label) * 72);
  g.fillStyle = GOLD; g.font = "400 22px 'Inter', system-ui, sans-serif"; g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  drawSpaced(g, 'גלריה', 687, 329, 6.2);
  g.strokeStyle = GOLD; g.lineWidth = 2; g.beginPath(); g.moveTo(540, 321); g.lineTo(616, 321); g.stroke();
  g.restore();
  g.save();
  g.globalAlpha = st.title; g.translate(0, (1 - st.title) * 72);
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = CREAM; g.font = "300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('ב', 732, 472);
  const wBet = g.measureText('ב').width;
  g.fillStyle = GOLD; g.font = "italic 300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.fillText('תוך', 732 - wBet, 472);
  const wTok = g.measureText('תוך').width;
  g.fillStyle = CREAM; g.font = "300 76.8px 'Cormorant Garamond', 'Noto Serif JP', Georgia, serif";
  g.letterSpacing = '3px'; g.fillText(' סושימי', 732 - wBet - wTok, 472); g.letterSpacing = '0px';
  g.restore();
}
window.__galStage = pr => {
  const r = (a, b) => easeOutCubic(clamp01((pr - a) / (b - a)));
  return { label: r(.46, .54), title: r(.50, .60) };
};
window.__drawGalFull = () => { drawGal({ label: 1, title: 1 }); return galCanvas.toDataURL('image/png'); };

/* ---------- build ---------- */
let built = false;
async function build() {
  await loadFonts();
  const [expImg, gal1Img, gal2Img, gal3Img, gal4Img, gal5Img] = await Promise.all(
    ['exp-interior.jpg', 'gal1.jpg', 'gal2.jpg', 'gal3.jpg', 'gal4.jpg', 'gal5.jpg'].map(loadImg));
  expImgEl = expImg;

  /* the experience tile: seated in its brass frame (continuity from v14) */
  expCanvas = document.createElement('canvas'); expCanvas.width = 780; expCanvas.height = 1688;
  expCtx = expCanvas.getContext('2d');
  drawExp({ title: 1, rows: [1, 1, 1, 1] });
  expTex = new THREE.CanvasTexture(expCanvas); expTex.colorSpace = THREE.SRGBColorSpace; expTex.anisotropy = 8;
  const tile = panel(2.11, .975, expTex, Math.PI / 2);
  tile.position.set(4.5, -.0145, 0);
  addPart(tile, [-1, -.5], { x: 1.6, y: 0, z: 0, rot: -.06 }); /* already seated */

  /* four icon tiles: seated on the page face (continuity) */
  EXPROWS.forEach((r, i) => {
    const it = ctex(144, 144, (g2) => {
      g2.drawImage(expCanvas, 660, ROWY[i] + 3, 72, 72, 0, 0, 144, 144);
    });
    const t = panel(.18, .18, it, Math.PI / 2);
    const vy = ROWY[i] + 39, vx = 696;
    t.position.set(4.5 - 1.055 + vy / 800, -.0135 + .001, .4875 - vx / 800);
    addPart(t, [-1, -.5], { x: .06 + i * .05, y: .1, z: 0, rot: .05 });
  });

  /* the gallery page: a full-height ink slab, slides in along the counter */
  galCanvas = document.createElement('canvas'); galCanvas.width = 780; galCanvas.height = 3639;
  galCtx = galCanvas.getContext('2d');
  galImgs = [gal1Img, gal2Img, gal3Img, gal4Img, gal5Img];
  drawGal({ label: 1, title: 1 });
  galTex = new THREE.CanvasTexture(galCanvas); galTex.colorSpace = THREE.SRGBColorSpace; galTex.anisotropy = 8;
  const gtile = panel(4.549, .975, galTex, Math.PI / 2);
  gtile.position.set(7.9595, -.0145, 0);
  addPart(gtile, [.36, .48], { x: 1.6, y: 0, z: 0, rot: -.06 });

  /* five photo prints: set down one by one (DOM reveal delays 0/.1/.2/.3/.4) */
  const PW = [.46, .55, .64, .73, .82];
  GALITEMS.forEach((it, i) => {
    const pt = ctex(it.w, it.h, (g2) => {
      const im = galImgs[i], sc = Math.max(it.w / im.width, it.h / im.height);
      const dw = im.width * sc, dh = im.height * sc;
      g2.drawImage(im, (it.w - dw) / 2, (it.h - dh) / 2, dw, dh);
    });
    const p = panel(it.h / 800, it.w / 800, pt, Math.PI / 2);
    p.position.set(5.685 + (it.y + it.h / 2) / 800, -.0135 + .001, .4875 - (it.x + it.w / 2) / 800);
    addPart(p, [PW[i], PW[i] + .11], { x: .55 + i * .1, y: .14, z: 0, rot: .05 });
  });

  drawGal({ label: 0, title: 0 }); galTex.needsUpdate = true;
  built = true;
}

/* ---------- camera: experience lock -> travel down-counter -> gallery top lock ---------- */
const K0p = new THREE.Vector3(4.5, D_FINAL, 0), K0u = new THREE.Vector3(-1, 0, 0), K0l = new THREE.Vector3(4.5, 0, 0);
const K1p = new THREE.Vector3(7.84, 1.75, 1.75), K1u = new THREE.Vector3(-1, 0, 0), K1l = new THREE.Vector3(6.59, 0, -.3);
const K2p = new THREE.Vector3(6.74, D_FINAL, 0), K2u = new THREE.Vector3(-1, 0, 0), K2l = new THREE.Vector3(6.74, 0, 0);
const easeInOut = t => t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;

let pr = 0;
function update() {
  const max = document.documentElement.scrollHeight - innerHeight;
  pr = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
  if (built) {
    for (const p of parts) {
      const t = clamp01((pr - p.win[0]) / (p.win[1] - p.win[0]));
      const e = easeOutCubic(t), eio = easeInOutQ(t), dp = dip(t);
      p.grp.position.set(
        p.to.x + (1 - e) * p.from.x,
        p.to.y + (1 - eio) * (p.from.y || 0) + dp,
        p.to.z + (1 - eio) * (p.from.z || 0) + dp * .5);
      p.grp.rotation.y = (1 - t * t) * (p.from.rot || 0);
    }
  }
  const t1 = easeInOut(clamp01((pr - .06) / .34));          /* travel: exp lock -> oblique over the gallery page */
  const tD = easeInOut(clamp01((pr - .40) / .46)) * .03;    /* micro-drift while the page + prints seat */
  const t2 = easeInOut(clamp01((pr - .88) / .12));          /* crane: oblique -> gallery lock */
  if (window.__expStage && expCtx) { drawExp(window.__expStage(pr)); expTex.needsUpdate = true; }
  if (window.__galStage && galCtx) { drawGal(window.__galStage(pr)); galTex.needsUpdate = true; }
  const tt = Math.min(1, t1 + tD);
  const px = new THREE.Vector3().lerpVectors(K0p, K1p, tt);
  const ux = new THREE.Vector3().lerpVectors(K0u, K1u, tt);
  const lx = new THREE.Vector3().lerpVectors(K0l, K1l, tt);
  for (const gl of glows) {
    const wp = gl.glow.getWorldPosition(new THREE.Vector3());
    const d = wp.distanceTo(camera.position);
    gl.glow.material.opacity = gl.base * Math.min(1, Math.max(0, (d - 1.0) / 1.6));
  }
  camera.position.lerpVectors(px, K2p, t2);
  camera.up.lerpVectors(ux, K2u, t2).normalize();
  const l = lx.lerp(K2l, t2);
  camera.lookAt(l);
  renderer.render(scene, camera);
}
addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });
window.__dbg = () => ({ built, parts: parts.length, pr, cam: camera.position.toArray().map(v=>+v.toFixed(2)), up: camera.up.toArray(), children: scene.children.length, renderCalls: renderer.info.render.calls, tris: renderer.info.render.triangles });
build().then(() => { window.__builtOk = true; }).catch(e => { window.__buildErr = String(e && e.stack || e); });
(function loop() { if (!window.__stop) { update(); requestAnimationFrame(loop); } })();
window.__renderOnce = () => update();
