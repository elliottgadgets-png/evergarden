import bpy
bpy.ops.wm.open_mainfile(filepath='draw1.blend')
pr=bpy.data.objects['pencil_root']
act=pr.animation_data.action
# remove all keys after f63 on location and rotation_euler
for fc in act.fcurves:
    if fc.data_path in ('location','rotation_euler'):
        for k in list(fc.keyframe_points):
            if k.co.x>63.5:
                fc.keyframe_points.remove(k)
# new path: right of paper (paper x in [0.2625,0.3675], front edge y=-0.074)
loc_keys={63:(0.315,0.06,0.09), 66:(0.44,0.03,0.13), 69:(0.42,-0.10,0.05), 70:(0.345,-0.10,0.038), 71:(0.27,-0.096,0.0334)}
rot_keys={63:(0.5665,0.0,2.1112), 66:(0.4,0.6,1.4), 69:(0.15,1.2,0.6), 70:(0.02,1.5,0.2), 71:(0.0,1.5359,0.1396)}
for f,v in loc_keys.items():
    pr.location=v; pr.keyframe_insert('location',frame=f)
for f,v in rot_keys.items():
    pr.rotation_euler=v; pr.keyframe_insert('rotation_euler',frame=f)
for fc in act.fcurves:
    if fc.data_path in ('location','rotation_euler'):
        for k in fc.keyframe_points:
            if k.co.x>=63.5: k.interpolation='LINEAR'
bpy.ops.wm.save_mainfile()
print("SAVED")
# report evaluated root positions f63-71
sc=bpy.context.scene
for f in range(63,72):
    sc.frame_set(f)
    bpy.context.view_layer.update()
    print("f%d loc"%f, tuple(round(x,4) for x in pr.matrix_world.translation))
