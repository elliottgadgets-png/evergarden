import bpy
bpy.ops.wm.open_mainfile(filepath='draw1.blend')
pr=bpy.data.objects['pencil_root']
act=pr.animation_data.action
for fc in act.fcurves:
    if fc.data_path in ('location','rotation_euler'):
        idxs=[i for i,k in enumerate(fc.keyframe_points) if k.co.x>63.5]
        for i in reversed(idxs):
            fc.keyframe_points.remove(fc.keyframe_points[i], fast=True)
        fc.update()
# lift away and out of frame top; hold out of frame through f71
loc_keys={63:(0.315,0.06,0.09), 66:(0.35,0.10,0.16), 69:(0.38,0.15,0.24), 71:(0.38,0.15,0.24)}
rot_keys={63:(0.5665,0.0,2.1112), 66:(0.35,0.25,1.7), 69:(0.2,0.1,1.85), 71:(0.2,0.1,1.85)}
for f,v in loc_keys.items():
    pr.location=v; pr.keyframe_insert('location',frame=f)
for f,v in rot_keys.items():
    pr.rotation_euler=v; pr.keyframe_insert('rotation_euler',frame=f)
for fc in act.fcurves:
    if fc.data_path in ('location','rotation_euler'):
        for k in fc.keyframe_points:
            if k.co.x>=63.5: k.interpolation='LINEAR'
bpy.ops.wm.save_mainfile()
print("SAVED")
