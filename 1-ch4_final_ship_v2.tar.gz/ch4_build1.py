import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
sc.frame_start=0; sc.frame_end=71

# 1. park ch3 frames out of this chapter
for o in sc.objects:
    if o.name.startswith('frame'):
        o.hide_render=True

# 2. clear camera/focus animation
cam=sc.camera
if cam.animation_data: cam.animation_data_clear()
fo=bpy.data.objects.get('focus')
if fo and fo.animation_data: fo.animation_data_clear()

def mat_principled(name,color,rough=0.4,metal=0.0):
    m=bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes=True
    b=m.node_tree.nodes['Principled BSDF']
    b.inputs['Base Color'].default_value=(*color,1)
    b.inputs['Roughness'].default_value=rough
    b.inputs['Metallic'].default_value=metal
    return m

graphite=mat_principled('graphite',(0.06,0.06,0.07),rough=0.55)
paper_mat=mat_principled('paper',(0.93,0.90,0.84),rough=0.85)
paint_mat=mat_principled('pencil_paint',(0.85,0.55,0.12),rough=0.35)
wood_mat=mat_principled('pencil_wood',(0.82,0.68,0.5),rough=0.6)
lead_mat=mat_principled('pencil_lead',(0.08,0.08,0.09),rough=0.3)
ferrule_mat=mat_principled('ferrule',(0.75,0.75,0.78),rough=0.25,metal=0.95)
eraser_mat=mat_principled('eraser',(0.75,0.4,0.42),rough=0.7)

PX,PY,PZ=0.315,0.0,0.030   # paper center on bench (bench top 0.03)
PW,PH=0.105,0.148          # A6-ish
PT=0.0004                  # paper thickness

# 3. paper with thickness and slight corner curl
N=20
verts=[]; faces=[]
for j in range(N+1):
    for i in range(N+1):
        x=-PW/2+PW*i/N; y=-PH/2+PH*j/N
        # gentle curl: lift corners, more at far-left
        fx=(x/(PW/2))**2; fy=(y/(PH/2))**2
        z=0.0016*fx*fy + 0.0006*fx
        verts.append((PX+x,PY+y,PZ+PT+z))
for j in range(N):
    for i in range(N):
        a=j*(N+1)+i; faces.append((a,a+1,a+N+2,a+N+1))
me=bpy.data.meshes.new('paper_mesh'); me.from_pydata(verts,[],faces); me.update()
paper=bpy.data.objects.new('paper',me); sc.collection.objects.link(paper)
paper.data.materials.append(paper_mat)
sol=paper.modifiers.new('th','SOLIDIFY'); sol.thickness=PT
sub=paper.modifiers.new('sm','SUBSURF'); sub.levels=1; sub.render_levels=1

# 4. pencil: hex body along +Z from tip-root
bpy.ops.object.empty_add(location=(PX,PY,PZ+PT))
proot=bpy.context.active_object; proot.name='pencil_root'
def pencil_part(name, verts, radius, depth, z0, mat):
    bpy.ops.mesh.primitive_cone_add(vertices=verts, radius1=radius, radius2=radius, depth=depth, location=(0,0,z0+depth/2))
    o=bpy.context.active_object; o.name=name; o.data.materials.append(mat)
    o.parent=proot; return o
pencil_part('penc_body',6,0.0032,0.075,0.012,paint_mat)
# wood cone (sharpened)
bpy.ops.mesh.primitive_cone_add(vertices=12, radius1=0.0032, radius2=0.0008, depth=0.009, location=(0,0,0.0075))
o=bpy.context.active_object; o.name='penc_wood'; o.data.materials.append(wood_mat); o.parent=proot
# graphite tip
bpy.ops.mesh.primitive_cone_add(vertices=12, radius1=0.0008, radius2=0.0001, depth=0.003, location=(0,0,0.0015))
o=bpy.context.active_object; o.name='penc_tip'; o.data.materials.append(lead_mat); o.parent=proot
# ferrule + eraser
pencil_part('penc_ferrule',12,0.0034,0.006,0.087,ferrule_mat)
pencil_part('penc_eraser',12,0.0033,0.006,0.093,eraser_mat)

# 5. strokes: curves with animated bevel_factor_end; pencil tip follows
def stroke_pts_rect(cx,cy,w,h):
    return [(cx-w/2,cy-h/2),(cx+w/2,cy-h/2),(cx+w/2,cy+h/2),(cx-w/2,cy+h/2),(cx-w/2,cy-h/2)]
def stroke_circle(cx,cy,r,n=16):
    return [(cx+r*math.cos(2*math.pi*k/n), cy+r*math.sin(2*math.pi*k/n)) for k in range(n+1)]
def stroke_poly(pts): return pts

# panel layout (paper-local, y up on paper); panel interior x in [PX-0.019, PX+0.019]
panels=[PY+0.045, PY+0.0, PY-0.045]
pw2,ph2=0.038,0.017
strokes=[]
for py in panels:
    strokes.append(stroke_pts_rect(PX,py,pw2,ph2))
# panel1: sun (upper right, inside) + two mountains
strokes.append(stroke_circle(PX+0.011,panels[0]+0.005,0.004))
strokes.append([(PX-0.017,panels[0]-0.011),(PX-0.009,panels[0]+0.004),(PX-0.001,panels[0]-0.011)])
strokes.append([(PX-0.005,panels[0]-0.011),(PX+0.003,panels[0]+0.002),(PX+0.011,panels[0]-0.011)])
# panel2: stick figure inside (panel y +-0.0085)
strokes.append(stroke_circle(PX-0.008,panels[1]+0.0055,0.0032))
strokes.append([(PX-0.008,panels[1]+0.0023),(PX-0.008,panels[1]-0.005)])
strokes.append([(PX-0.015,panels[1]-0.001),(PX-0.001,panels[1]-0.001)])
strokes.append([(PX-0.008,panels[1]-0.005),(PX-0.014,panels[1]-0.008)])
strokes.append([(PX-0.008,panels[1]-0.005),(PX-0.002,panels[1]-0.008)])
# panel3: star centered
import math as m2
def star(cx,cy,r1,r2,n=5):
    pts=[]
    for k in range(2*n+1):
        r=r1 if k%2==0 else r2
        a=m2.pi/2 + k*m2.pi/n
        pts.append((cx+r*m2.cos(a), cy+r*m2.sin(a)))
    return pts
strokes.append(star(PX,panels[2],0.008,0.0032))

# timing: draw f14..f58 across all strokes, weighted by length, clamped to fit
def slen(pts): return sum((Vector(pts[k+1])-Vector(pts[k])).length for k in range(len(pts)-1))
lens=[slen(s) for s in strokes]; total=sum(lens)
t0,t1=14,58
wins=[]; cum=0.0
for idx,L in enumerate(lens):
    s=t0+round((t1-t0)*cum/total); cum+=L
    e=t0+round((t1-t0)*cum/total)
    if e<=s: e=s+1
    wins.append((s,e))

SZ=PZ+2*PT+0.0022+0.0005  # stroke z (paper top incl. curl max ~0.0022) -> sit just above max curl plane
SZ=PZ+PT+0.0023

stroke_curves=[]
for i,pts in enumerate(strokes):
    cu=bpy.data.curves.new(f'stroke{i}','CURVE'); cu.dimensions='3D'
    sp=cu.splines.new('POLY'); sp.points.add(len(pts)-1)
    for k,(x,y) in enumerate(pts):
        # local curl height at (x,y)
        lx,ly=x-PX,y-PY
        z=0.0016*(lx/(PW/2))**2*(ly/(PH/2))**2 + 0.0006*(lx/(PW/2))**2
        sp.points[k].co=(x,y,PZ+PT+z+0.0003,1)
    cu.bevel_depth=0.00045; cu.bevel_resolution=2; cu.resolution_u=1
    ob=bpy.data.objects.new(f'stroke{i}',cu); sc.collection.objects.link(ob)
    ob.data.materials.append(graphite)
    stroke_curves.append((ob,pts))

# animate bevel_factor_end + pencil tip
def bez_key(cu,f,v,interp='LINEAR'):
    sc.frame_set(f); cu.bevel_factor_end=v
    cu.keyframe_insert('bevel_factor_end')
    for fc in cu.animation_data.action.fcurves:
        if fc.data_path=='bevel_factor_end':
            for kp in fc.keyframe_points: kp.interpolation=interp

for (ob,pts),(s,e) in zip(stroke_curves,wins):
    cu=ob.data
    bez_key(cu,s,0.0); bez_key(cu,e,1.0)
    # cumulative lengths for tip tracking
    cum=[0.0]
    for k in range(len(pts)-1): cum.append(cum[-1]+(Vector(pts[k+1])-Vector(pts[k])).length)
    tot=cum[-1]
    for f in range(s,e+1,2):
        u=(f-s)/max(1,(e-s)); d=u*tot
        k=0
        while k<len(cum)-2 and cum[k+1]<d: k+=1
        seg=(cum[k+1]-cum[k]) or 1e-6; t=(d-cum[k])/seg
        x=pts[k][0]+(pts[k+1][0]-pts[k][0])*t
        y=pts[k][1]+(pts[k+1][1]-pts[k][1])*t
        lx,ly=x-PX,y-PY
        z=0.0016*(lx/(PW/2))**2*(ly/(PH/2))**2 + 0.0006*(lx/(PW/2))**2
        sc.frame_set(f)
        proot.location=(x,y,PZ+PT+z+0.0002)
        proot.rotation_euler=Vector((0.030,0.018,0.055)).normalized().to_track_quat('Z','Y').to_euler()
        proot.keyframe_insert('location'); proot.keyframe_insert('rotation_euler')

# pencil rest poses: lying on bench before/after
def pencil_rest(f):
    sc.frame_set(f)
    proot.location=(PX-0.045,PY-0.096,PZ+0.0034)
    proot.rotation_euler=(0,math.radians(88),math.radians(8))
    proot.keyframe_insert('location'); proot.keyframe_insert('rotation_euler')
pencil_rest(0)
pencil_rest(71)
# rise & dip keys around drawing window
DRAWTILT=Vector((0.030,0.018,0.055)).normalized().to_track_quat('Z','Y').to_euler()
sc.frame_set(10); proot.location=(PX-0.045,PY-0.096,PZ+0.05); proot.rotation_euler=DRAWTILT
proot.keyframe_insert('location'); proot.keyframe_insert('rotation_euler')
sc.frame_set(63); proot.location=(PX,PY+0.06,PZ+0.06); proot.rotation_euler=DRAWTILT
proot.keyframe_insert('location'); proot.keyframe_insert('rotation_euler')
# location keys LINEAR so tip tracks the linear stroke growth (gate: tip anchoring); rotation BEZIER
for fc in proot.animation_data.action.fcurves:
    for kp in fc.keyframe_points:
        kp.interpolation='LINEAR' if fc.data_path=='location' else 'BEZIER'

# 6. camera: 3/4 macro on paper, gentle push-in
cam.data.lens=55
def look_at(obj,pt):
    d=pt-obj.location
    obj.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
tgt=Vector((PX,PY-0.005,0.033))
for f,loc in ((0,(PX+0.10,-0.23,0.21)),(40,(PX+0.08,-0.20,0.185)),(71,(PX+0.065,-0.18,0.17))):
    sc.frame_set(f); cam.location=loc; look_at(cam,tgt)
    cam.keyframe_insert('location'); cam.keyframe_insert('rotation_euler')
for f in (0,71):
    sc.frame_set(f); fo.location=tgt; fo.keyframe_insert('location')
cam.data.dof.focus_object=fo; cam.data.dof.aperture_fstop=4.5
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/draw1.blend")
print("CH4 BUILT", len(strokes), "strokes", wins[:5])
