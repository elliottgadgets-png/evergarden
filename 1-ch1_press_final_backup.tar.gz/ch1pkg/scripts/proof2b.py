import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_proof2.blend")
sc = bpy.context.scene
# camera: include right-side linkage
cam = sc.camera
cam.animation_data_clear()
cam.data.lens = 50
cam.location=(0.36,-0.62,0.38); cam.keyframe_insert("location", frame=0)
d=Vector((0.04,-0.04,0.155))-cam.location; cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler(); cam.keyframe_insert("rotation_euler", frame=0)
cam.location=(0.32,-0.56,0.35); cam.keyframe_insert("location", frame=71)
d=Vector((0.04,-0.04,0.155))-cam.location; cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler(); cam.keyframe_insert("rotation_euler", frame=71)
for fc in cam.animation_data.action.fcurves:
    for kp in fc.keyframe_points: kp.interpolation='BEZIER'
foc = bpy.data.objects["focus"]; foc.location=(0.02,-0.04,0.16)
# lift fill
bpy.data.objects["fill"].data.energy = 5
# edge wear lighter
iron = bpy.data.materials["cast_iron"].node_tree
for n in iron.nodes:
    if n.type=='VALTORGB':
        n.color_ramp.elements[1].color=(0.22,0.20,0.18,1)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_proof2b.blend")
print("PROOF2B_SAVED")
