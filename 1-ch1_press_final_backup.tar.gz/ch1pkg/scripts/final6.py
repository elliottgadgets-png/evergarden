import bpy, math
from mathutils import Vector, Matrix, Euler
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final.blend")
sc = bpy.context.scene
hinge = bpy.data.objects["platen_hinge"]
sheet = bpy.data.objects["sheet_stamped"]
print("rotmode", sheet.rotation_mode)
have_hide=False
if sheet.animation_data:
    for fc in sheet.animation_data.action.fcurves:
        print(" ", fc.data_path, fc.array_index, [(int(k.co[0]), round(k.co[1],2)) for k in fc.keyframe_points][:8])
        if 'hide' in fc.data_path: have_hide=True
print("have_hide", have_hide)
