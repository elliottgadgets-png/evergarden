import bpy, math
from mathutils import Vector, Matrix, Euler
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final.blend")
sc = bpy.context.scene
dg = bpy.context.evaluated_depsgraph_get()
hinge = bpy.data.objects["platen_hinge"]
sheet = bpy.data.objects["sheet_stamped"]

# current local pose (on platen)
loc0 = sheet.location.copy(); rot0 = sheet.rotation_euler.copy()
sheet.animation_data_clear()

# world targets for the slide-off
sc.frame_set(58)
M_hinge = hinge.matrix_world.copy()
M_on = M_hinge @ Matrix.Translation(loc0) @ rot0.to_matrix().to_4x4()
land_center = Vector((0.02,-0.30,0.036))
land_rot = Euler((0,0,math.radians(8))).to_matrix().to_4x4()
M_land = Matrix.Translation(land_center) @ land_rot
# midpoint: halfway, lifting forward+down, half-flattened
mid_center = M_on.translation.lerp(land_center, 0.5) + Vector((0,-0.03,0.02))
mid_rot = (rot0.to_matrix().lerp(Euler((0,0,math.radians(8))).to_matrix(),0.5)).to_4x4()
M_mid = Matrix.Translation(mid_center) @ mid_rot

def set_world(obj, M, f):
    sc.frame_set(f)
    L = hinge.matrix_world.inverted() @ M
    lc = L.to_translation(); rq = L.to_quaternion()
    obj.location = lc; obj.keyframe_insert("location", frame=f)
    obj.rotation_mode='QUATERNION'; obj.rotation_quaternion = rq; obj.keyframe_insert("rotation_quaternion", frame=f)

set_world(sheet, M_on, 54)
set_world(sheet, M_on, 58)
set_world(sheet, M_mid, 62)
set_world(sheet, M_land, 66)
set_world(sheet, M_land, 71)

# platen: hold 0.40 through the end
fc = hinge.animation_data.action.fcurves[0]
for kp in fc.keyframe_points:
    if kp.co[0] >= 54: kp.co[1]=0.40; kp.handle_left[1]=0.40; kp.handle_right[1]=0.40

# rake target: static, at landed sheet
tgt = bpy.data.objects["rake_target"]; tgt.parent=None
tgt.location=(0.02,-0.30,0.04)
# rake sweep across the landed sheet (grazing, from right to left)
rake = bpy.data.objects["rake"]
for f,x,y,z in ((54,0.5,-0.28,0.30),(62,0.05,-0.32,0.26),(71,-0.42,-0.28,0.22)):
    rake.location=(x,y,z)
    for fc2 in rake.animation_data.action.fcurves:
        if fc2.data_path=='location':
            [k for k in fc2.keyframe_points if k.co[0]==f][0].co[1]=(x,y,z)[fc2.array_index]

# camera end pose: high-front, aiming at landed sheet, press behind
cam = bpy.data.objects["Camera"]; act = cam.animation_data.action
end_loc=(0.28,-0.80,0.58)
d2=Vector((0.0,-0.24,0.05))-Vector(end_loc); end_rot=d2.to_track_quat('-Z','Y').to_euler()
for i,v in enumerate(end_loc):
    fcl=[c for c in act.fcurves if c.data_path=='location' and c.array_index==i][0]
    [k for k in fcl.keyframe_points if k.co[0]==71][0].co[1]=v
for i,v in enumerate(end_rot):
    fcr=[c for c in act.fcurves if c.data_path=='rotation_euler' and c.array_index==i][0]
    [k for k in fcr.keyframe_points if k.co[0]==71][0].co[1]=v
# focus empty onto landed sheet for the lock
foc = bpy.data.objects["focus"]
if foc.animation_data: foc.animation_data_clear()
foc.location=(0.02,-0.04,0.16); foc.keyframe_insert("location", frame=54)
foc.location=(0.02,-0.28,0.04); foc.keyframe_insert("location", frame=66)
foc.keyframe_insert("location", frame=71)

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final2.blend")
print("FINAL2_SAVED")
