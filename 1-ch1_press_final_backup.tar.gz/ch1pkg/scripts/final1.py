import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_proof2d.blend")
sc = bpy.context.scene

# ---------- 1. real seal: deboss on stamped sheet ----------
stampm = bpy.data.materials["paper_stamped"]; snt = stampm.node_tree
for n in list(snt.nodes):
    if n.type not in ('OUTPUT_MATERIAL','BSDF_PRINCIPLED'): snt.nodes.remove(n)
for l in list(snt.links): snt.links.remove(l)
sb = snt.nodes["Principled BSDF"]; out = snt.nodes["Material Output"]
tc = snt.nodes.new("ShaderNodeTexCoord")
mp = snt.nodes.new("ShaderNodeMapping"); mp.inputs["Scale"].default_value=(1.45,1.45,1.45); mp.inputs["Location"].default_value=(-0.225,-0.225,0)
snt.links.new(tc.outputs["Generated"], mp.inputs["Vector"])
tex = snt.nodes.new("ShaderNodeTexImage"); tex.image = bpy.data.images.load("/home/sandbox/evergarden-cine/seal.png")
snt.links.new(mp.outputs["Vector"], tex.inputs["Vector"])
# base color: bone, slightly darker warm inside recess (where seal white = pressed)
ramp = snt.nodes.new("ShaderNodeValToRGB")
ramp.color_ramp.elements[0].color=(0.78,0.74,0.66,1)   # recess tint (seal white)
ramp.color_ramp.elements[1].color=(0.87,0.84,0.78,1)   # paper bone
snt.links.new(tex.outputs["Color"], ramp.inputs[0]); snt.links.new(ramp.outputs[0], sb.inputs["Base Color"])
# deboss bump (inverted: white seal = pressed DOWN)
bump = snt.nodes.new("ShaderNodeBump"); bump.inputs["Strength"].default_value=0.4; bump.inputs["Distance"].default_value=0.002; bump.invert=True
snt.links.new(tex.outputs["Color"], bump.inputs["Height"]); snt.links.new(bump.outputs["Normal"], sb.inputs["Normal"])
snt.links.new(sb.outputs[0], out.inputs[0])

# ---------- 2. die relief: raised seal on die face ----------
die = bpy.data.objects["die"]
r = max(die.dimensions.x, die.dimensions.z)/2*0.98
brass = bpy.data.materials["brass"]
bpy.ops.mesh.primitive_cylinder_add(radius=r, depth=0.0015, location=(0,-0.0495,0.19), rotation=(math.radians(90),0,0))
rel = bpy.context.active_object; rel.name="die_relief"
rm = bpy.data.materials.new("brass_relief"); rm.use_nodes=True
rnt = rm.node_tree; rb = rnt.nodes["Principled BSDF"]
rb.inputs["Metallic"].default_value=0.9; rb.inputs["Roughness"].default_value=0.35
rb.inputs["Base Color"].default_value=(0.35,0.25,0.10,1)
rtc = rnt.nodes.new("ShaderNodeTexCoord")
rtex = rnt.nodes.new("ShaderNodeTexImage"); rtex.image = bpy.data.images["seal.png"]
rnt.links.new(rtc.outputs["Generated"], rtex.inputs["Vector"])
rbump = rnt.nodes.new("ShaderNodeBump"); rbump.inputs["Strength"].default_value=0.6; rbump.inputs["Distance"].default_value=0.0012
rnt.links.new(rtex.outputs["Color"], rbump.inputs["Height"]); rnt.links.new(rbump.outputs["Normal"], rb.inputs["Normal"])
rel.data.materials.append(rm)

# ---------- 3. rake spot: sweeps across the stamped face f44->f71 ----------
# target empty parented to hinge at sheet face
hinge = bpy.data.objects["platen_hinge"]
bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0,-0.097,0.20))
tgt = bpy.context.active_object; tgt.name="rake_target"; tgt.parent=hinge; tgt.location=(0,-0.045,0.14)
ld = bpy.data.lights.new("rake","SPOT"); ld.energy=0.0; ld.spot_size=0.85; ld.spot_blend=0.45; ld.color=(1.0,0.83,0.62)
lo = bpy.data.objects.new("rake",ld); bpy.context.scene.collection.objects.link(lo)
lo.location=(0.55,-0.30,0.34)
con = lo.constraints.new('TRACK_TO'); con.target=tgt; con.track_axis='TRACK_NEGATIVE_Z'; con.up_axis='UP_Y'
# energy keys
ld.energy=0.0; ld.keyframe_insert("energy", frame=40)
ld.energy=0.0; ld.keyframe_insert("energy", frame=44)
ld.energy=28.0; ld.keyframe_insert("energy", frame=54)
ld.energy=28.0; ld.keyframe_insert("energy", frame=71)
# sweep across face: x from +0.55 to -0.40, slightly lowering
for f,x,y,z in ((54,0.55,-0.30,0.34),(62,0.05,-0.34,0.30),(71,-0.40,-0.30,0.26)):
    lo.location=(x,y,z); lo.keyframe_insert("location", frame=f)

# ---------- 4. release/wide lift ----------
fill = bpy.data.objects["fill"].data
fill.energy=5.0; fill.keyframe_insert("energy", frame=40)
fill.energy=8.0; fill.keyframe_insert("energy", frame=54)
fill.energy=8.0; fill.keyframe_insert("energy", frame=71)
# tray/brayer separator area light
sd = bpy.data.lights.new("set_sep","AREA"); sd.energy=4.5; sd.color=(1.0,0.8,0.58); sd.size=0.35
so = bpy.data.objects.new("set_sep",sd); bpy.context.scene.collection.objects.link(so)
so.location=(-0.35,0.35,0.65); d=Vector((-0.45,0.25,0.05))-so.location; so.rotation_euler=d.to_track_quat('-Z','Y').to_euler()

# ---------- 5. camera: keep thru f54, new lock pose f71 (stamped-face legible) ----------
cam = bpy.data.objects["Camera"]; act = cam.animation_data.action
end_loc=(0.30,-0.72,0.52)
d2=Vector((0.0,-0.08,0.20))-Vector(end_loc); end_rot=d2.to_track_quat('-Z','Y').to_euler()
for i,v in enumerate(end_loc):
    fc=[c for c in act.fcurves if c.data_path=='location' and c.array_index==i][0]
    [k for k in fc.keyframe_points if k.co[0]==71][0].co[1]=v
for i,v in enumerate(end_rot):
    fc=[c for c in act.fcurves if c.data_path=='rotation_euler' and c.array_index==i][0]
    [k for k in fc.keyframe_points if k.co[0]==71][0].co[1]=v

# ---------- 6. final quality ----------
sc.cycles.samples=64
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final.blend")
print("FINAL_SAVED die_r", round(r,4))
