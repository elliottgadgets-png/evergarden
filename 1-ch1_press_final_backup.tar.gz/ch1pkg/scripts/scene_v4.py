import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v3.blend")
sc = bpy.context.scene
# exposure rebalance for sub-meter scene scale
for name, e in (("key",14),("rim",9),("fill",2.5),("practical",4)):
    bpy.data.objects[name].data.energy = e
# wall darker still
bpy.data.materials["wall"].node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value=(0.008,0.0075,0.007,1)
# iron bump only where it belongs: weaken overall so flat bed stays smooth
int_ = bpy.data.materials["cast_iron"].node_tree
for n in int_.nodes:
    if n.type=='BUMP': n.inputs["Strength"].default_value=0.3; n.inputs["Distance"].default_value=0.0012
    if n.type=='TEX_NOISE': n.inputs["Scale"].default_value=60; n.inputs["Detail"].default_value=2.5
# give the bed its own smooth iron
bed = bpy.data.objects["bed"]
smooth = bpy.data.materials.new("bed_iron"); smooth.use_nodes=True
sb = smooth.node_tree.nodes["Principled BSDF"]
sb.inputs["Base Color"].default_value=(0.05,0.047,0.045,1); sb.inputs["Metallic"].default_value=0.85; sb.inputs["Roughness"].default_value=0.5
bed.data.materials.clear(); bed.data.materials.append(smooth)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v4.blend")
print("SCENE_V4_SAVED")
