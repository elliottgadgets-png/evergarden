import bpy, math
from mathutils import Vector, Matrix, Euler
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc=bpy.context.scene
blank=bpy.data.objects["sheet"]; sheet=bpy.data.objects["sheet_stamped"]; hinge=bpy.data.objects["platen_hinge"]
sc.frame_set(42); bpy.context.view_layer.update()
M_target = blank.matrix_world.copy()
R_land = Euler((0,0,math.radians(188))).to_matrix().to_4x4() @ Euler((math.radians(90),0,0)).to_matrix().to_4x4()
land_center = Vector((0.02,-0.30,0.033))
M_land = Matrix.Translation(land_center) @ R_land
q_t = M_target.to_quaternion(); q_l = M_land.to_quaternion()

def key_pose(f, M):
    sc.frame_set(f); bpy.context.view_layer.update()
    P = hinge.matrix_world @ sheet.matrix_parent_inverse
    L = P.inverted() @ M
    sheet.location = L.to_translation()
    sheet.rotation_euler = L.to_quaternion().to_euler()
    sheet.keyframe_insert("location", frame=f)
    sheet.keyframe_insert("rotation_euler", frame=f)

act = sheet.animation_data.action
for fc in list(act.fcurves):
    if fc.data_path in ("location","rotation_euler"):
        act.fcurves.remove(fc)

key_pose(43, M_target)
key_pose(46, M_target)
M56 = Matrix.Translation(M_target.translation.lerp(land_center,0.35)+Vector((0,0,0.03))) @ (q_t.slerp(q_l,0.35)).to_matrix().to_4x4()
key_pose(56, M56)
M62 = Matrix.Translation(M_target.translation.lerp(land_center,0.68)+Vector((0,0,0.015))) @ (q_t.slerp(q_l,0.68)).to_matrix().to_4x4()
key_pose(62, M62)
key_pose(68, M_land)
key_pose(71, M_land)

# sheet_fill earlier ramp
fl = bpy.data.objects["sheet_fill"].data
fc = fl.animation_data.action.fcurves.find("energy")
while len(fc.keyframe_points)>0:
    fc.keyframe_points.remove(fc.keyframe_points[-1], fast=True)
for fr,ev in [(43,0.0),(50,6.0),(71,6.0)]:
    fc.keyframe_points.insert(fr, ev, options={'FAST'})
fc.update()
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
print("SAVED")
