import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v10.blend")
stampm = bpy.data.materials["paper_stamped"]
snt = stampm.node_tree
for n in list(snt.nodes):
    if n.type not in ('OUTPUT_MATERIAL','BSDF_PRINCIPLED'): snt.nodes.remove(n)
sb = snt.nodes["Principled BSDF"]
for l in list(snt.links):
    if l.to_node==sb and l.to_socket==sb.inputs["Base Color"]: snt.links.remove(l)
tc = snt.nodes.new("ShaderNodeTexCoord")
flat = snt.nodes.new("ShaderNodeVectorMath"); flat.operation='MULTIPLY'; flat.inputs[1].default_value=(1,0,1)
snt.links.new(tc.outputs["Generated"], flat.inputs[0])
dist = snt.nodes.new("ShaderNodeVectorMath"); dist.operation='DISTANCE'; dist.inputs[1].default_value=(0.5,0,0.5)
snt.links.new(flat.outputs[0], dist.inputs[0])
ramp = snt.nodes.new("ShaderNodeValToRGB"); ramp.color_ramp.interpolation='CONSTANT'
INK=(0.10,0.08,0.055,1); PAP=(0.85,0.82,0.76,1)
cr = ramp.color_ramp
cr.elements.remove(cr.elements[1])
for pos,col in ((0.0,INK),(0.10,PAP),(0.24,INK),(0.30,PAP)):
    e = cr.elements.new(pos) if pos>0 else cr.elements[0]
    if pos==0: e.position=0.0
    e.color=col
snt.links.new(dist.outputs["Value"], ramp.inputs[0]); snt.links.new(ramp.outputs[0], sb.inputs["Base Color"])
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v11.blend")
print("SCENE_V11_SAVED")
