import bpy, math
from mathutils import Vector, Matrix, Euler
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc=bpy.context.scene
sheet=bpy.data.objects["sheet_stamped"]; hinge=bpy.data.objects["platen_hinge"]; cam=bpy.data.objects["Camera"]

# on-platen local pose (evaluate existing key at f58)
sc.frame_set(58); bpy.context.view_layer.update()
on_loc = sheet.location.copy(); on_rot = sheet.rotation_euler.copy()

# landed world pose from existing f71 key
sc.frame_set(71); bpy.context.view_layer.update()
P71 = hinge.matrix_world @ sheet.matrix_parent_inverse
land_world = P71 @ sheet.matrix_basis.copy()

# on-platen world at f58
sc.frame_set(58)
P58 = hinge.matrix_world @ sheet.matrix_parent_inverse
on_world = P58 @ Matrix.Translation(on_loc) @ on_rot.to_matrix().to_4x4()

def set_world(f, M):
    sc.frame_set(f)
    P = hinge.matrix_world @ sheet.matrix_parent_inverse
    L = P.inverted() @ M
    sheet.location = L.to_translation()
    sheet.rotation_euler = L.to_quaternion().to_euler()
    sheet.keyframe_insert("location", frame=f)
    sheet.keyframe_insert("rotation_euler", frame=f)

# remove old keys at 62 and 66 for location/rotation
act = sheet.animation_data.action
for fc in act.fcurves:
    if fc.data_path in ("location","rotation_euler"):
        for k in list(fc.keyframe_points):
            if int(round(k.co.x)) in (62,66):
                fc.keyframe_points.remove(k)

# hold on platen until f60
sc.frame_set(60)
sheet.location = on_loc; sheet.rotation_euler = on_rot
sheet.keyframe_insert("location", frame=60); sheet.keyframe_insert("rotation_euler", frame=60)

# mid-slide at f64: lerp 0.5, slight lift
q_on = on_world.to_quaternion(); q_land = land_world.to_quaternion()
mid_center = on_world.translation.lerp(land_world.translation, 0.55) + Vector((0,0,0.02))
M_mid = Matrix.Translation(mid_center) @ (q_on.slerp(q_land,0.55)).to_matrix().to_4x4()
set_world(64, M_mid)
# land at f68
set_world(68, land_world)

# camera: finish glide at 66, hold to 71
sc.frame_set(71); bpy.context.view_layer.update()
end_loc = cam.location.copy(); end_rot = cam.rotation_euler.copy()
sc.frame_set(66)
cam.location = end_loc; cam.rotation_euler = end_rot
cam.keyframe_insert("location", frame=66); cam.keyframe_insert("rotation_euler", frame=66)
# ease: make 66-71 constant-ish by setting interpolation of segment 66->71 to linear is fine (same value => static)

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
print("SAVED")
