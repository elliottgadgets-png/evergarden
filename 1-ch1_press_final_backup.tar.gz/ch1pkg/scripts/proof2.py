# Proof 2: close-up pull->contact->release with linkage, wear, paper, set depth
import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v11.blend")
sc = bpy.context.scene

# ---------- materials: wear passes ----------
# cast iron: edge wear via Pointiness + roughness variation
iron = bpy.data.materials["cast_iron"]; nt = iron.node_tree
ib = nt.nodes["Principled BSDF"]
geo = nt.nodes.new("ShaderNodeNewGeometry")
rampw = nt.nodes.new("ShaderNodeValToRGB")
rampw.color_ramp.elements[0].position=0.55; rampw.color_ramp.elements[0].color=(0.02,0.018,0.017,1)
rampw.color_ramp.elements[1].position=0.75; rampw.color_ramp.elements[1].color=(0.16,0.15,0.14,1)
nt.links.new(geo.outputs["Pointiness"], rampw.inputs[0]); nt.links.new(rampw.outputs[0], ib.inputs["Base Color"])
# brass: oxidation patches
brass = bpy.data.materials["brass"]; bnt = brass.node_tree
bb = bnt.nodes["Principled BSDF"]
bn = bnt.nodes.new("ShaderNodeTexNoise"); bn.inputs["Scale"].default_value=6; bn.inputs["Detail"].default_value=4
br = bnt.nodes.new("ShaderNodeValToRGB")
br.color_ramp.elements[0].position=0.35; br.color_ramp.elements[0].color=(0.22,0.16,0.06,1)
br.color_ramp.elements[1].position=0.65; br.color_ramp.elements[1].color=(0.42,0.30,0.12,1)
bnt.links.new(bn.outputs["Fac"], br.inputs[0]); bnt.links.new(br.outputs[0], bb.inputs["Base Color"])
bno = bnt.nodes.new("ShaderNodeTexNoise"); bno.inputs["Scale"].default_value=9; bno.inputs["Detail"].default_value=2
brm = bnt.nodes.new("ShaderNodeMapRange"); brm.inputs["To Min"].default_value=0.25; brm.inputs["To Max"].default_value=0.55
bnt.links.new(bno.outputs["Fac"], brm.inputs[0]); bnt.links.new(brm.outputs[0], bb.inputs["Roughness"])
# steel handle: smudge roughness
steel = bpy.data.materials["steel"]; snt2 = steel.node_tree
sb2 = snt2.nodes["Principled BSDF"]
sn = snt2.nodes.new("ShaderNodeTexNoise"); sn.inputs["Scale"].default_value=12; sn.inputs["Detail"].default_value=3
srm = snt2.nodes.new("ShaderNodeMapRange"); srm.inputs["To Min"].default_value=0.15; srm.inputs["To Max"].default_value=0.45
snt2.links.new(sn.outputs["Fac"], srm.inputs[0]); snt2.links.new(srm.outputs[0], sb2.inputs["Roughness"])

def box(name, loc, scale, mat, bevel=0.0, parent=None, rot=None):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    o=bpy.context.active_object; o.name=name
    o.scale=(scale[0]/2,scale[1]/2,scale[2]/2); bpy.ops.object.transform_apply(scale=True)
    if bevel:
        md=o.modifiers.new("e",'BEVEL'); md.width=bevel; md.segments=2
    if rot: o.rotation_euler=rot
    if mat: o.data.materials.append(mat)
    if parent: o.parent=parent
    return o
def cyl(name, loc, radius, depth, mat, rot=None, bevel=0.0, parent=None, verts=32):
    bpy.ops.mesh.primitive_cylinder_add(radius=radius, depth=depth, location=loc, vertices=verts)
    o=bpy.context.active_object; o.name=name
    if bevel:
        md=o.modifiers.new("e",'BEVEL'); md.width=bevel; md.segments=2
    if rot: o.rotation_euler=rot
    if mat: o.data.materials.append(mat)
    if parent: o.parent=parent
    return o

ironm = bpy.data.materials["cast_iron"]; steelm=bpy.data.materials["steel"]
# ---------- bolts on base corners & column tops ----------
for x in (-0.125, 0.125):
    for y in (-0.085, 0.085):
        cyl("bolt", (x,y,0.032), 0.008, 0.008, steelm, bevel=0.001, verts=6)
for x in (-0.115, 0.115):
    cyl("bolt", (x,-0.048,0.27), 0.006, 0.008, steelm, rot=(math.radians(90),0,0), bevel=0.001, verts=6)

# ---------- visible linkage: crank disk on handle pivot + connecting rod to platen lug ----------
hp = bpy.data.objects["handle_pivot"]
crank = cyl("crank", (0.145,-0.01,0.24), 0.038, 0.012, ironm, rot=(0,math.radians(90),0), bevel=0.002)
# lug on platen arm (right side), parented to hinge
hinge = bpy.data.objects["platen_hinge"]
lug = box("platen_lug", (0,0,0), (0.02,0.02,0.05), ironm, bevel=0.002, parent=hinge)
lug.location = (0.045, 0.0, 0.045)
# connecting rod (baked per keyframe)
rod = cyl("con_rod", (0.14,0,0.15), 0.006, 0.15, steelm, bevel=0.001)

# ---------- animation remap: 72 frames ----------
sc.frame_start=0; sc.frame_end=71; sc.render.fps=24
hinge.rotation_euler[0]=0.35
# clear old keys
hinge.animation_data_clear(); hp.animation_data_clear()
pl_keys=[(0,0.35),(12,0.35),(30,0.02),(40,0.02),(54,0.60),(71,0.60)]
hn_keys=[(0,-0.25),(12,-0.25),(30,0.55),(40,0.55),(54,-0.25),(71,-0.25)]
for f,v in pl_keys:
    hinge.rotation_euler[0]=v; hinge.keyframe_insert("rotation_euler", index=0, frame=f)
for f,v in hn_keys:
    hp.rotation_euler[1]=v; hp.keyframe_insert("rotation_euler", index=1, frame=f)
for o in (hinge,hp):
    for fc in o.animation_data.action.fcurves:
        for kp in fc.keyframe_points: kp.interpolation='BEZIER'

# bake rod between crank pin and lug world positions
PIV=Vector((0.145,-0.01,0.24)); CRANK_R=0.030
hinge_loc=Vector(hinge.location)
def pin_world(a):
    ang = -math.pi/2 + a
    return PIV + Vector((math.sin(ang)*CRANK_R, -0.018, -math.cos(ang)*CRANK_R))
def lug_world(b):
    c, s = math.cos(b), math.sin(b)
    local = Vector((0.045, 0.0, 0.045))
    # rotate about X by b: y' = y c - z s, z' = y s + z c
    yr = local.y*c - local.z*s; zr = local.y*s + local.z*c
    return hinge_loc + Vector((local.x, yr, zr))
for f,a,b in [(f, next(v for ff,v in hn_keys if ff>=f) if f<30 else None, None) for f in []]:
    pass
# simple: sample keys directly at boundaries
import numpy as np
def interp(keys, f):
    ks=sorted(keys)
    if f<=ks[0][0]: return ks[0][1]
    if f>=ks[-1][0]: return ks[-1][1]
    for (f0,v0),(f1,v1) in zip(ks,ks[1:]):
        if f0<=f<=f1:
            t=(f-f0)/(f1-f0); return v0+(v1-v0)*t
for f in range(0,72,3):
    a=interp(hn_keys,f); b=interp(pl_keys,f)
    p1=pin_world(a); p2=lug_world(b)
    mid=(p1+p2)/2; d=p2-p1; L=d.length
    rod.location=mid
    rod.scale=(1,1,L/0.15)
    rod.rotation_euler=d.to_track_quat('Z','Y').to_euler()
    rod.keyframe_insert("location", frame=f); rod.keyframe_insert("rotation_euler", frame=f); rod.keyframe_insert("scale", frame=f)
for fc in rod.animation_data.action.fcurves:
    for kp in fc.keyframe_points: kp.interpolation='LINEAR'

# ---------- paper: thickness + curl + squash + deboss on stamped ----------
paperm = bpy.data.materials["paper"]
for nm in ("sheet","sheet_stamped"):
    o=bpy.data.objects[nm]
    o.scale.y = 1.5  # 3mm thick
# curl: slight bend via lattice-free approach - skip deform, add rotated top edge? keep simple: skip curl for now
# squash at contact on both sheets
for nm in ("sheet","sheet_stamped"):
    o=bpy.data.objects[nm]
    o.animation_data_clear()
    for f,sy in [(0,1.5),(12,1.5),(30,1.5),(33,1.15),(40,1.15),(44,1.5),(71,1.5)]:
        o.scale.y=sy; o.keyframe_insert("scale", frame=f, index=1)
    for fc in o.animation_data.action.fcurves:
        for kp in fc.keyframe_points: kp.interpolation='BEZIER'
# deboss bump on stamped sheet from emblem ramp
sm = bpy.data.materials["paper_stamped"]; smt = sm.node_tree
dist_node = ramp_node = None
for n in smt.nodes:
    if n.type=='VECT_MATH' and n.operation=='DISTANCE': dist_node=n
    if n.type=='VALTORGB': ramp_node=n
if dist_node is not None:
    bump = smt.nodes.new("ShaderNodeBump"); bump.inputs["Strength"].default_value=0.4; bump.inputs["Distance"].default_value=0.0008
    bump.invert = True
    smt.links.new(dist_node.outputs["Value"], bump.inputs["Height"])
    smt.links.new(bump.outputs["Normal"], smt.nodes["Principled BSDF"].inputs["Normal"])
# paper fiber: fine noise bump on both papers
for mname in ("paper","paper_stamped"):
    m=bpy.data.materials[mname]; mnt=m.node_tree; mb=mnt.nodes["Principled BSDF"]
    mn=mnt.nodes.new("ShaderNodeTexNoise"); mn.inputs["Scale"].default_value=180; mn.inputs["Detail"].default_value=2
    mb2=mnt.nodes.new("ShaderNodeBump"); mb2.inputs["Strength"].default_value=0.15; mb2.inputs["Distance"].default_value=0.0003
    mnt.links.new(mn.outputs["Fac"], mb2.inputs["Height"])
    # chain into existing normal if present
    existing = [l for l in mnt.links if l.to_socket==mb.inputs["Normal"]]
    if existing:
        src = existing[0].from_socket
        mnt.links.remove(existing[0])
        mnt.links.new(src, mb2.inputs["Normal"])
    mnt.links.new(mb2.outputs["Normal"], mb.inputs["Normal"])
# visibility keys re-add (cleared with anim data): plain until 40, stamped after 44
plain=bpy.data.objects["sheet"]; st=bpy.data.objects["sheet_stamped"]
def vis(o, tl):
    for f,v in tl:
        o.hide_render=v; o.keyframe_insert("hide_render", frame=f)
vis(plain, [(0,False),(42,False),(43,True),(71,True)])
vis(st, [(0,True),(42,True),(43,False),(71,False)])

# ---------- lighting: lift structure, keep mood ----------
for name,e in (("key",16),("rim",11),("fill",3),("practical",6)):
    bpy.data.objects[name].data.energy=e
bpy.ops.object.light_add(type='AREA', location=(0,0.1,1.15))
top=bpy.context.active_object; top.name="top"
top.data.energy=9; top.data.color=(0.95,0.97,1.0); top.data.shape='DISK'; top.data.size=0.5
d=Vector((0,0,0.15))-top.location; top.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
sc.world.node_tree.nodes["Background"].inputs[0].default_value=(0.004,0.004,0.005,1)
sc.world.node_tree.nodes["Background"].inputs[1].default_value=1.0

# ---------- set dressing ----------
# paper stack tray back-left
tray = box("tray", (-0.34,0.22,0.012), (0.22,0.30,0.015), ironm, bevel=0.003)
for i in range(4):
    s=box("stack_sheet", (-0.34+0.004*i,0.22-0.003*i,0.024+0.003*i), (0.19,0.27,0.0025), paperm, bevel=0.001, rot=(0,0,0.02*i))
# brayer right
cyl("brayer_roll", (0.33,0.12,0.035), 0.028, 0.11, bpy.data.materials["grip_wood"], rot=(math.radians(90),0,0), bevel=0.003)
cyl("brayer_axle", (0.33,0.12,0.035), 0.006, 0.15, steelm, rot=(math.radians(90),0,0))
box("brayer_handle", (0.33,0.21,0.05), (0.03,0.09,0.03), bpy.data.materials["grip_wood"], bevel=0.008, rot=(0.3,0,0))
# background glow panel (warm, will blur with DOF)
glowm = bpy.data.materials.new("glow"); glowm.use_nodes=True
ge = glowm.node_tree.nodes["Principled BSDF"]
ge.inputs["Emission Color"].default_value=(1.0,0.55,0.25,1); ge.inputs["Emission Strength"].default_value=2.5
ge.inputs["Base Color"].default_value=(0,0,0,1)
box("bg_glow", (0.45,1.15,0.75), (0.35,0.02,0.5), glowm)

# ---------- camera: close-up with DOF ----------
cam = sc.camera
cam.animation_data_clear()
cam.data.lens=55
cam.location=(0.30,-0.52,0.36); cam.keyframe_insert("location", frame=0)
d=Vector((0.0,-0.045,0.155))-cam.location; cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler(); cam.keyframe_insert("rotation_euler", frame=0)
cam.location=(0.26,-0.46,0.33); cam.keyframe_insert("location", frame=71)
d=Vector((0.0,-0.045,0.155))-cam.location; cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler(); cam.keyframe_insert("rotation_euler", frame=71)
for fc in cam.animation_data.action.fcurves:
    for kp in fc.keyframe_points: kp.interpolation='BEZIER'
# DOF
foc = bpy.data.objects.new("focus", None); bpy.context.collection.objects.link(foc)
foc.location=(0,-0.045,0.155)
cam.data.dof.use_dof=True; cam.data.dof.focus_object=foc; cam.data.dof.aperture_fstop=2.8

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_proof2.blend")
print("PROOF2_SAVED")
