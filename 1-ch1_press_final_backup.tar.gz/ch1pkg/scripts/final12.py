import bpy, math
from mathutils import Vector, Matrix, Euler
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc=bpy.context.scene
sheet=bpy.data.objects["sheet_stamped"]; hinge=bpy.data.objects["platen_hinge"]
# recompute corrected mid pose (lower, stays in frame)
sc.frame_set(54); bpy.context.view_layer.update()
P = hinge.matrix_world @ sheet.matrix_parent_inverse
M_on_world = P @ sheet.matrix_basis.copy()
R_land = Euler((0,0,math.radians(188))).to_matrix().to_4x4() @ Euler((math.radians(90),0,0)).to_matrix().to_4x4()
q_on = M_on_world.to_quaternion(); q_land = R_land.to_quaternion()
land_center = Vector((0.02,-0.30,0.033))
mid_center = M_on_world.translation.lerp(land_center,0.68) + Vector((0,-0.01,0.012))
M_mid_world = Matrix.Translation(mid_center) @ (q_on.slerp(q_land,0.68)).to_matrix().to_4x4()
L = P.inverted() @ M_mid_world
sheet.location=L.to_translation(); sheet.rotation_euler=L.to_quaternion().to_euler()
sheet.keyframe_insert("location", frame=62); sheet.keyframe_insert("rotation_euler", frame=62)
# seal contrast
m=bpy.data.materials["paper_stamped"]; nt=m.node_tree
ramp=[n for n in nt.nodes if n.type=='VALTORGB'][0]
ramp.color_ramp.elements[1].color=(0.45,0.40,0.33,1)
bump=[n for n in nt.nodes if n.type=='BUMP'][0]
bump.inputs["Strength"].default_value=0.45
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
print("SAVED")
