import bpy
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v4.blend")
sc = bpy.context.scene
sc.view_settings.look = 'AgX - Medium High Contrast'
# darker still
for name, e in (("key",10),("rim",6),("fill",1.5),("practical",3)):
    bpy.data.objects[name].data.energy = e
# key more lateral for modeling
K = bpy.data.objects["key"]; K.location = (0.85,-0.25,0.75)
d = Vector((0,0,0.18)) - K.location; K.rotation_euler = d.to_track_quat('-Z','Y').to_euler()
# wall back and near-black
wall = bpy.data.objects["wall"]; wall.location.y = 1.2
bpy.data.materials["wall"].node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value=(0.004,0.004,0.0035,1)
# wood much darker
wnt = bpy.data.materials["bench_wood"].node_tree
for n in wnt.nodes:
    if n.type=='MIX': n.inputs["B"].default_value=(0.30,0.21,0.16,1)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v5.blend")
print("SCENE_V5_SAVED")
