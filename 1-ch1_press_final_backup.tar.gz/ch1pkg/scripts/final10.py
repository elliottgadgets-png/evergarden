import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
m=bpy.data.materials["paper_stamped"]; nt=m.node_tree
bump=[n for n in nt.nodes if n.type=='BUMP'][0]
for l in list(nt.links):
    if l.to_node==bump or l.from_node==bump: nt.links.remove(l)
bump.inputs["Strength"].default_value=0.3; bump.inputs["Distance"].default_value=0.001
tex=[n for n in nt.nodes if n.type=='TEX_IMAGE'][0]
sb=nt.nodes["Principled BSDF"]
nt.links.new(tex.outputs["Color"], bump.inputs["Height"]); nt.links.new(bump.outputs["Normal"], sb.inputs["Normal"])
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc=bpy.context.scene
sc.render.engine='CYCLES'; sc.cycles.samples=12; sc.cycles.use_denoising=True
sc.render.resolution_x=390; sc.render.resolution_y=844
sc.frame_set(71); sc.render.filepath='/tmp/pf10_f071.png'; bpy.ops.render.render(write_still=True)
print("DONE")
