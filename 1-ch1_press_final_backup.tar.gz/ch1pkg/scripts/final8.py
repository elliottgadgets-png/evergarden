import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
stampm = bpy.data.materials["paper_stamped"]; snt = stampm.node_tree
ramp = [n for n in snt.nodes if n.type=='VALTORGB'][0]
ramp.color_ramp.elements[0].color=(0.80,0.77,0.71,1)   # tex black = paper bone
ramp.color_ramp.elements[1].color=(0.52,0.47,0.40,1)   # tex white = pressed recess
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc=bpy.context.scene
sc.render.engine='CYCLES'; sc.cycles.samples=16; sc.cycles.use_denoising=True
sc.render.resolution_x=390; sc.render.resolution_y=844
sc.frame_set(71); sc.render.filepath='/tmp/pf8_f071.png'; bpy.ops.render.render(write_still=True)
print("DONE")
