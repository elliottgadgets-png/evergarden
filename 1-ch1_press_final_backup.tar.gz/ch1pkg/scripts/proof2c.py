import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_proof2b.blend")
hinge = bpy.data.objects["platen_hinge"]
fc = hinge.animation_data.action.fcurves[0]
for kp in fc.keyframe_points:
    if kp.co[0] >= 54: kp.co[1]=0.40; kp.handle_left[1]=0.40; kp.handle_right[1]=0.40
g = bpy.data.objects["bg_glow"]; g.location=(-0.55,1.05,0.85); g.scale=(1.4,1,1.2)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_proof2c.blend")
print("PROOF2C_SAVED")
