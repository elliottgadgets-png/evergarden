# Tabletop platen letterpress v2 - working face toward camera (-Y)
import bpy, math
from mathutils import Vector

def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)

def mat_principled(name, color, metallic=0.0, rough=0.5):
    m = bpy.data.materials.new(name); m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*color, 1)
    b.inputs["Metallic"].default_value = metallic
    b.inputs["Roughness"].default_value = rough
    return m

def box(name, loc, scale, mat, bevel=0.004, parent=None):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    o = bpy.context.active_object; o.name = name
    o.scale = (scale[0]/2, scale[1]/2, scale[2]/2)
    bpy.ops.object.transform_apply(scale=True)
    if bevel:
        md = o.modifiers.new("edge", 'BEVEL'); md.width = bevel; md.segments = 2
    if mat: o.data.materials.append(mat)
    if parent: o.parent = parent
    return o

def cyl(name, loc, radius, depth, mat, rot=None, bevel=0.002, parent=None, verts=48):
    bpy.ops.mesh.primitive_cylinder_add(radius=radius, depth=depth, location=loc, vertices=verts)
    o = bpy.context.active_object; o.name = name
    if bevel:
        md = o.modifiers.new("edge", 'BEVEL'); md.width = bevel; md.segments = 2
    if rot: o.rotation_euler = rot
    if mat: o.data.materials.append(mat)
    if parent: o.parent = parent
    return o

def empty(name, loc):
    o = bpy.data.objects.new(name, None)
    bpy.context.collection.objects.link(o); o.location = loc
    return o

reset()
iron  = mat_principled("cast_iron", (0.052, 0.048, 0.046), metallic=0.85, rough=0.45)
brass = mat_principled("brass", (0.35, 0.22, 0.08), metallic=1.0, rough=0.3)
steel = mat_principled("steel", (0.18, 0.18, 0.19), metallic=1.0, rough=0.25)
wood  = mat_principled("grip_wood", (0.16, 0.07, 0.03), rough=0.55)
paperm= mat_principled("paper", (0.85, 0.82, 0.76), rough=0.9)

# base & frame (static)
box("base", (0,0,0.015), (0.30,0.22,0.03), iron, bevel=0.008)
box("colL", (-0.115,0,0.16), (0.035,0.10,0.26), iron, bevel=0.006)
box("colR", ( 0.115,0,0.16), (0.035,0.10,0.26), iron, bevel=0.006)
box("bridge", (0,0,0.295), (0.265,0.10,0.035), iron, bevel=0.006)
cyl("inkdisk", (0,0,0.325), 0.085, 0.014, iron, bevel=0.003)
cyl("inkface", (0,0,0.333), 0.075, 0.004, steel, bevel=0.001)
# type bed faces CAMERA (-Y)
box("bed", (0,-0.028,0.19), (0.16,0.02,0.17), iron, bevel=0.004)
cyl("die", (0,-0.042,0.19), 0.045, 0.008, brass, rot=(math.radians(90),0,0), bevel=0.001)

# platen assembly hinged low, in front of bed; +X-rotation tilts top toward camera
hinge = empty("platen_hinge", (0,-0.058,0.06))
arm = box("platen_arm", (0,0,0.075), (0.05,0.03,0.15), iron, bevel=0.005, parent=hinge)
arm.location = (0,0,0.075)
pl = box("platen", (0,0,0.15), (0.17,0.018,0.19), iron, bevel=0.004, parent=hinge)
pl.location = (0,0,0.15)
sh = box("sheet", (0,-0.011,0.15), (0.13,0.002,0.15), paperm, bevel=0.001, parent=hinge)
sh.location = (0,-0.011,0.15)

# handle on right: idle raised, pulls DOWN on press
hp = empty("handle_pivot", (0.135,0,0.24))
a = cyl("handle_arm", (0.055,0,0), 0.011, 0.16, steel, rot=(0,math.radians(90),0), parent=hp); a.location=(0.055,0,0)
g = cyl("handle_grip", (0.14,0,0), 0.016, 0.07, wood, rot=(0,math.radians(90),0), parent=hp); g.location=(0.14,0,0)

# flywheel left
cyl("flywheel", (-0.145,0,0.22), 0.075, 0.02, iron, rot=(0,math.radians(90),0), bevel=0.004)
cyl("flyhub", (-0.158,0,0.22), 0.018, 0.03, brass, rot=(0,math.radians(90),0))

sc = bpy.context.scene
sc.frame_start = 0; sc.frame_end = 119; sc.render.fps = 24

# platen: open 24deg toward camera, closed 0
pl_keys = [(0,0.42),(30,0.42),(52,0.02),(70,0.02),(92,0.42),(119,0.42)]
hn_keys = [(0,-0.25),(30,-0.25),(52,0.55),(70,0.55),(92,-0.25),(119,-0.25)]
for f,v in pl_keys:
    hinge.rotation_euler[0] = v
    hinge.keyframe_insert("rotation_euler", index=0, frame=f)
for f,v in hn_keys:
    hp.rotation_euler[1] = v
    hp.keyframe_insert("rotation_euler", index=1, frame=f)
for o in (hinge, hp):
    for fc in o.animation_data.action.fcurves:
        for kp in fc.keyframe_points: kp.interpolation='BEZIER'

# camera: whole press in frame, slight push-in
bpy.ops.object.camera_add(location=(0.42,-0.98,0.52))
cam = bpy.context.active_object; sc.camera = cam
d = Vector((0,0,0.17)) - cam.location
cam.rotation_euler = d.to_track_quat('-Z','Y').to_euler()
cam.data.lens = 50
cam.location = (0.48,-1.08,0.56); cam.keyframe_insert("location", frame=0)
cam.location = (0.38,-0.88,0.47); cam.keyframe_insert("location", frame=119)
d = Vector((0,0,0.17)) - cam.location
cam.rotation_euler = d.to_track_quat('-Z','Y').to_euler()
for fc in cam.animation_data.action.fcurves:
    for kp in fc.keyframe_points: kp.interpolation='BEZIER'

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_v2.blend")
print("PRESS_V2_SAVED")
