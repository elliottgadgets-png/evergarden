import bpy, sys, os
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc=bpy.context.scene
sc.render.engine='CYCLES'; sc.cycles.device='CPU'; sc.cycles.samples=64; sc.cycles.use_denoising=True; sc.cycles.use_adaptive_sampling=True; sc.cycles.adaptive_threshold=0.02; sc.cycles.adaptive_min_samples=16
sc.render.resolution_x=390; sc.render.resolution_y=844; sc.render.resolution_percentage=100
frames=[int(x) for x in sys.argv[sys.argv.index('--')+1:]]
for f in frames:
    p=f'/home/sandbox/evergarden-cine/frames_final/f{f:03d}.png'
    os.makedirs('/home/sandbox/evergarden-cine/frames_final', exist_ok=True)
    if os.path.exists(p): continue
    sc.frame_set(f)
    sc.render.filepath=p
    bpy.ops.render.render(write_still=True)
print("DONE", frames)
