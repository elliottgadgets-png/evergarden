import bpy, math
from mathutils import Vector, Matrix, Euler
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final2.blend")
sc = bpy.context.scene
hinge = bpy.data.objects["platen_hinge"]
sheet = bpy.data.objects["sheet_stamped"]
sheet.animation_data_clear()
sheet.rotation_mode='XYZ'
sheet.hide_render=True; sheet.keyframe_insert("hide_render", frame=0); sheet.keyframe_insert("hide_render", frame=42)
sheet.hide_render=False; sheet.keyframe_insert("hide_render", frame=43); sheet.keyframe_insert("hide_render", frame=71)

sc.frame_set(54); bpy.context.view_layer.update()
M_on = sheet.matrix_world.copy()

# flat on bench, FACE UP: tip the vertical card backward 90 deg about X
Rx = Euler((math.radians(-90),0,0)).to_matrix().to_4x4()
yaw = Euler((0,0,math.radians(8))).to_matrix().to_4x4()
land_center = Vector((0.02,-0.30,0.033))
M_land = Matrix.Translation(land_center) @ yaw @ Rx @ (M_on.to_quaternion().to_matrix().to_4x4())
mid_center = M_on.translation.lerp(land_center,0.55) + Vector((0,-0.02,0.03))
M_mid = Matrix.Translation(mid_center) @ (M_on.to_quaternion().slerp(M_land.to_quaternion(),0.55)).to_matrix().to_4x4()

def key_world(M,f):
    sc.frame_set(f); bpy.context.view_layer.update()
    P = hinge.matrix_world @ sheet.matrix_parent_inverse
    L = P.inverted() @ M
    sheet.location=L.to_translation(); sheet.rotation_euler=L.to_quaternion().to_euler()
    sheet.keyframe_insert("location",frame=f); sheet.keyframe_insert("rotation_euler",frame=f)

for f,M in ((54,M_on),(58,M_on),(62,M_mid),(66,M_land),(71,M_land)):
    key_world(M,f)
# gentle squash after landing for tactile settle
sheet.scale=(1,1,1); sheet.keyframe_insert("scale",frame=54); sheet.keyframe_insert("scale",frame=62)
sheet.scale=(1,0.85,1); sheet.keyframe_insert("scale",frame=66)
sheet.scale=(1,1,1); sheet.keyframe_insert("scale",frame=71)

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final2.blend")
sc.frame_set(71); bpy.context.view_layer.update()
facedir = sheet.matrix_world.to_3x3() @ Vector((0,1,0))
print("verify face->", tuple(round(v,2) for v in facedir), "pos", tuple(round(v,3) for v in sheet.matrix_world.translation))
sc.render.engine='CYCLES'; sc.cycles.samples=16; sc.cycles.use_denoising=True
sc.render.resolution_x=390; sc.render.resolution_y=844
sc.render.filepath='/tmp/pf5_f071.png'
bpy.ops.render.render(write_still=True); print("DONE")
