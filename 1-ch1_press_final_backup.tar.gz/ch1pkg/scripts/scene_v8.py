import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v7.blend")
sc = bpy.context.scene

# 1) cleaner stamp: wave-texture concentric rings
stampm = bpy.data.materials["paper_stamped"]
snt = stampm.node_tree
for n in list(snt.nodes):
    if n.type not in ('OUTPUT_MATERIAL','BSDF_PRINCIPLED'): snt.nodes.remove(n)
sb = snt.nodes["Principled BSDF"]
for l in list(snt.links):
    if l.to_node==sb and l.to_socket==sb.inputs["Base Color"]: snt.links.remove(l)
tc = snt.nodes.new("ShaderNodeTexCoord")
wave = snt.nodes.new("ShaderNodeTexWave"); wave.wave_type='RINGS'; wave.rings_direction='Z'
wave.inputs["Scale"].default_value=28.0; wave.inputs["Distortion"].default_value=0.0; wave.inputs["Detail"].default_value=0.0
snt.links.new(tc.outputs["Generated"], wave.inputs["Vector"])
ramp = snt.nodes.new("ShaderNodeValToRGB")
ramp.color_ramp.interpolation='CONSTANT'
e0 = ramp.color_ramp.elements[0]; e0.position=0.42; e0.color=(0.85,0.82,0.76,1)
e1 = ramp.color_ramp.elements[1]; e1.position=0.5; e1.color=(0.12,0.09,0.06,1)
snt.links.new(wave.outputs["Color"], ramp.inputs[0]); snt.links.new(ramp.outputs[0], sb.inputs["Base Color"])
sb.inputs["Roughness"].default_value=0.92

# 2) end pose: less tilt, camera higher and looking into open platen
hinge = bpy.data.objects["platen_hinge"]
fc = hinge.animation_data.action.fcurves[0]
for kp in fc.keyframe_points:
    if kp.co[0] >= 92: kp.co[1] = 0.34; kp.handle_right[1]=0.34
cam = sc.camera
for kp in cam.animation_data.action.fcurves[2].keyframe_points:  # Z
    if kp.co[0]==119: kp.co[1]=0.60; kp.handle_left[1]=0.60
# retarget camera aim via track-quat at end frame: adjust rotation keys
cam.animation_data_clear()
cam.location=(0.48,-1.08,0.56); cam.keyframe_insert("location", frame=0)
d=Vector((0,0,0.17))-cam.location; cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler(); cam.keyframe_insert("rotation_euler", frame=0)
cam.location=(0.34,-0.80,0.60); cam.keyframe_insert("location", frame=119)
d=Vector((0,-0.03,0.20))-cam.location; cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler(); cam.keyframe_insert("rotation_euler", frame=119)
for fc in cam.animation_data.action.fcurves:
    for kp in fc.keyframe_points: kp.interpolation='BEZIER'

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v8.blend")
print("SCENE_V8_SAVED")
