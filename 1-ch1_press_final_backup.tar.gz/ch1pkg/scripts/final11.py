import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
m=bpy.data.materials["paper_stamped"]; nt=m.node_tree
for n in list(nt.nodes): nt.nodes.remove(n)
out = nt.nodes.new("ShaderNodeOutputMaterial")
sb = nt.nodes.new("ShaderNodeBsdfPrincipled")
sb.inputs["Roughness"].default_value=0.85
tc = nt.nodes.new("ShaderNodeTexCoord")
sep = nt.nodes.new("ShaderNodeSeparateXYZ"); nt.links.new(tc.outputs["Generated"], sep.inputs[0])
comb = nt.nodes.new("ShaderNodeCombineXYZ")
nt.links.new(sep.outputs["X"], comb.inputs["X"]); nt.links.new(sep.outputs["Z"], comb.inputs["Y"])
mp = nt.nodes.new("ShaderNodeMapping"); mp.inputs["Scale"].default_value=(1.35,1.35,1); mp.inputs["Location"].default_value=(-0.175,-0.175,0)
nt.links.new(comb.outputs[0], mp.inputs["Vector"])
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = bpy.data.images["seal.png"]
nt.links.new(mp.outputs["Vector"], tex.inputs["Vector"])
ramp = nt.nodes.new("ShaderNodeValToRGB")
ramp.color_ramp.elements[0].color=(0.80,0.77,0.71,1)
ramp.color_ramp.elements[1].color=(0.52,0.47,0.40,1)
nt.links.new(tex.outputs["Color"], ramp.inputs[0]); nt.links.new(ramp.outputs[0], sb.inputs["Base Color"])
bump = nt.nodes.new("ShaderNodeBump"); bump.inputs["Strength"].default_value=0.35; bump.inputs["Distance"].default_value=0.0012; bump.invert=True
nt.links.new(tex.outputs["Color"], bump.inputs["Height"]); nt.links.new(bump.outputs["Normal"], sb.inputs["Normal"])
nt.links.new(sb.outputs[0], out.inputs[0])
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc=bpy.context.scene
sc.render.engine='CYCLES'; sc.cycles.samples=16; sc.cycles.use_denoising=True
sc.render.resolution_x=390; sc.render.resolution_y=844
sc.frame_set(71); sc.render.filepath='/tmp/pf11_f071.png'; bpy.ops.render.render(write_still=True)
sc.frame_set(62); sc.render.filepath='/tmp/pf11_f062.png'; bpy.ops.render.render(write_still=True)
print("DONE")
