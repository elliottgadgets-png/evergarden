import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v5.blend")
sc = bpy.context.scene
# bench reaches the wall: deeper, shifted back
bench = bpy.data.objects["bench"]
bench.scale.y = 2.0; bench.location.y = 0.45
# cooler, darker wood
wnt = bpy.data.materials["bench_wood"].node_tree
for n in wnt.nodes:
    if n.type=='MIX': n.inputs["B"].default_value=(0.34,0.28,0.24,1)
# key slightly less orange
bpy.data.objects["key"].data.color = (1.0,0.92,0.82)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v6.blend")
print("SCENE_V6_SAVED")
