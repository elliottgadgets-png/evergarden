import bpy, math
from mathutils import Vector, Matrix, Euler
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final2.blend")
sc = bpy.context.scene
hinge = bpy.data.objects["platen_hinge"]
sheet = bpy.data.objects["sheet_stamped"]
print("parent_inverse:", sheet.matrix_parent_inverse)
print("rotmode:", sheet.rotation_mode, "basis:", sheet.matrix_basis)

# wipe all sheet anim incl hide; rekey everything cleanly
sheet.animation_data_clear()
sheet.rotation_mode='XYZ'
# hide keys
sheet.hide_render=True; sheet.keyframe_insert("hide_render", frame=0); sheet.keyframe_insert("hide_render", frame=42)
sheet.hide_render=False; sheet.keyframe_insert("hide_render", frame=43); sheet.keyframe_insert("hide_render", frame=71)

def world_to_local_keys(M_world, f):
    sc.frame_set(f)
    bpy.context.view_layer.update()
    P = hinge.matrix_world @ sheet.matrix_parent_inverse
    L = P.inverted() @ M_world
    sheet.location = L.to_translation()
    sheet.rotation_euler = L.to_quaternion().to_euler()
    sheet.keyframe_insert("location", frame=f)
    sheet.keyframe_insert("rotation_euler", frame=f)

# on-platen pose: read current world matrix at f54 BEFORE rekeying
sc.frame_set(54); bpy.context.view_layer.update()
M_on = sheet.matrix_world.copy()
print("M_on:", M_on)
land_center = Vector((0.02,-0.30,0.036))
M_land = Matrix.Translation(land_center) @ Euler((0,0,math.radians(8))).to_matrix().to_4x4()
mid_center = M_on.translation.lerp(land_center,0.5) + Vector((0,-0.02,0.03))
M_mid = Matrix.Translation(mid_center) @ (M_on.to_quaternion().lerp(M_land.to_quaternion(),0.5)).to_matrix().to_4x4()
for f,M in ((54,M_on),(58,M_on),(62,M_mid),(66,M_land),(71,M_land)):
    world_to_local_keys(M,f)

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final2.blend")
# in-session verification render
sc.frame_set(71); bpy.context.view_layer.update()
print("verify world:", tuple(round(v,3) for v in sheet.matrix_world.translation), tuple(round(v,2) for v in (sheet.matrix_world.to_3x3()@Vector((0,0,1)))))
sc.render.engine='CYCLES'; sc.cycles.samples=16; sc.cycles.use_denoising=True
sc.render.resolution_x=390; sc.render.resolution_y=844
sc.render.filepath='/tmp/pf3_f071.png'
bpy.ops.render.render(write_still=True)
print("DONE")
