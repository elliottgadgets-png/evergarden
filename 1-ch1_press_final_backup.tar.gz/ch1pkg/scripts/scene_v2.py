import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v1.blend")
sc = bpy.context.scene

# wood grain: smaller, finer
wnt = bpy.data.materials["bench_wood"].node_tree
for n in wnt.nodes:
    if n.type == 'MAPPING': n.inputs["Scale"].default_value = (5.0, 5.0, 1.0)

# wall: near-black, matte
wl = bpy.data.materials["wall"].node_tree.nodes["Principled BSDF"]
wl.inputs["Base Color"].default_value = (0.012, 0.011, 0.010, 1)

# lights: hard moody ratio - warm key high right, faint cool rim, near-zero fill
K = bpy.data.objects["key"]; R = bpy.data.objects["rim"]; F = bpy.data.objects["fill"]
K.data.energy = 90; K.data.size = 0.35
R.data.energy = 70; R.data.size = 0.3
F.data.energy = 5
sc.world.node_tree.nodes["Background"].inputs[1].default_value = 0.5

# subtle warm point as practical glow behind press
bpy.ops.object.light_add(type='POINT', location=(0.05, 0.25, 0.45))
p = bpy.context.active_object; p.name="practical"
p.data.energy = 8; p.data.color = (1.0, 0.6, 0.3); p.data.shadow_soft_size = 0.1

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v2.blend")
print("SCENE_V2_SAVED")
