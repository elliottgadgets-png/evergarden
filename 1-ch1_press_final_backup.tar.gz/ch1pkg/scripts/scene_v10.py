import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v9.blend")
snt = bpy.data.materials["paper_stamped"].node_tree
for n in snt.nodes:
    if n.type=='TEX_WAVE':
        n.rings_direction='Y'; n.inputs["Scale"].default_value=22.0
    if n.type=='VALTORGB':
        n.color_ramp.elements[0].position=0.46
        n.color_ramp.elements[1].position=0.54
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v10.blend")
print("SCENE_V10_SAVED")
