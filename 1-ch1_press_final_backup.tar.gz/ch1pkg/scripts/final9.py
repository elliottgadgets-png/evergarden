import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc=bpy.context.scene
# rake: raise for 25-30deg graze with real diffuse contribution
rake = bpy.data.objects["rake"]
vals={54:(0.45,-0.34,0.34),62:(0.0,-0.38,0.30),71:(-0.40,-0.34,0.26)}
for fc in rake.animation_data.action.fcurves:
    if fc.data_path=='location':
        for k in fc.keyframe_points:
            if k.co[0] in vals:
                k.co[1]=vals[k.co[0]][fc.array_index]; k.handle_left[1]=k.co[1]; k.handle_right[1]=k.co[1]
# dedicated sheet fill, keyed on for release only
sd = bpy.data.lights.new("sheet_fill","AREA"); sd.energy=0.0; sd.color=(1.0,0.85,0.66); sd.size=0.25
so = bpy.data.objects.new("sheet_fill",sd); sc.collection.objects.link(so)
so.location=(0.05,-0.55,0.42)
d=Vector((0.02,-0.29,0.03))-so.location; so.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
sd.energy=0.0; sd.keyframe_insert("energy", frame=44)
sd.energy=6.0; sd.keyframe_insert("energy", frame=54); sd.keyframe_insert("energy", frame=71)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc.render.engine='CYCLES'; sc.cycles.samples=16; sc.cycles.use_denoising=True
sc.render.resolution_x=390; sc.render.resolution_y=844
sc.frame_set(71); sc.render.filepath='/tmp/pf9_f071.png'; bpy.ops.render.render(write_still=True)
print("DONE")
