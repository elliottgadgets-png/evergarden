import bpy, math
from mathutils import Vector, Matrix, Euler
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final.blend")
sc = bpy.context.scene
hinge = bpy.data.objects["platen_hinge"]
sheet = bpy.data.objects["sheet_stamped"]

sc.frame_set(54); bpy.context.view_layer.update()
P = hinge.matrix_world @ sheet.matrix_parent_inverse
M_on_local = sheet.matrix_basis.copy()
M_on_world = P @ M_on_local

# landing: face(local +y) -> world +z; print top(local +z) -> away(-y cam side = +y world); yaw 8deg
R_land = Euler((0,0,math.radians(188))).to_matrix().to_4x4() @ Euler((math.radians(90),0,0)).to_matrix().to_4x4()
land_center = Vector((0.02,-0.30,0.033))
M_land_world = Matrix.Translation(land_center) @ R_land
q_on = M_on_world.to_quaternion(); q_land = R_land.to_quaternion()
mid_center = M_on_world.translation.lerp(land_center,0.55) + Vector((0,-0.02,0.035))
M_mid_world = Matrix.Translation(mid_center) @ (q_on.slerp(q_land,0.55)).to_matrix().to_4x4()

for f,Mw in ((58,M_on_world),(62,M_mid_world),(66,M_land_world),(71,M_land_world)):
    L = P.inverted() @ Mw
    sheet.location = L.to_translation()
    sheet.rotation_euler = L.to_quaternion().to_euler()
    sheet.keyframe_insert("location", frame=f)
    sheet.keyframe_insert("rotation_euler", frame=f)

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final3.blend")
sc.frame_set(71); bpy.context.view_layer.update()
fw = sheet.matrix_world.to_3x3() @ Vector((0,1,0))
print("face->", tuple(round(v,2) for v in fw), "pos", tuple(round(v,3) for v in sheet.matrix_world.translation))
sc.render.engine='CYCLES'; sc.cycles.samples=16; sc.cycles.use_denoising=True
sc.render.resolution_x=390; sc.render.resolution_y=844
sc.render.filepath='/tmp/pf6_f071.png'
bpy.ops.render.render(write_still=True); print("DONE")
