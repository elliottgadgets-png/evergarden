import bpy, math
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v2.blend")
sc = bpy.context.scene
# black world so off-wall frame is pure dark
sc.world.node_tree.nodes["Background"].inputs[0].default_value = (0.0,0.0,0.0,1)
sc.world.node_tree.nodes["Background"].inputs[1].default_value = 0.0
# bigger wall
wall = bpy.data.objects["wall"]; wall.scale = (1.6, 1.0, 1.6)
# darker wood via mix
wnt = bpy.data.materials["bench_wood"].node_tree
wb = wnt.nodes["Principled BSDF"]
tex = next(n for n in wnt.nodes if n.type=='TEX_IMAGE' and 'Color' in n.image.name)
mix = wnt.nodes.new("ShaderNodeMix"); mix.data_type='RGBA'; mix.blend_type='MULTIPLY'; mix.inputs["Factor"].default_value=1.0
mix.inputs["B"].default_value = (0.55,0.42,0.34,1)
for l in list(wnt.links):
    if l.to_node==wb and l.to_socket==wb.inputs["Base Color"]: wnt.links.remove(l)
wnt.links.new(tex.outputs["Color"], mix.inputs["A"]); wnt.links.new(mix.outputs["Result"], wb.inputs["Base Color"])
mp = next(n for n in wnt.nodes if n.type=='MAPPING'); mp.inputs["Scale"].default_value=(3.0,8.0,1.0)
# stronger iron texture
int_ = bpy.data.materials["cast_iron"].node_tree
for n in int_.nodes:
    if n.type=='BUMP': n.inputs["Strength"].default_value=0.5; n.inputs["Distance"].default_value=0.0025
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v3.blend")
print("SCENE_V3_SAVED")
