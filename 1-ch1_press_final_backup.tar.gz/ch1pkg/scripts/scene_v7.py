import bpy, math
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v6.blend")
sc = bpy.context.scene

# paper smaller & lower on platen
sh = bpy.data.objects["sheet"]
sh.scale = (0.12/0.13, 1.0, 0.13/0.15)  # relative to current dims via fresh size below
sh.location = (0, 0.010, 0.135)
# ink disk & bridge up 0.03 so disk silhouette never crosses the paper
for n in ("bridge","inkdisk","inkface"):
    bpy.data.objects[n].location.z += 0.03

# stamped sheet twin: hidden until after the press
paperm = bpy.data.materials["paper"]
stampm = bpy.data.materials.new("paper_stamped"); stampm.use_nodes=True
snt = stampm.node_tree; sb = snt.nodes["Principled BSDF"]
sb.inputs["Base Color"].default_value=(0.85,0.82,0.76,1); sb.inputs["Roughness"].default_value=0.9
# procedural seal: dark ring emblem
tc = snt.nodes.new("ShaderNodeTexCoord")
mp = snt.nodes.new("ShaderNodeMapping"); snt.links.new(tc.outputs["Generated"], mp.inputs["Vector"])
sep = snt.nodes.new("ShaderNodeSeparateXYZ"); snt.links.new(mp.outputs["Vector"], sep.inputs[0])
# distance from center in XZ plane of generated coords
import mathutils
vm = snt.nodes.new("ShaderNodeVectorMath"); vm.operation='DISTANCE'
ctr = snt.nodes.new("ShaderNodeVectorMath"); ctr.operation='SUBTRACT'
snt.links.new(mp.outputs["Vector"], ctr.inputs[0]); ctr.inputs[1].default_value=(0.5,0.5,0.5)
snt.links.new(ctr.outputs[0], vm.inputs[0])
z0 = snt.nodes.new("ShaderNodeVectorMath"); z0.operation='MULTIPLY'; z0.inputs[1].default_value=(1,0,1)
snt.links.new(ctr.outputs[0], z0.inputs[0]); snt.links.new(z0.outputs[0], vm.inputs[0])
ring = snt.nodes.new("ShaderNodeValToRGB")
ring.color_ramp.elements[0].position=0.18; ring.color_ramp.elements[0].color=(0.1,0.08,0.06,1)
ring.color_ramp.elements[1].position=0.20; ring.color_ramp.elements[1].color=(0.85,0.82,0.76,1)
ring.color_ramp.elements.new(0.24); ring.color_ramp.elements[1].color=(0.85,0.82,0.76,1)
ring.color_ramp.elements[2].color=(0.1,0.08,0.06,1); ring.color_ramp.elements.new(0.26)
ring.color_ramp.elements[3].color=(0.85,0.82,0.76,1)
snt.links.new(vm.outputs[0], ring.inputs[0]); snt.links.new(ring.outputs[0], sb.inputs["Base Color"])

def box(name, loc, scale, mat, bevel=0.0, parent=None):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    o=bpy.context.active_object; o.name=name
    o.scale=(scale[0]/2,scale[1]/2,scale[2]/2); bpy.ops.object.transform_apply(scale=True)
    if bevel:
        md=o.modifiers.new("e",'BEVEL'); md.width=bevel; md.segments=2
    if mat: o.data.materials.append(mat)
    if parent: o.parent=parent
    return o

hinge = bpy.data.objects["platen_hinge"]
st = box("sheet_stamped", (0,0.0095,0.135), (0.12,0.002,0.13), stampm, bevel=0.001, parent=hinge)
st.location=(0,0.0095,0.135)
# visibility keys: stamped hidden until f75, plain hidden after f75
plain = sh
for o, on_frames, off_frames in ((plain,[0],[75]), (st,[75],[0])):
    pass
def vis_keys(o, timeline):
    for f,v in timeline:
        o.hide_render = v
        o.keyframe_insert("hide_render", frame=f)
vis_keys(plain, [(0,False),(74,False),(75,True),(119,True)])
vis_keys(st,    [(0,True),(74,True),(75,False),(119,False)])

# wear: roughness variation on cast iron
int_ = bpy.data.materials["cast_iron"].node_tree
ib = int_.nodes["Principled BSDF"]
noise2 = int_.nodes.new("ShaderNodeTexNoise"); noise2.inputs["Scale"].default_value=4; noise2.inputs["Detail"].default_value=2
ramp = int_.nodes.new("ShaderNodeValToRGB")
ramp.color_ramp.elements[0].color=(0.3,0.3,0.3,1); ramp.color_ramp.elements[1].color=(0.6,0.6,0.6,1)
int_.links.new(noise2.outputs["Fac"], ramp.inputs[0]); int_.links.new(ramp.outputs[0], ib.inputs["Roughness"])
# ink sheen on disk face
inkf = bpy.data.materials["steel"]
ib2 = inkf.node_tree.nodes["Principled BSDF"]
ib2.inputs["Roughness"].default_value=0.15
# paper warmer, softer
pb = paperm.node_tree.nodes["Principled BSDF"]
pb.inputs["Base Color"].default_value=(0.80,0.76,0.68,1); pb.inputs["Roughness"].default_value=0.95

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v7.blend")
print("SCENE_V7_SAVED")
