import bpy, math
from mathutils import Vector, Matrix
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc=bpy.context.scene
blank=bpy.data.objects["sheet"]; sheet=bpy.data.objects["sheet_stamped"]; hinge=bpy.data.objects["platen_hinge"]

# target world pose = blank sheet world at f42
sc.frame_set(42); bpy.context.view_layer.update()
M_target = blank.matrix_world.copy()

def local_for(f, M):
    sc.frame_set(f); bpy.context.view_layer.update()
    P = hinge.matrix_world @ sheet.matrix_parent_inverse
    return P.inverted() @ M

def key_pose(f, M):
    L = local_for(f, M)
    sheet.location = L.to_translation()
    sheet.rotation_euler = L.to_quaternion().to_euler()
    sheet.keyframe_insert("location", frame=f)
    sheet.keyframe_insert("rotation_euler", frame=f)

# clear existing loc/rot keys, rebuild
act = sheet.animation_data.action
for fc in list(act.fcurves):
    if fc.data_path in ("location","rotation_euler"):
        act.fcurves.remove(fc)

key_pose(43, M_target)
key_pose(60, M_target)

# landing world pose from current f71 key state: capture before clearing? f71 keys were on loc/rot fcurves - removed!
# rebuild landing pose from scratch (same composition as final12)
from mathutils import Euler
R_land = Euler((0,0,math.radians(188))).to_matrix().to_4x4() @ Euler((math.radians(90),0,0)).to_matrix().to_4x4()
land_center = Vector((0.02,-0.30,0.033))
M_land = Matrix.Translation(land_center) @ R_land

q_t = M_target.to_quaternion(); q_l = M_land.to_quaternion()
mid_center = M_target.translation.lerp(land_center, 0.55) + Vector((0,0,0.02))
M_mid = Matrix.Translation(mid_center) @ (q_t.slerp(q_l,0.55)).to_matrix().to_4x4()
key_pose(64, M_mid)
key_pose(68, M_land)
key_pose(71, M_land)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
print("SAVED")
