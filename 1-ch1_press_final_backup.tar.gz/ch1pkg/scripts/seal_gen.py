from PIL import Image, ImageDraw
import math
S=1024; img=Image.new('L',(S,S),0); d=ImageDraw.Draw(img)
c=S/2
d.ellipse([c-380,c-380,c+380,c+380], outline=255, width=32)
d.ellipse([c-315,c-315,c+315,c+315], outline=255, width=9)
def leaf(tipx,tipy,basex,basey,w):
    # leaf as tapered quad/arc from base to tip with width w
    dx,dy=tipx-basex,tipy-basey; L=math.hypot(dx,dy); ux,uy=dx/L,dy/L; px,py=-uy,ux
    pts=[]
    for i in range(21):
        t=i/20
        bw=math.sin(t*math.pi)*w
        pts.append((basex+dx*t+px*bw, basey+dy*t+py*bw))
    for i in range(20,-1,-1):
        t=i/20
        bw=math.sin(t*math.pi)*w
        pts.append((basex+dx*t-px*bw, basey+dy*t-py*bw))
    d.polygon(pts, fill=255)
# stem from bottom center up to bud
d.line([c,c+230,c,c-90], fill=255, width=20)
# two leaves sprouting from mid-stem, angled up-out
leaf(c-165,c-160,c,c+40,52)
leaf(c+165,c-160,c,c+40,52)
# bud on top
d.ellipse([c-52,c-195,c+52,c-95], fill=255)
img.save('seal.png')
prev=Image.new('RGB',(S,S),(20,16,12)); prev.paste(Image.merge('RGB',(img,img,img)).point(lambda v:v*0.9),(0,0),img)
prev.save('/tmp/seal_preview.png')
print("SEAL_OK")
