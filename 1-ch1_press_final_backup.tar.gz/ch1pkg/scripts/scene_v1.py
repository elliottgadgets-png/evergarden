# Scene v1: fix platen registration, add bench + backdrop + textured materials
import bpy, math, sys
from mathutils import Vector

bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_v2.blend")

# --- fix platen registration: paper faces die, closes to contact ---
hinge = bpy.data.objects["platen_hinge"]
hinge.location = (0,-0.052,0.06)
pl = bpy.data.objects["platen"];  pl.location = (0,0.017,0.15)
sh = bpy.data.objects["sheet"];   sh.location = (0,0.010,0.15)  # die side of platen

# --- cast iron gets procedural noise bump ---
iron = bpy.data.materials["cast_iron"]
nt = iron.node_tree
b = nt.nodes["Principled BSDF"]
noise = nt.nodes.new("ShaderNodeTexNoise"); noise.inputs["Scale"].default_value=35; noise.inputs["Detail"].default_value=3; noise.inputs["Roughness"].default_value=0.8
bump = nt.nodes.new("ShaderNodeBump"); bump.inputs["Strength"].default_value=0.25; bump.inputs["Distance"].default_value=0.0015
nt.links.new(noise.outputs["Fac"], bump.inputs["Height"]); nt.links.new(bump.outputs["Normal"], b.inputs["Normal"])

# --- bench: wooden desktop ---
woodm = bpy.data.materials.new("bench_wood"); woodm.use_nodes=True
wnt = woodm.node_tree; wb = wnt.nodes["Principled BSDF"]
tex = wnt.nodes.new("ShaderNodeTexImage"); tex.image = bpy.data.images.load("/tmp/wood/Wood026_1K-JPG_Color.jpg")
wnt.links.new(tex.outputs["Color"], wb.inputs["Base Color"])
rough = wnt.nodes.new("ShaderNodeTexImage"); rough.image = bpy.data.images.load("/tmp/wood/Wood026_1K-JPG_Roughness.jpg")
rough.image.colorspace_settings.name='Non-Color'
wnt.links.new(rough.outputs["Color"], wb.inputs["Roughness"])
norm = wnt.nodes.new("ShaderNodeTexImage"); norm.image = bpy.data.images.load("/tmp/wood/Wood026_1K-JPG_NormalGL.jpg")
norm.image.colorspace_settings.name='Non-Color'
nm = wnt.nodes.new("ShaderNodeNormalMap"); wnt.links.new(norm.outputs["Color"], nm.inputs["Color"]); wnt.links.new(nm.outputs["Normal"], wb.inputs["Normal"])
uv = wnt.nodes.new("ShaderNodeUVMap"); mapn = wnt.nodes.new("ShaderNodeMapping")
wnt.links.new(uv.outputs["UV"], mapn.inputs["Vector"])
for t in (tex, rough, norm): wnt.links.new(mapn.outputs["Vector"], t.inputs["Vector"])
mapn.inputs["Scale"].default_value = (2.0, 2.0, 1.0)

def box(name, loc, scale, mat, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    o=bpy.context.active_object; o.name=name
    o.scale=(scale[0]/2,scale[1]/2,scale[2]/2); bpy.ops.object.transform_apply(scale=True)
    if bevel:
        md=o.modifiers.new("e",'BEVEL'); md.width=bevel; md.segments=2
    if mat: o.data.materials.append(mat)
    return o

bench = box("bench", (0,0,-0.035), (1.6,1.0,0.05), woodm, bevel=0.004)
# backdrop wall
wallm = bpy.data.materials.new("wall"); wallm.use_nodes=True
wl = wallm.node_tree.nodes["Principled BSDF"]
wl.inputs["Base Color"].default_value=(0.045,0.04,0.035,1); wl.inputs["Roughness"].default_value=0.95
wall = box("wall", (0,0.45,0.6), (1.8,0.05,1.6), wallm)

# --- lights (replace test lights): warm key, cool rim, soft fill ---
w = bpy.data.worlds.new("w"); bpy.context.scene.world = w; w.use_nodes=True
w.node_tree.nodes["Background"].inputs[0].default_value=(0.008,0.008,0.01,1)
w.node_tree.nodes["Background"].inputs[1].default_value=1.0
def area(name, loc, energy, color, size=0.4, target=(0,0,0.18)):
    bpy.ops.object.light_add(type='AREA', location=loc)
    l=bpy.context.active_object; l.name=name
    l.data.energy=energy; l.data.color=color; l.data.shape='DISK'; l.data.size=size
    d=Vector(target)-l.location; l.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
area("key",(0.55,-0.55,0.85),70,(1.0,0.88,0.75),0.5)
area("rim",(-0.55,0.25,0.75),55,(0.72,0.8,1.0),0.4)
area("fill",(0,-0.9,0.25),14,(1.0,0.95,0.9),0.6)

# camera: widen slightly so flywheel isn't cropped
cam = bpy.data.objects["Camera"] if "Camera" in bpy.data.objects else bpy.context.scene.camera
bpy.context.scene.camera = cam
cam.data.lens = 47

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v1.blend")
print("SCENE_V1_SAVED")
