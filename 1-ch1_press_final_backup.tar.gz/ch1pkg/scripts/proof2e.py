import bpy
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_proof2c.blend")
cam = bpy.data.objects["Camera"]
act = cam.animation_data.action
# current interpolated pose at f54
loc54 = (0.36+(0.32-0.36)*54/71, -0.62+(-0.56+0.62)*54/71, 0.38+(0.35-0.38)*54/71)
rot54 = (1.243+(1.252-1.243)*54/71, 0.0, 0.504+(0.494-0.504)*54/71)
def setkey(dp, idx, f, v):
    fc = [c for c in act.fcurves if c.data_path==dp and c.array_index==idx][0]
    fc.keyframe_points.insert(f, v, options={'FAST'})
    for k in fc.keyframe_points: k.interpolation='BEZIER'
for i,v in enumerate(loc54): setkey('location', i, 54, v)
for i,v in enumerate(rot54): setkey('rotation_euler', i, 54, v)
# new end pose f71: pull back + raise, aim at paper/die center
end_loc = (0.50,-0.85,0.50)
d = Vector((0.02,-0.02,0.18)) - Vector(end_loc)
end_rot = d.to_track_quat('-Z','Y').to_euler()
for i,v in enumerate(end_loc):
    fc=[c for c in act.fcurves if c.data_path=='location' and c.array_index==i][0]
    [k for k in fc.keyframe_points if k.co[0]==71][0].co[1]=v
for i,v in enumerate(end_rot):
    fc=[c for c in act.fcurves if c.data_path=='rotation_euler' and c.array_index==i][0]
    [k for k in fc.keyframe_points if k.co[0]==71][0].co[1]=v
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_proof2d.blend")
print("SAVED end_rot", tuple(round(v,3) for v in end_rot))
