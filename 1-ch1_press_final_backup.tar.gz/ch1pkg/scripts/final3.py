import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final2.blend")
s = bpy.data.objects["sheet_stamped"]
s.hide_render=True; s.keyframe_insert("hide_render", frame=0); s.keyframe_insert("hide_render", frame=42)
s.hide_render=False; s.keyframe_insert("hide_render", frame=43); s.keyframe_insert("hide_render", frame=71)
# hide_viewport must match or render can still skip in some pipelines
s.hide_viewport=True; s.keyframe_insert("hide_viewport", frame=0); s.keyframe_insert("hide_viewport", frame=42)
s.hide_viewport=False; s.keyframe_insert("hide_viewport", frame=43); s.keyframe_insert("hide_viewport", frame=71)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final2.blend")
print("VISFIX_SAVED")
