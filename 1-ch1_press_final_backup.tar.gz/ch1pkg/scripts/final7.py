import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final3.blend")
sc = bpy.context.scene

# ---- fix seal UVs: face spans generated x,z ----
stampm = bpy.data.materials["paper_stamped"]; snt = stampm.node_tree
sb = snt.nodes["Principled BSDF"]
tc = snt.nodes["TexCoord"] if "TexCoord" in snt.nodes else None
# rebuild cleanly
for n in list(snt.nodes):
    if n.type not in ('OUTPUT_MATERIAL','BSDF_PRINCIPLED'): snt.nodes.remove(n)
for l in list(snt.links): snt.links.remove(l)
tc = snt.nodes.new("ShaderNodeTexCoord")
sep = snt.nodes.new("ShaderNodeSeparateXYZ"); snt.links.new(tc.outputs["Generated"], sep.inputs[0])
comb = snt.nodes.new("ShaderNodeCombineXYZ")
snt.links.new(sep.outputs["X"], comb.inputs["X"]); snt.links.new(sep.outputs["Z"], comb.inputs["Y"])
mp = snt.nodes.new("ShaderNodeMapping"); mp.inputs["Scale"].default_value=(1.35,1.35,1); mp.inputs["Location"].default_value=(-0.175,-0.175,0)
snt.links.new(comb.outputs[0], mp.inputs["Vector"])
tex = snt.nodes.new("ShaderNodeTexImage"); tex.image = bpy.data.images["seal.png"]
snt.links.new(mp.outputs["Vector"], tex.inputs["Vector"])
ramp = snt.nodes.new("ShaderNodeValToRGB")
ramp.color_ramp.elements[0].color=(0.55,0.50,0.42,1)
ramp.color_ramp.elements[1].color=(0.80,0.77,0.71,1)
snt.links.new(tex.outputs["Color"], ramp.inputs[0]); snt.links.new(ramp.outputs[0], sb.inputs["Base Color"])
bump = snt.nodes.new("ShaderNodeBump"); bump.inputs["Strength"].default_value=0.5; bump.inputs["Distance"].default_value=0.0025; bump.invert=True
snt.links.new(tex.outputs["Color"], bump.inputs["Height"]); snt.links.new(bump.outputs["Normal"], sb.inputs["Normal"])

# ---- rake: retarget to landed sheet, grazing sweep ----
tgt = bpy.data.objects["rake_target"]; tgt.parent=None; tgt.location=(0.02,-0.30,0.035)
rake = bpy.data.objects["rake"]; rdata = rake.data
rdata.spot_size=0.7; rdata.spot_blend=0.5
for fc in rake.animation_data.action.fcurves:
    if fc.data_path=='location':
        for k in fc.keyframe_points:
            f=k.co[0]
            vals={54:(0.5,-0.28,0.24),62:(0.05,-0.32,0.20),71:(-0.42,-0.28,0.17)}
            if f in vals: k.co[1]=vals[f][fc.array_index]; k.handle_left[1]=k.co[1]; k.handle_right[1]=k.co[1]
for fc in rdata.animation_data.action.fcurves:
    if fc.data_path=='energy':
        for k in fc.keyframe_points:
            if k.co[0]>=54: k.co[1]=45.0; k.handle_left[1]=45.0; k.handle_right[1]=45.0
# fill lift tamer
fill = bpy.data.objects["fill"].data
for fc in fill.animation_data.action.fcurves:
    for k in fc.keyframe_points:
        if k.co[0]>=54: k.co[1]=6.0; k.handle_left[1]=6.0; k.handle_right[1]=6.0
# focus empty: move to landed sheet at the lock
foc = bpy.data.objects["focus"]
if foc.animation_data: foc.animation_data_clear()
foc.location=(0.02,-0.04,0.16); foc.keyframe_insert("location", frame=54)
foc.location=(0.02,-0.28,0.05); foc.keyframe_insert("location", frame=66); foc.keyframe_insert("location", frame=71)

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc.render.engine='CYCLES'; sc.cycles.samples=16; sc.cycles.use_denoising=True
sc.render.resolution_x=390; sc.render.resolution_y=844
sc.frame_set(71); sc.render.filepath='/tmp/pf7_f071.png'; bpy.ops.render.render(write_still=True)
sc.frame_set(60); sc.render.filepath='/tmp/pf7_f060.png'; bpy.ops.render.render(write_still=True)
print("DONE")
