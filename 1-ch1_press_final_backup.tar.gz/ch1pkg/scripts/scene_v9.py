import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v8.blend")
sc = bpy.context.scene
H = -0.052  # hinge y

# thinner plate, clean sandwich: camera -> plate(-0.042..-0.034) -> paper(-0.0445..-0.0425) -> die face(-0.0435)
pl = bpy.data.objects["platen"]
pl.location = (0, 0.014, 0.15)
pl.scale = (1.0, 0.008/0.018, 1.0)  # thin the plate
for o in ("sheet","sheet_stamped"):
    bpy.data.objects[o].location = (0, 0.0085, 0.135)
die = bpy.data.objects["die"]
die.location = (0, -0.0475, 0.19)

# open angle 0.85 so stamped face ends facing up
hinge = bpy.data.objects["platen_hinge"]
fc = hinge.animation_data.action.fcurves[0]
for kp in fc.keyframe_points:
    if kp.co[0] in (0,30): kp.co[1]=0.35
    if kp.co[0] >= 92: kp.co[1]=0.85
    kp.handle_left[1]=kp.co[1]; kp.handle_right[1]=kp.co[1]

# camera: start wide, end high looking down into open platen
cam = sc.camera
cam.animation_data_clear()
cam.location=(0.48,-1.05,0.55); cam.keyframe_insert("location", frame=0)
d=Vector((0,0,0.16))-cam.location; cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler(); cam.keyframe_insert("rotation_euler", frame=0)
cam.location=(0.10,-0.52,0.95); cam.keyframe_insert("location", frame=119)
d=Vector((0,-0.10,0.10))-cam.location; cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler(); cam.keyframe_insert("rotation_euler", frame=119)
for fc in cam.animation_data.action.fcurves:
    for kp in fc.keyframe_points: kp.interpolation='BEZIER'

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/press_scene_v9.blend")
print("SCENE_V9_SAVED")
