/* EVERGARDEN eg-v1 — THE BUILDER'S WORKBENCH (hero slot, world scaffold).
   World: one long walnut workbench in a sunlit workshop. Warm plaster wall,
   paned window (daylight key), shelf of colored ink bottles, hanging tools,
   green-enamel shop lamps. On the bench: cutting mat, pencil cup, ruler,
   eraser, succulent, ink bottle. The hero page is a bone sheet on the bench:
   faint pencil wireframe underneath, ink draws over it as you scroll (RTL wipe).
   Palette from the live evergarden CSS: ink #14100c, bone #ece9e2, dim #8a877e,
   ember #e8862e, case #ffd28a, gold #D9A441 — rebalanced to DAYLIGHT per Itamar:
   color and life, no dark minimalism.
   Hero DOM truth (eg-live-ch0.png, x1.071): headline Suez One 900 30css=60px
   baselines ~1250/1335 centered; sub Heebo 300 28px ls 1.68 baseline ~1410;
   hint ember baseline ~1490; wordmark top-right. Light-sheet ink adaptation
   disclosed: sub #C4BCAB-on-black becomes #6b655a on bone. */
import * as THREE from './vendor/three.module.js';

const INK = '#14100c', BONE = '#f2ede3', DIM = '#6b655a', EMBER = '#c05f1a', GOLD = '#b3852f';
const PAPER = '#f2ede3', PENCIL = 'rgba(96,106,122,.5)';

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
document.getElementById('stage').appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xe4d8c2);
const camera = new THREE.PerspectiveCamera(54, innerWidth / innerHeight, .05, 80);

/* ---------- canvas helpers ---------- */
function ctex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}
function drawSpaced(g, text, cx, cy, spacing) {
  const ch = [...text];
  const ws = ch.map(c => g.measureText(c).width);
  const total = ws.reduce((a, b) => a + b, 0) + spacing * (ch.length - 1);
  let x = cx + total / 2;
  const prev = g.textAlign; g.textAlign = 'right';
  for (let i = 0; i < ch.length; i++) { g.fillText(ch[i], x, cy); x -= ws[i] + spacing; }
  g.textAlign = prev;
}
function drawSpacedLTR(g, text, cx, cy, spacing) {
  const ch = [...text];
  const ws = ch.map(c => g.measureText(c).width);
  const total = ws.reduce((a, b) => a + b, 0) + spacing * (ch.length - 1);
  let x = cx - total / 2;
  const prev = g.textAlign; g.textAlign = 'left';
  for (let i = 0; i < ch.length; i++) { g.fillText(ch[i], x, cy); x += ws[i] + spacing; }
  g.textAlign = prev;
}
function spacedW(g, text, spacing) {
  return [...text].reduce((a, c) => a + g.measureText(c).width, 0) + spacing * (text.length - 1);
}
const clamp01 = t => Math.min(1, Math.max(0, t));
const easeInOut = t => t * t * (3 - 2 * t);

async function loadFonts() {
  await Promise.all([
    document.fonts.load("900 60px 'Suez One'", 'האתר הזה נבנה מול'),
    document.fonts.load("300 28px 'Heebo'", 'לא תבנית דרג'),
    document.fonts.load("200 22px 'Heebo'", 'SEED 005'),
    document.fonts.load("400 26px 'Heebo'", 'גלול והעבודה מתחילה'),
  ]);
  await document.fonts.ready;
}

/* ---------- lighting: daylight + shop lamps ---------- */
scene.add(new THREE.AmbientLight(0xf0e4d0, .55));
{
  const envC = document.createElement('canvas'); envC.width = 256; envC.height = 128;
  const eg = envC.getContext('2d');
  const gr = eg.createLinearGradient(0, 0, 0, 128);
  gr.addColorStop(0, '#f5ead2'); gr.addColorStop(.55, '#cbb694'); gr.addColorStop(1, '#5f4a30');
  eg.fillStyle = gr; eg.fillRect(0, 0, 256, 128);
  const win = eg.createRadialGradient(64, 44, 4, 64, 44, 34);
  win.addColorStop(0, 'rgba(255,252,240,1)'); win.addColorStop(1, 'rgba(255,252,240,0)');
  eg.fillStyle = win; eg.fillRect(0, 0, 256, 128);
  const envTex = new THREE.CanvasTexture(envC);
  envTex.mapping = THREE.EquirectangularReflectionMapping;
  envTex.colorSpace = THREE.SRGBColorSpace;
  scene.environment = envTex;
}
const sun = new THREE.DirectionalLight(0xfff2dc, 2.6);
sun.position.set(-6, 5.2, 2.4); sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -9; sun.shadow.camera.right = 9;
sun.shadow.camera.top = 6; sun.shadow.camera.bottom = -4;
sun.shadow.bias = -.002; sun.shadow.radius = 7; scene.add(sun);
const fill = new THREE.DirectionalLight(0xdfe8f0, .5);   /* cool bounce off the wall */
fill.position.set(4, 2.5, 4); scene.add(fill);

/* green-enamel shop lamp */
const lamps = [];
function shopLamp(x, z, drop) {
  const g = new THREE.Group();
  const ceilY = 3.4;
  const cord = new THREE.Mesh(new THREE.CylinderGeometry(.008, .008, drop, 6),
    new THREE.MeshStandardMaterial({ color: 0x2b2622, roughness: .8 }));
  cord.position.set(0, ceilY - drop / 2, 0); g.add(cord);
  const shade = new THREE.Mesh(new THREE.ConeGeometry(.22, .17, 28, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x2e5b4a, roughness: .16, metalness: .35, side: THREE.DoubleSide, envMapIntensity: 1.2 }));
  shade.position.set(0, ceilY - drop, 0); shade.castShadow = true; g.add(shade);
  const bulbY = ceilY - drop - .04;
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(.032, 12, 12),
    new THREE.MeshBasicMaterial({ color: 0xffe2b0 }));
  bulb.position.set(0, bulbY, 0); g.add(bulb);
  const pt = new THREE.PointLight(0xffd9a0, 4.2, 8, 2);
  pt.position.set(0, bulbY - .02, 0); pt.castShadow = true;
  pt.shadow.mapSize.set(512, 512); pt.shadow.bias = -.004; pt.shadow.radius = 5; g.add(pt);
  g.position.set(x, 0, z); scene.add(g);
  lamps.push(pt);
}
shopLamp(-4.5, -1.1, 1.95);   /* over the hero sheet, behind it */
shopLamp(-2.2, -1.1, 1.95);
shopLamp(-6.9, -1.1, 1.95);

/* ---------- the bench: warm walnut, visible grain ---------- */
function woodTex() {
  return ctex(2048, 384, (g, w, h) => {
    g.fillStyle = '#6f4c2b'; g.fillRect(0, 0, w, h);
    for (let p = 0; p < 4; p++) {                       /* planks across z */
      const y0 = p * h / 4;
      g.fillStyle = ['#77522f', '#664423', '#7d5733', '#5f3f20'][p];
      g.fillRect(0, y0, w, h / 4);
      g.fillStyle = 'rgba(60,38,20,.55)'; g.fillRect(0, y0, w, 3);
    }
    for (let i = 0; i < 340; i++) {                     /* grain streaks */
      const y = Math.random() * h, x = Math.random() * w, len = 90 + Math.random() * 420;
      g.strokeStyle = `rgba(${52 + Math.random() * 30 | 0},${34 + Math.random() * 18 | 0},16,${.08 + Math.random() * .14})`;
      g.lineWidth = .8 + Math.random() * 1.8;
      g.beginPath(); g.moveTo(x, y);
      g.bezierCurveTo(x + len * .3, y + (Math.random() - .5) * 6, x + len * .7, y + (Math.random() - .5) * 6, x + len, y + (Math.random() - .5) * 4);
      g.stroke();
    }
    for (let i = 0; i < 46; i++) {                      /* scratches + use marks */
      const x = Math.random() * w, y = Math.random() * h, a = (Math.random() - .5) * .5;
      const l = 12 + Math.random() * 90;
      g.strokeStyle = Math.random() < .5 ? `rgba(230,205,165,${.06 + Math.random() * .1})` : `rgba(42,26,12,${.08 + Math.random() * .12})`;
      g.lineWidth = .6 + Math.random() * 1.1;
      g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke();
    }
    {                                                    /* coffee ring */
      const cx = w * .82, cy = h * .3;
      g.strokeStyle = 'rgba(58,36,16,.22)'; g.lineWidth = 5;
      g.beginPath(); g.arc(cx, cy, 26, 0, 7); g.stroke();
      g.strokeStyle = 'rgba(58,36,16,.1)'; g.lineWidth = 9;
      g.beginPath(); g.arc(cx, cy, 27, .6, 4.4); g.stroke();
    }
    for (let i = 0; i < 14; i++) {                      /* knots */
      const x = Math.random() * w, y = Math.random() * h;
      const gr = g.createRadialGradient(x, y, 1, x, y, 12 + Math.random() * 10);
      gr.addColorStop(0, 'rgba(48,30,14,.7)'); gr.addColorStop(1, 'rgba(48,30,14,0)');
      g.fillStyle = gr; g.beginPath(); g.arc(x, y, 24, 0, 7); g.fill();
    }
  });
}
const bench = new THREE.Mesh(
  new THREE.BoxGeometry(26, .16, 3.6),
  new THREE.MeshStandardMaterial({ map: woodTex(), roughness: .74, metalness: .02 }));
bench.position.set(-2, -.08, 0); bench.receiveShadow = true; bench.castShadow = true;
scene.add(bench);
/* bench front edge (apron) */
const apron = new THREE.Mesh(new THREE.BoxGeometry(26, .5, .1),
  new THREE.MeshStandardMaterial({ color: 0x6e4a26, roughness: .8 }));
apron.position.set(-2, -.38, 1.76); scene.add(apron);
/* legs hint */
for (const lx of [-12.5, 8.5]) {
  const leg = new THREE.Mesh(new THREE.BoxGeometry(.18, 2.2, .18),
    new THREE.MeshStandardMaterial({ color: 0x5f3f21, roughness: .85 }));
  leg.position.set(lx, -1.4, 1.5); scene.add(leg);
}

/* ---------- floor + wall ---------- */
const floor = new THREE.Mesh(new THREE.PlaneGeometry(90, 60),
  new THREE.MeshStandardMaterial({ color: 0x9c8468, roughness: .95 }));
floor.rotation.x = -Math.PI / 2; floor.position.y = -2.5; scene.add(floor);

const wallTex = ctex(1024, 512, (g, w, h) => {
  g.fillStyle = '#e9dfc9'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 40; i++) {                         /* large soft tonal blotches */
    const x = Math.random() * w, y = Math.random() * h, r = 40 + Math.random() * 130;
    const bg = g.createRadialGradient(x, y, 0, x, y, r);
    const tone = Math.random() < .5 ? '150,128,96' : '235,226,205';
    bg.addColorStop(0, `rgba(${tone},${.05 + Math.random() * .06})`); bg.addColorStop(1, `rgba(${tone},0)`);
    g.fillStyle = bg; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  for (let i = 0; i < 3800; i++) {                       /* plaster stipple */
    g.fillStyle = `rgba(${120 + Math.random() * 60 | 0},${100 + Math.random() * 50 | 0},70,${.04 + Math.random() * .07})`;
    g.fillRect(Math.random() * w, Math.random() * h, 2.2, 2.2);
  }
  const ao = g.createLinearGradient(0, h * .72, 0, h);   /* ambient occlusion toward the bench */
  ao.addColorStop(0, 'rgba(90,70,45,0)'); ao.addColorStop(1, 'rgba(90,70,45,.18)');
  g.fillStyle = ao; g.fillRect(0, h * .72, w, h * .28);
});
const wall = new THREE.Mesh(new THREE.PlaneGeometry(60, 16),
  new THREE.MeshStandardMaterial({ map: wallTex, roughness: .96 }));
wall.position.set(-2, 4.5, -2.6); scene.add(wall);

/* paned window with daylight glow */
function windowUnit(wx, wy) {
  const g = new THREE.Group();
  const viewTex = ctex(512, 640, (c2, w, h) => {
    const gr = c2.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, '#dfeaf0'); gr.addColorStop(.35, '#fdf3d8'); gr.addColorStop(.62, '#f5e3b8'); gr.addColorStop(1, '#e8cf9a');
    c2.fillStyle = gr; c2.fillRect(0, 0, w, h);
    for (let x = -20; x < w + 20; x += 30) {                 /* distant tree blobs, soft */
      const r = 30 + (x * 7919 % 21);
      const yy = h * .76 - (x * 104729 % 26);
      const tg = c2.createRadialGradient(x, yy, r * .2, x, yy, r);
      tg.addColorStop(0, 'rgba(120,148,82,.75)'); tg.addColorStop(1, 'rgba(120,148,82,0)');
      c2.fillStyle = tg; c2.beginPath(); c2.arc(x, yy, r, 0, 7); c2.fill();
    }
    const fg = c2.createLinearGradient(0, h * .8, 0, h);
    fg.addColorStop(0, 'rgba(98,126,66,.75)'); fg.addColorStop(1, 'rgba(80,104,54,.85)');
    c2.fillStyle = fg; c2.fillRect(0, h * .8, w, h * .2);
    c2.fillStyle = 'rgba(255,246,220,.35)'; c2.fillRect(0, 0, w, h * .3);  /* high light haze */
  });
  const sky = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 2.7),
    new THREE.MeshBasicMaterial({ map: viewTex }));
  g.add(sky);
  const frameMat = new THREE.MeshStandardMaterial({ color: 0x6b4f2e, roughness: .7 });
  const bars = [[0, 0, 2.24, .09], [0, 1.42, 2.24, .09], [0, -1.42, 2.24, .09],
                [-1.08, 0, .09, 2.94], [1.08, 0, .09, 2.94], [0, 0, .07, 2.84], [0, .71, 2.14, .06], [0, -.71, 2.14, .06]];
  for (const [x, y, bw, bh] of bars) {
    const b = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, .05), frameMat);
    b.position.set(x, y, .02); g.add(b);
  }
  g.position.set(wx, wy, -2.56); scene.add(g);
}
windowUnit(-5.5, 2.45);

/* shelf with colored ink bottles */
{
  const shelf = new THREE.Mesh(new THREE.BoxGeometry(3.4, .07, .34),
    new THREE.MeshStandardMaterial({ color: 0x7a5636, roughness: .75 }));
  shelf.position.set(-1.0, 2.62, -2.4); shelf.castShadow = true; scene.add(shelf);
  const glass = ['#c46a1e', '#2f7a72', '#b03a2e', '#3d6b35', '#2e4f8a', '#8a4b78'];
  glass.forEach((col, i) => {
    const b = new THREE.Mesh(new THREE.CylinderGeometry(.09, .1, .3 + (i % 3) * .07, 14),
      new THREE.MeshStandardMaterial({ color: col, roughness: .15, metalness: .1, transparent: true, opacity: .88 }));
    b.position.set(-2.35 + i * .5, 2.83 + (i % 3) * .035, -2.4); b.castShadow = true; scene.add(b);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(.05, .05, .06, 10),
      new THREE.MeshStandardMaterial({ color: 0x3a2c1c, roughness: .6 }));
    cap.position.set(-2.35 + i * .5, 3.02 + (i % 3) * .07, -2.4); scene.add(cap);
  });
}
/* hanging tools on the wall (simple silhouettes, warm steel) */
function hangTool(x, y, kind) {
  const mat = new THREE.MeshStandardMaterial({ color: 0x6e6a63, roughness: .45, metalness: .7 });
  const g = new THREE.Group();
  if (kind === 'hammer') {
    const head = new THREE.Mesh(new THREE.BoxGeometry(.34, .12, .08), mat); head.position.y = .42; g.add(head);
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(.025, .032, .7, 8),
      new THREE.MeshStandardMaterial({ color: 0x8a5f36, roughness: .8 })); g.add(handle);
  } else if (kind === 'square') {
    const a = new THREE.Mesh(new THREE.BoxGeometry(.06, .8, .03), mat); g.add(a);
    const b = new THREE.Mesh(new THREE.BoxGeometry(.5, .06, .03), mat); b.position.set(.22, -.37, 0); g.add(b);
  } else { /* brush */
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(.028, .028, .5, 8),
      new THREE.MeshStandardMaterial({ color: 0x3d6b35, roughness: .7 })); handle.position.y = .12; g.add(handle);
    const br = new THREE.Mesh(new THREE.CylinderGeometry(.045, .06, .22, 8),
      new THREE.MeshStandardMaterial({ color: 0xc9a96e, roughness: .9 })); br.position.y = -.26; g.add(br);
  }
  g.position.set(x, y, -2.52); scene.add(g);
}
hangTool(-3.9, 2.95, 'hammer'); hangTool(-3.0, 2.85, 'square'); hangTool(-2.2, 2.9, 'brush');

/* ---------- bench props around the hero slot ---------- */
const HERO_X = -4.46;
/* banker's desk lamp: brass arm, green glass shade, warm bulb */
{
  const brassMat = new THREE.MeshStandardMaterial({ color: 0xa8843e, roughness: .2, metalness: .95, envMapIntensity: 1.3 });
  const g = new THREE.Group();
  const base = new THREE.Mesh(new THREE.CylinderGeometry(.14, .16, .035, 20), brassMat);
  base.position.y = .018; g.add(base);
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(.016, .016, .5, 10), brassMat);
  stem.position.set(0, .27, 0); g.add(stem);
  const arm = new THREE.Mesh(new THREE.CylinderGeometry(.013, .013, .34, 10), brassMat);
  arm.position.set(0, .52, -.14); arm.rotation.x = Math.PI / 2.25; g.add(arm);
  const shade = new THREE.Mesh(new THREE.SphereGeometry(.13, 18, 10, 0, Math.PI * 2, 0, Math.PI * .55),
    new THREE.MeshStandardMaterial({ color: 0x2e6b4f, roughness: .25, metalness: .15, side: THREE.DoubleSide, emissive: 0x1d4a33, emissiveIntensity: .35 }));
  shade.position.set(0, .62, -.3); shade.rotation.x = Math.PI * .62; g.add(shade);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(.035, 10, 10),
    new THREE.MeshBasicMaterial({ color: 0xffe6b8 }));
  bulb.position.set(0, .58, -.33); g.add(bulb);
  const pt = new THREE.PointLight(0xffd9a0, 3.4, 4.5, 2);
  pt.position.set(0, .56, -.33); pt.castShadow = true; pt.shadow.mapSize.set(512, 512); pt.shadow.bias = -.004; pt.shadow.radius = 5;
  g.add(pt);
  g.position.set(HERO_X + .62, 0, -1.28); g.rotation.y = .35;
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  scene.add(g);
}
/* green cutting mat with faint grid */
{
  const matTex = ctex(512, 320, (g, w, h) => {
    g.fillStyle = '#3e6b4f'; g.fillRect(0, 0, w, h);
    g.strokeStyle = 'rgba(240,240,225,.14)'; g.lineWidth = 1;
    for (let x = 0; x < w; x += 32) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); }
    for (let y = 0; y < h; y += 32) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
  });
  const m = new THREE.Mesh(new THREE.BoxGeometry(1.7, .012, 1.15),
    new THREE.MeshStandardMaterial({ map: matTex, roughness: .85 }));
  m.position.set(HERO_X - 1.9, .006, .55); m.receiveShadow = true; m.castShadow = true; scene.add(m);
}
/* pencil cup with colored pencils */
{
  const cup = new THREE.Mesh(new THREE.CylinderGeometry(.11, .095, .24, 18),
    new THREE.MeshStandardMaterial({ color: 0xb34a2e, roughness: .5 }));
  cup.position.set(HERO_X + 1.55, .12, -.55); cup.castShadow = true; scene.add(cup);
  const cols = [0xd23b2e, 0xe8a13a, 0x2e6fb0, 0x3d8a4a, 0x8a4b78];
  cols.forEach((c, i) => {
    const p = new THREE.Mesh(new THREE.CylinderGeometry(.012, .012, .34, 6),
      new THREE.MeshStandardMaterial({ color: c, roughness: .6 }));
    p.position.set(HERO_X + 1.55 + (i - 2) * .035, .3, -.55 + ((i % 2) - .5) * .05);
    p.rotation.z = (i - 2) * .09; p.castShadow = true; scene.add(p);
  });
}
/* steel ruler */
{
  const rulerTex = ctex(512, 40, (g2, w2, h2) => {
    g2.fillStyle = '#9aa0a6'; g2.fillRect(0, 0, w2, h2);
    g2.fillStyle = 'rgba(40,42,46,.65)';
    for (let x = 8; x < w2; x += 10) {
      const tall = (x - 8) % 50 === 0;
      g2.fillRect(x, 0, 1.5, tall ? 18 : 9);
    }
    for (let i = 0; i < 120; i++) {
      g2.fillStyle = `rgba(255,255,255,${.02 + Math.random() * .04})`;
      g2.fillRect(Math.random() * w2, Math.random() * h2, 8 + Math.random() * 30, .8);
    }
  });
  const r = new THREE.Mesh(new THREE.BoxGeometry(1.15, .008, .09),
    new THREE.MeshStandardMaterial({ map: rulerTex, roughness: .38, metalness: .8, envMapIntensity: 1.1 }));
  r.position.set(HERO_X + 1.3, .004, .62); r.rotation.y = .16; r.castShadow = true; scene.add(r);
}
/* pink eraser */
{
  const e = new THREE.Mesh(new THREE.BoxGeometry(.14, .05, .07),
    new THREE.MeshStandardMaterial({ color: 0xd98a8f, roughness: .9 }));
  e.position.set(HERO_X - 1.25, .025, -.62); e.rotation.y = -.3; e.castShadow = true; scene.add(e);
}
/* succulent in terracotta pot (the everGARDEN wink) */
{
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(.09, .07, .14, 14),
    new THREE.MeshStandardMaterial({ color: 0xa85c38, roughness: .8 }));
  pot.position.set(-6.9, .07, -.62); pot.castShadow = true; scene.add(pot);
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x4d7a4a, roughness: .7 });
  for (let i = 0; i < 7; i++) {
    const leaf = new THREE.Mesh(new THREE.SphereGeometry(.045, 8, 6), leafMat);
    const a = i / 7 * Math.PI * 2;
    leaf.position.set(-6.9 + Math.cos(a) * .045, .19 + Math.sin(i) * .015, -.62 + Math.sin(a) * .045);
    leaf.scale.set(.6, 1.5, .6); leaf.rotation.z = Math.cos(a) * .5; scene.add(leaf);
  }
}
/* amber ink bottle near the sheet */
{
  const b = new THREE.Mesh(new THREE.CylinderGeometry(.068, .076, .16, 14),
    new THREE.MeshStandardMaterial({ color: 0x8a4a12, roughness: .08, metalness: .05, transparent: true, opacity: .92, envMapIntensity: 1.3 }));
  b.position.set(HERO_X + 1.15, .08, -.68); b.castShadow = true; scene.add(b);
  const cork = new THREE.Mesh(new THREE.CylinderGeometry(.038, .042, .05, 10),
    new THREE.MeshStandardMaterial({ color: 0x6e5334, roughness: .95 }));
  cork.position.set(HERO_X + 1.15, .185, -.68); cork.castShadow = true; scene.add(cork);
}

/* soft contact shadows (radial gradient planes just above the bench) */
let contactTex = null;
function contactShadow(x, z, sx, sz, alpha) {
  if (!contactTex) {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const g2 = c.getContext('2d');
    const gr = g2.createRadialGradient(64, 64, 8, 64, 64, 62);
    gr.addColorStop(0, 'rgba(30,20,10,.85)'); gr.addColorStop(.6, 'rgba(30,20,10,.32)'); gr.addColorStop(1, 'rgba(30,20,10,0)');
    g2.fillStyle = gr; g2.fillRect(0, 0, 128, 128);
    contactTex = new THREE.CanvasTexture(c);
  }
  const m = new THREE.Mesh(new THREE.PlaneGeometry(sx, sz),
    new THREE.MeshBasicMaterial({ map: contactTex, transparent: true, opacity: alpha, depthWrite: false }));
  m.rotation.x = -Math.PI / 2; m.position.set(x, .0025, z); scene.add(m);
}

/* ---------- the hero sheet: bone paper, pencil wireframe, ink wipe ---------- */
const SHEET_W = .98, SHEET_D = 2.12;                /* portrait page: width across bench, length into the bench */
let paperTex, inkCanvas, inkCtx, wipeCanvas, wipeCtx, wipeTex;

function drawPaperBase(g, w, h) {
  g.fillStyle = PAPER; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 1500; i++) {                   /* paper tooth */
    g.fillStyle = `rgba(120,100,70,${.02 + Math.random() * .04})`;
    g.fillRect(Math.random() * w, Math.random() * h, 1.5, 1.5);
  }
  for (let i = 0; i < 260; i++) {                    /* long fibers */
    const x = Math.random() * w, y = Math.random() * h, a = Math.random() * Math.PI, l = 6 + Math.random() * 22;
    g.strokeStyle = `rgba(${140 + Math.random() * 40 | 0},${120 + Math.random() * 30 | 0},88,${.05 + Math.random() * .07})`;
    g.lineWidth = .7 + Math.random() * .8;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke();
  }
  g.strokeStyle = 'rgba(150,128,92,.28)';            /* deckled edges */
  for (const [horiz, fixed] of [[true, 3], [true, h - 3], [false, 3], [false, w - 3]]) {
    g.lineWidth = 2 + Math.random() * 3;
    g.beginPath();
    for (let d = 0; d <= (horiz ? w : h); d += 14) {
      const off = fixed + (Math.random() - .5) * 3;
      if (d === 0) g.moveTo(horiz ? d : off, horiz ? off : d);
      else g.lineTo(horiz ? d : off, horiz ? off : d);
    }
    g.stroke();
  }
  const v = g.createRadialGradient(w / 2, h / 2, h * .3, w / 2, h / 2, h * .75);
  v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(90,70,40,.12)');
  g.fillStyle = v; g.fillRect(0, 0, w, h);
}
function drawWireframe(g, w, h) {
  g.strokeStyle = PENCIL; g.lineWidth = 2; g.lineCap = 'round';
  const j = n => n + (Math.random() - .5) * 5;        /* hand wobble */
  /* browser chrome sketch around the hero block */
  g.strokeRect(j(70), j(1120), 640, 400);
  g.beginPath(); g.arc(j(100), j(1145), 6, 0, 7); g.stroke();
  g.beginPath(); g.arc(j(125), j(1145), 6, 0, 7); g.stroke();
  g.beginPath(); g.moveTo(j(70), j(1170)); g.lineTo(j(710), j(1170)); g.stroke();
  /* headline + sub placeholder strokes */
  for (const [y, x0, x1] of [[1252, 120, 660], [1335, 260, 520], [1410, 180, 600], [1490, 300, 480]]) {
    g.beginPath(); g.moveTo(j(x0), y); g.lineTo(j(x1), y + (Math.random() - .5) * 4); g.stroke();
  }
  /* wordmark + tag boxes */
  g.strokeRect(j(560), j(40), 150, 60);
  g.strokeRect(j(600), j(110), 110, 22);
  /* sprouting branch, pencil study — the garden on the bench */
  g.save(); g.translate(390, 700); g.lineWidth = 2.5;
  g.beginPath(); g.moveTo(0, 240);
  g.bezierCurveTo(-18, 150, 22, 90, -6, 10);
  g.stroke();
  const leaf = (x, y, r, rot) => {
    g.save(); g.translate(x, y); g.rotate(rot);
    g.beginPath(); g.ellipse(0, 0, r, r * .42, 0, 0, Math.PI * 2); g.stroke();
    g.beginPath(); g.moveTo(-r, 0); g.lineTo(r, 0); g.stroke();
    g.restore();
  };
  leaf(-52, 130, 46, -.5); leaf(48, 96, 42, .45); leaf(-44, 44, 38, -.65); leaf(40, 6, 34, .35); leaf(-10, -34, 36, -1.35);
  g.beginPath(); g.moveTo(-58, 240); g.lineTo(58, 240); g.lineTo(44, 320); g.lineTo(-44, 320); g.closePath(); g.stroke();  /* pot */
  g.restore();
}
function drawInk(g, w, h) {
  /* wordmark */
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 44px 'Suez One'";
  g.fillText('נבנה ביד', 726, 84);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  drawSpacedLTR(g, 'SEED 005', 683, 124, 6);
  /* headline, two lines */
  g.textAlign = 'center';
  g.fillStyle = INK;
  const L1 = 'האתר הזה נבנה מול העיניים', L2 = 'שלך.';
  let fs = 60;                                   /* probe: 30css x2, line1 666px wide */
  g.font = `900 ${fs}px 'Suez One'`;
  while (g.measureText(L1).width > 700 && fs > 40) { fs -= 2; g.font = `900 ${fs}px 'Suez One'`; }
  g.fillText(L1, 390, 1250);
  g.fillText(L2, 390, 1318);
  /* sub */
  g.fillStyle = DIM; g.font = "300 28px 'Heebo'";
  drawSpaced(g, 'לא תבנית. לא דרג-אנד-דרופ. נבנה ביד.', 390, 1403, 1.68);
  /* scroll hint — probe truth: cap Heebo 200 13px ls 2.34, color dim (not ember) */
  g.fillStyle = '#8a877e'; g.font = "200 26px 'Heebo'";
  drawSpaced(g, 'גלול — והעבודה מתחילה ↓', 390, 1483, 4.68);
}

function addInkBleed(src) {
  const c = document.createElement('canvas'); c.width = src.width; c.height = src.height;
  const g = c.getContext('2d');
  g.filter = 'blur(1.4px)'; g.globalAlpha = .38;
  g.drawImage(src, .6, .8);
  g.filter = 'none'; g.globalAlpha = 1;
  g.drawImage(src, 0, 0);
  return c;
}
function buildSheet() {
  const W = 780, H = 1688;
  paperTex = ctex(W, H, drawPaperBase);
  /* wireframe lives on its own canvas under the paper shading */
  const wireC = document.createElement('canvas'); wireC.width = W; wireC.height = H;
  const wg = wireC.getContext('2d'); drawPaperBase(wg, W, H); drawWireframe(wg, W, H);
  const wireTex = new THREE.CanvasTexture(wireC); wireTex.colorSpace = THREE.SRGBColorSpace; wireTex.anisotropy = 8;
  /* ink prerendered, wiped into wipeCanvas by scroll */
  const rawInk = document.createElement('canvas'); rawInk.width = W; rawInk.height = H;
  drawInk(rawInk.getContext('2d'), W, H);
  inkCanvas = addInkBleed(rawInk);
  inkCtx = inkCanvas.getContext('2d');
  wipeCanvas = document.createElement('canvas'); wipeCanvas.width = W; wipeCanvas.height = H;
  wipeCtx = wipeCanvas.getContext('2d');
  wipeCtx.drawImage(wireC, 0, 0);
  wipeTex = new THREE.CanvasTexture(wipeCanvas); wipeTex.colorSpace = THREE.SRGBColorSpace; wipeTex.anisotropy = 8;

  const geo = new THREE.BoxGeometry(SHEET_W, .024, SHEET_D);
  const edge = new THREE.MeshStandardMaterial({ color: 0xd8d0bf, roughness: .85 });
  const face = new THREE.MeshBasicMaterial({ map: wipeTex });
  const sheet = new THREE.Mesh(geo, [edge, edge, face, edge, edge, edge]);
  sheet.castShadow = true; sheet.receiveShadow = true;
  sheet.position.set(HERO_X, .028, 0);
  sheet.rotation.y = -.012;                            /* laid down casually, not aligned */
  scene.add(sheet);
  /* a pencil resting on the bench by the sheet */
  const pencil = new THREE.Mesh(new THREE.CylinderGeometry(.014, .014, .5, 6),
    new THREE.MeshStandardMaterial({ color: 0xe8a13a, roughness: .6 }));
  pencil.rotation.z = Math.PI / 2; pencil.rotation.y = .24;
  pencil.position.set(HERO_X - .78, .014, .35); pencil.castShadow = true; scene.add(pencil);
}

let lastWipe = -1;
function setWipe(t) {                                  /* 0=wireframe only, 1=fully inked */
  t = clamp01(t);
  if (Math.abs(t - lastWipe) < .004) return;
  lastWipe = t;
  const W = 780, H = 1688;
  wipeCtx.clearRect(0, 0, W, H);
  wipeCtx.drawImage(inkCanvas, 0, 0);                  /* ink exists under… */
  /* …a mask that uncovers right-to-left (RTL draw direction) */
  const xEdge = W + 80 - easeInOut(t) * (W + 160);   /* t0: off right, t1: off left */
  wipeCtx.globalCompositeOperation = 'destination-out';
  wipeCtx.fillStyle = '#000';
  wipeCtx.fillRect(0, 0, Math.min(W, Math.max(0, xEdge - 70)), H);
  const fx0 = Math.max(0, xEdge - 70), fx1 = Math.min(W, xEdge + 10);
  if (fx1 > fx0) {
    const gr = wipeCtx.createLinearGradient(xEdge - 70, 0, xEdge + 10, 0);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    wipeCtx.fillStyle = gr; wipeCtx.fillRect(fx0, 0, fx1 - fx0, H);
  }
  wipeCtx.globalCompositeOperation = 'destination-over';
  wipeCtx.globalAlpha = 1 - .55 * t;
  wipeCtx.drawImage(wireBackup, 0, 0);
  wipeCtx.globalAlpha = 1;
  wipeTex.needsUpdate = true;
}
let wireBackup;                                        /* kept for the composite */

/* ---------- chapter 1 sheet (חוויה): letterpress deboss ----------
   Live DOM truth (egprobe1, css x2): marker 'פרק 01 — חוויה' dim, centered,
   Heebo 200 11css baseline ~1218 ls .4em; kicker 'אתר טוב לא נקרא. הוא מורגש.'
   Suez One ~24css bone baseline ~1314; frag 2 lines Heebo 15css bone
   baselines ~1398/1434; micro 'געו במסך — החומר מרגיש אתכם' Heebo 12css dim
   baseline ~1516. On-paper adaptations: bone→ink (kicker) / blind deboss (frag). */
const SHEET2_X = HERO_X + 2.3;
let dieGroup = null;
const DIE_REST = { x: SHEET2_X + .62, y: .05, z: -.95 };
const DIE_HOVER = { x: SHEET2_X, y: .5, z: .62 };
const DIE_PRESS = { x: SHEET2_X, y: .052, z: .62 };
function drawDeboss(g, text, cx, cy, font, opts = {}) {
  g.font = font; g.textAlign = 'center'; g.textBaseline = 'alphabetic';
  const d = opts.depth || 2;
  g.fillStyle = 'rgba(90,70,45,.55)';                      /* pressed shadow, upper edge */
  g.fillText(text, cx, cy - d * .7);
  g.fillStyle = 'rgba(255,252,244,.95)';                   /* paper lift, lower edge */
  g.fillText(text, cx, cy + d * .9);
  if (opts.ink) {
    g.fillStyle = opts.ink;
    g.fillText(text, cx, cy);
  } else {
    g.fillStyle = 'rgba(104,84,54,.58)';                   /* blind deboss readable bed */
    g.fillText(text, cx, cy);
  }
}
function drawWireframe2(g, w, h) {
  g.strokeStyle = PENCIL; g.lineWidth = 2; g.lineCap = 'round';
  const j = n => n + (Math.random() - .5) * 5;
  g.strokeRect(j(70), j(1120), 640, 420);
  g.beginPath(); g.arc(j(100), j(1145), 6, 0, 7); g.stroke();
  g.beginPath(); g.arc(j(125), j(1145), 6, 0, 7); g.stroke();
  g.beginPath(); g.moveTo(j(70), j(1170)); g.lineTo(j(710), j(1170)); g.stroke();
  for (const [y, x0, x1] of [[1218, 280, 500], [1314, 130, 650], [1398, 110, 670], [1434, 160, 620], [1516, 220, 560]]) {
    g.beginPath(); g.moveTo(j(x0), y); g.lineTo(j(x1), y + (Math.random() - .5) * 4); g.stroke();
  }
  g.strokeRect(j(560), j(40), 150, 60);
  g.strokeRect(j(600), j(110), 110, 22);
  /* fingerprint study, pencil — touch */
  g.save(); g.translate(390, 640);
  for (let r = 14; r <= 98; r += 14) {
    g.beginPath();
    for (let a = 0; a <= Math.PI * 2 + .1; a += .12) {
      const rr = r + Math.sin(a * 3 + r) * 3.5;
      const x = Math.cos(a) * rr * .82, y = Math.sin(a) * rr;
      if (a === 0) g.moveTo(x, y); else g.lineTo(x, y);
    }
    g.stroke();
  }
  g.restore();
}
function drawInk2(g, w, h) {
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 44px 'Suez One'";
  g.fillText('נבנה ביד', 726, 84);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  drawSpacedLTR(g, 'SEED 005', 683, 124, 6);
  g.fillStyle = '#8a877e'; g.font = "200 22px 'Heebo'";
  drawSpaced(g, 'פרק 01 — חוויה', 390, 1218, 3.2);
  /* the kicker, inked deboss */
  drawDeboss(g, 'אתר טוב לא נקרא. הוא מורגש.', 390, 1314, "900 48px 'Suez One'", { ink: INK, depth: 3 });
  /* the frag, blind deboss — felt before it is read */
  drawDeboss(g, 'כל גלילה מתוכננת · כל ריחוף עונה ·', 390, 1398, "300 30px 'Heebo'", { depth: 1.6 });
  drawDeboss(g, 'כל מעבר מספר משהו', 390, 1434, "300 30px 'Heebo'", { depth: 1.6 });
  /* micro line, flat dim */
  g.fillStyle = '#8a877e'; g.font = "300 24px 'Heebo'"; g.textAlign = 'center';
  g.fillText('געו במסך — החומר מרגיש אתכם', 390, 1516);
}
let sheet2Tex, sheet2Canvas, sheet2Ctx, sheet2Wire, sheet2InkFull, lastPress = -1;
function buildSheet2() {
  const W = 780, H = 1688;
  sheet2Wire = document.createElement('canvas'); sheet2Wire.width = W; sheet2Wire.height = H;
  const wg = sheet2Wire.getContext('2d'); drawPaperBase(wg, W, H); drawWireframe2(wg, W, H);
  const rawInk = document.createElement('canvas'); rawInk.width = W; rawInk.height = H;
  const ig = rawInk.getContext('2d');
  drawPaperBase(ig, W, H);
  ig.globalAlpha = .55; ig.drawImage(sheet2Wire, 0, 0); ig.globalAlpha = 1;   /* ghost of the sketch stays */
  {                                                                          /* the press leaves an impression */
    const imp = ig.createRadialGradient(390, 1370, 60, 390, 1370, 330);
    imp.addColorStop(0, 'rgba(96,76,48,.14)'); imp.addColorStop(.75, 'rgba(96,76,48,.07)'); imp.addColorStop(1, 'rgba(96,76,48,0)');
    ig.fillStyle = imp;
    ig.save(); ig.translate(390, 1370); ig.scale(1.25, .8); ig.translate(-390, -1370);
    ig.fillRect(0, 900, W, 940); ig.restore();
  }
  drawInk2(ig, W, H);
  sheet2InkFull = addInkBleed(rawInk);
  sheet2Canvas = document.createElement('canvas'); sheet2Canvas.width = W; sheet2Canvas.height = H;
  sheet2Ctx = sheet2Canvas.getContext('2d');
  sheet2Ctx.drawImage(sheet2Wire, 0, 0);
  sheet2Tex = new THREE.CanvasTexture(sheet2Canvas); sheet2Tex.colorSpace = THREE.SRGBColorSpace; sheet2Tex.anisotropy = 8;
  const geo = new THREE.BoxGeometry(SHEET_W, .024, SHEET_D);
  const edge = new THREE.MeshStandardMaterial({ color: 0xd8d0bf, roughness: .85 });
  const face = new THREE.MeshBasicMaterial({ map: sheet2Tex });
  const sheet = new THREE.Mesh(geo, [edge, edge, face, edge, edge, edge]);
  sheet.castShadow = true; sheet.receiveShadow = true;
  sheet.position.set(SHEET2_X, .028, 0);
  sheet.rotation.y = .014;
  scene.add(sheet);
  /* the press die: steel block + wood handle, on a movable group for the press action */
  dieGroup = new THREE.Group();
  const dieFaceTex = ctex(256, 152, (g2, w2, h2) => {
    g2.fillStyle = '#6b7076'; g2.fillRect(0, 0, w2, h2);
    g2.save(); g2.translate(w2 / 2, h2 / 2 + 8); g2.scale(-1, 1);          /* reversed, as a real die */
    g2.font = "900 44px 'Suez One'"; g2.textAlign = 'center'; g2.textBaseline = 'middle';
    g2.fillStyle = 'rgba(255,255,255,.5)'; g2.fillText('נבנה ביד', 1.5, 1.5);
    g2.fillStyle = '#43474c'; g2.fillText('נבנה ביד', 0, 0);
    g2.restore();
  });
  const steelSide = new THREE.MeshStandardMaterial({ color: 0x7d8288, roughness: .3, metalness: .9, envMapIntensity: 1.1 });
  const steelFace = new THREE.MeshStandardMaterial({ map: dieFaceTex, roughness: .28, metalness: .9, envMapIntensity: 1.1 });
  const die = new THREE.Mesh(new THREE.BoxGeometry(.34, .1, .2),
    [steelSide, steelSide, steelSide, steelFace, steelSide, steelSide]);
  die.castShadow = true; dieGroup.add(die);
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(.045, .05, .16, 12),
    new THREE.MeshStandardMaterial({ color: 0x7a5636, roughness: .7 }));
  handle.position.y = .12; handle.castShadow = true; dieGroup.add(handle);
  dieGroup.position.set(SHEET2_X + .62, .05, -.95);
  dieGroup.rotation.y = -.2;
  scene.add(dieGroup);
  contactShadow(SHEET2_X + .06, .04, SHEET_W * 1.35, SHEET_D * 1.12, .5);
  contactShadow(SHEET2_X + .62, -.95, .5, .34, .5);
}

function setPress(u) {
  u = clamp01(u);
  if (Math.abs(u - lastPress) < .004) return;
  lastPress = u;
  const W = 780, H = 1688, g = sheet2Ctx;
  g.clearRect(0, 0, W, H);
  g.drawImage(sheet2InkFull, 0, 0);
  g.globalCompositeOperation = 'destination-in';
  const r = easeInOut(u) * 1500;
  if (r > 1) {
    const gr = g.createRadialGradient(390, 1370, Math.max(0, r - 60), 390, 1370, r);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
  } else {
    g.clearRect(0, 0, W, H);
  }
  g.globalCompositeOperation = 'destination-over';
  g.globalAlpha = 1 - .3 * u;
  g.drawImage(sheet2Wire, 0, 0);
  g.globalAlpha = 1;
  sheet2Tex.needsUpdate = true;
}

/* ---------- chapter 2 sheet (דיוק): scribed precision ----------
   Live DOM truth (egprobe2, css x2): cap 'הפיקסל האחרון הוא ההבדל בין מוצר ליצירה.'
   Heebo 200 13css dim ls 2.34 baseline ~877; proof cells centered, val Suez One 900
   22css bone baselines ~1000/1192/1384, key Heebo 200 11css bone baselines ~1068/1260/1452.
   Action (A storyboard): a caliper SCRIBES each value — engraved thin strokes,
   not letterpress. Wireframe layer: machinist's square + dimension lines. */
const SHEET3_X = SHEET2_X + 2.3;
function drawWireframe3(g, w, h) {
  g.strokeStyle = PENCIL; g.lineWidth = 2; g.lineCap = 'round';
  const j = n => n + (Math.random() - .5) * 5;
  /* machinist's square study */
  g.save(); g.translate(390, 500); g.lineWidth = 2.5;
  g.beginPath(); g.moveTo(-160, 120); g.lineTo(-160, -120); g.lineTo(-120, -120); g.lineTo(-120, 80); g.lineTo(160, 80); g.lineTo(160, 120); g.closePath(); g.stroke();
  for (let x = -110; x <= 150; x += 20) { g.beginPath(); g.moveTo(x, 80); g.lineTo(x, x % 100 === -10 + 100 * Math.round((x + 10) / 100) ? 60 : 68); g.stroke(); }
  g.restore();
  /* dimension lines between the future cells */
  for (const y of [1000, 1192, 1384]) {
    g.beginPath(); g.moveTo(120, y - 14); g.lineTo(120, y + 48); g.stroke();
    g.beginPath(); g.moveTo(114, y - 14); g.lineTo(126, y - 14); g.stroke();
    g.beginPath(); g.moveTo(114, y + 48); g.lineTo(126, y + 48); g.stroke();
  }
  for (const [y, x0, x1] of [[877, 110, 670]]) {
    g.beginPath(); g.moveTo(j(x0), y); g.lineTo(j(x1), y + (Math.random() - .5) * 4); g.stroke();
  }
}
function drawScribed(g, text, cx, cy, font, color) {
  /* burin-scored stroke: bright scratch above, dark scored line at center */
  g.font = font; g.textAlign = 'center'; g.textBaseline = 'alphabetic';
  g.fillStyle = 'rgba(255,252,244,.7)';
  g.fillText(text, cx, cy - 1.2);
  g.fillStyle = color;
  g.fillText(text, cx, cy);
}
function drawInk3(g, w, h) {
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 44px 'Suez One'";
  g.fillText('נבנה ביד', 726, 84);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  drawSpacedLTR(g, 'SEED 005', 683, 124, 6);
  g.fillStyle = '#8a877e'; g.font = "200 26px 'Heebo'"; g.textAlign = 'center';
  drawSpaced(g, 'הפיקסל האחרון הוא ההבדל בין מוצר ליצירה.', 390, 877, 4.68);
  const cells = [['מתחת לשנייה', 'זמן טעינה'], ['100', 'בליבת הנגישות'], ['מושלם', 'RTL']];
  cells.forEach(([val, key], i) => {
    const yv = 1000 + i * 192, yk = 1068 + i * 192;
    drawScribed(g, val, 390, yv, "900 44px 'Suez One'", '#3d3a35');
    g.fillStyle = '#8a877e'; g.font = "200 22px 'Heebo'"; g.textAlign = 'center';
    g.fillText(key, 390, yk);
  });
}
let sheet3Tex, sheet3Canvas, sheet3Ctx, sheet3Wire, sheet3InkFull;
function buildSheet3() {
  const W = 780, H = 1688;
  sheet3Wire = document.createElement('canvas'); sheet3Wire.width = W; sheet3Wire.height = H;
  const wg = sheet3Wire.getContext('2d'); drawPaperBase(wg, W, H); drawWireframe3(wg, W, H);
  sheet3InkFull = document.createElement('canvas'); sheet3InkFull.width = W; sheet3InkFull.height = H;
  const ig = sheet3InkFull.getContext('2d');
  drawPaperBase(ig, W, H);
  ig.globalAlpha = .55; ig.drawImage(sheet3Wire, 0, 0); ig.globalAlpha = 1;
  drawInk3(ig, W, H);
  sheet3Canvas = addInkBleed(sheet3InkFull);
  sheet3Tex = new THREE.CanvasTexture(sheet3Canvas); sheet3Tex.colorSpace = THREE.SRGBColorSpace; sheet3Tex.anisotropy = 8;
  const geo = new THREE.BoxGeometry(SHEET_W, .024, SHEET_D);
  const edge = new THREE.MeshStandardMaterial({ color: 0xd8d0bf, roughness: .85 });
  const face = new THREE.MeshBasicMaterial({ map: sheet3Tex });
  const sheet = new THREE.Mesh(geo, [edge, edge, face, edge, edge, edge]);
  sheet.castShadow = true; sheet.receiveShadow = true;
  sheet.position.set(SHEET3_X, .028, 0);
  sheet.rotation.y = -.01;
  scene.add(sheet);
  /* a caliper resting by the sheet — the tool for this section's action */
  const calMat = new THREE.MeshStandardMaterial({ color: 0xb0b6bc, roughness: .3, metalness: .9, envMapIntensity: 1.2 });
  const beam = new THREE.Mesh(new THREE.BoxGeometry(.7, .012, .045), calMat);
  beam.position.set(SHEET3_X + .72, .006, .5); beam.rotation.y = .5; beam.castShadow = true; scene.add(beam);
  const jaw1 = new THREE.Mesh(new THREE.BoxGeometry(.045, .012, .16), calMat);
  jaw1.position.set(SHEET3_X + .42, .006, .66); jaw1.rotation.y = .5; jaw1.castShadow = true; scene.add(jaw1);
  const jaw2 = new THREE.Mesh(new THREE.BoxGeometry(.045, .012, .13), calMat);
  jaw2.position.set(SHEET3_X + .58, .006, .56); jaw2.rotation.y = .5; jaw2.castShadow = true; scene.add(jaw2);
  contactShadow(SHEET3_X + .06, .04, SHEET_W * 1.35, SHEET_D * 1.12, .5);
  contactShadow(SHEET3_X + .62, .58, .8, .5, .45);
}

/* ---------- camera + scroll ---------- */
const camCurve = t => {
  /* approach: from the left end of the bench, settle over the hero sheet */
  const x = THREE.MathUtils.lerp(-6.35, HERO_X, easeInOut(t));
  return x;
};
function camTravel(u) {                                /* hero lock -> ch1 lock */
  const e = easeInOut(u);
  const x = THREE.MathUtils.lerp(HERO_X, SHEET2_X, e);
  camera.position.set(x, 1.44 + Math.sin(e * Math.PI) * .12, 1.9);
  camera.lookAt(x, -.05, .3);
}
function camSheet2Lock() {
  camera.position.set(SHEET2_X, 1.44, 1.9);
  camera.lookAt(SHEET2_X, -.05, .3);
}
function seg(t, a, b) { return clamp01((t - a) / (b - a)); }
function diePose(t) {
  if (!dieGroup) return;
  let p;
  if (t < .5) p = DIE_REST;
  else if (t < .62) {                              /* lift + glide over the sheet */
    const u = easeInOut(seg(t, .5, .62));
    p = { x: THREE.MathUtils.lerp(DIE_REST.x, DIE_HOVER.x, u),
          y: THREE.MathUtils.lerp(DIE_REST.y, DIE_HOVER.y, u),
          z: THREE.MathUtils.lerp(DIE_REST.z, DIE_HOVER.z, u) };
  } else if (t < .7) {                             /* the fall */
    const u = seg(t, .62, .7); const e = u * u;
    p = { x: DIE_HOVER.x, y: THREE.MathUtils.lerp(DIE_HOVER.y, DIE_PRESS.y, e), z: DIE_HOVER.z };
  } else if (t < .8) {                             /* dwell on the sheet, tiny settle */
    const u = seg(t, .7, .8);
    p = { x: DIE_PRESS.x, y: DIE_PRESS.y + Math.sin(u * Math.PI * 2) * .004 * (1 - u), z: DIE_PRESS.z };
  } else if (t < .92) {                            /* lift away and home */
    const u = easeInOut(seg(t, .8, .92));
    p = { x: THREE.MathUtils.lerp(DIE_PRESS.x, DIE_REST.x, u),
          y: THREE.MathUtils.lerp(DIE_PRESS.y, DIE_REST.y, u) + Math.sin(u * Math.PI) * .3,
          z: THREE.MathUtils.lerp(DIE_PRESS.z, DIE_REST.z, u) };
  } else p = DIE_REST;
  dieGroup.position.set(p.x, p.y, p.z);
  dieGroup.rotation.y = THREE.MathUtils.lerp(-.2, 0, seg(t, .5, .62)) + (t >= .92 || t < .5 ? -.0 : 0);
}
function updateCam(t) {
  const x = camCurve(t);
  const lift = Math.sin(Math.PI * clamp01(t)) * .1;
  const settle = easeInOut(t);
  camera.position.set(x, 1.62 - .18 * settle + lift, 1.62 + .28 * settle);
  camera.lookAt(x, THREE.MathUtils.lerp(.92, -.05, settle), THREE.MathUtils.lerp(-2.45, .3, settle));
}

/* ---------- boot ---------- */
(async () => {
  await loadFonts();
  buildSheet();
  buildSheet2();
  buildSheet3();
  wireBackup = (() => { const c = document.createElement('canvas'); c.width = 780; c.height = 1688;
    const g = c.getContext('2d'); drawPaperBase(g, 780, 1688); drawWireframe(g, 780, 1688); return c; })();
  setWipe(0);
  contactShadow(HERO_X + .06, .04, SHEET_W * 1.35, SHEET_D * 1.12, .5);
  contactShadow(HERO_X + .62, -1.24, .55, .45, .55);
  contactShadow(HERO_X + 1.55, -.55, .5, .4, .5);
  contactShadow(-6.9, -.62, .42, .36, .5);
  contactShadow(HERO_X + 1.15, -.68, .3, .26, .45);
  let scrollT = 0, scrollC = 0;
  const onScroll = () => {
    const max = document.getElementById('scroll').offsetHeight - innerHeight;
    scrollT = max > 0 ? scrollY / max : 0;
  };
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });
  window.__focusSheet3 = () => { window.__f3 = true; };
  window.__focusSheet2 = () => { window.__f2 = true; };
  function tick() {
    requestAnimationFrame(tick);
    if (window.__f3) {
      camera.position.set(SHEET3_X, 1.44, 1.9);
      camera.lookAt(SHEET3_X, -.05, .3);
    } else if (window.__f2) {
      camera.position.set(SHEET2_X, 1.44, 1.9);
      camera.lookAt(SHEET2_X, -.05, .3);
    } else {
      scrollC += (scrollT - scrollC) * .12;
      const t = clamp01(scrollC);
      if (t < .3) {                                  /* hero: approach + ink */
        const th = t / .3;
        updateCam(Math.min(th / .5, 1));
        setWipe((th - .3) / .6);
        setPress(0);
      } else if (t < .5) {                           /* hero -> ch1 travel */
        camTravel(seg(t, .3, .5));
      } else {                                       /* ch1: the press + lock */
        camSheet2Lock();
      }
      diePose(t);
      setPress(t < .5 ? 0 : seg(t, .66, .8));
    }
    renderer.render(scene, camera);
  }
  tick();
  window.__setProgress = p => { scrollT = scrollC = clamp01(p); };
})();
