# Ch3 עבודות — groundwork notes (probe 2026-09-10)

## Live DOM truth (390px, css px; canvas = x2)
- title "עבודות": Frank Ruhl Libre 900 28px bone ls 3.33, y 353 css (baseline ~380)
- sub "שלוש יצירות שכבר יצאו מהסדנה. תלחצו, תגללו, תבדקו אותי.": Heebo 100 12px dim, y 384 css, 2 lines
- 3 work-cards: x75 w240 h88 css (canvas 150/480x176), tops y 511/619/727 css
  - meta: name Frank Ruhl 900 15px bone at x110 (canvas 220), type Heebo 200 11px dim + ↗
  - rows: סושימי/אתר מסעדה פרימיום, The Sound Room/חנות אונליין, עורך וידאו/דף נחיתה לפרילנסר
  - thumbs: assets/work-{soshimi,verdant,videoeditor}.jpg — fetched into refs/

## Action concept (A storyboard: "3 finished pieces lifted off bench")
Three small walnut-framed mini-screens (the finished sites, thumbs as their screens)
glide in from off-bench right, one by one, and stand upright in a row above sheet4;
as each lands (soft thunk, tiny settle bounce like the die), its name + type
ink-stamps onto the sheet in the card row below it. Distinct from wipe/press/scribe:
sliding/standing physical objects + stamp reveal per row.

## Build plan
- SHEET4_X = SHEET3_X + 2.3; page 640vh -> ~760vh; timeline remap t<.8 -> t<.73-ish (keep old chain pacing: u = t/.73)
- card rows painted to probe coords; thumbs drawn into card paint from refs/*.jpg
- frames = BoxGeometry thin slabs, walnut edge material + screen face with thumb texture
- landing sequence per row: glide-in (easeOut) -> tilt upright -> settle bounce -> stamp (destination-in radial, reuse setPress pattern per-row)
- camera: travel3 + lock, same grammar as camTravel2
