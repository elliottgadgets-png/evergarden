# Ch4 סיפור — groundwork notes (probe 2026-09-10)

## Live DOM truth (390px, css px; canvas = x2)
Horizontal filmstrip track (cf-* classes), so x positions are track-relative, not layout.
Content order (RTL, rightmost first):
1. marker "פרק 03 — סיפור" Heebo 11px GOLD rgb(217,164,65)
2. "לכל עסק יש סיפור." cf-big Suez One 300 30px lh36 #f2e7d5
3. "האתר שלך הוא היצירה שמספרת אותו." (2 lines, h72)
4. "מתחיל בהקשבה." + sub "איך נראה פרויקט ראשון איתי" Heebo 200 14px 62% alpha
5. "ממשיך בבנייה." + sub "תהליך שקוף, שלב אחר שלב"
6. "נגמר בפרטים." + sub "הרגע שאתה רואה את האתר שלך חי"
7. "הסיפור שלך יכול להיות הבא." cf-big GOLD (closer)

## Action concept (A storyboard: sketch pinned to cork rail, annotated)
Distinct action #5: LIVE PENCIL-DRAWING. A hand pencil (the hero pencil prop travels over)
sketches the story as a small pencil study that DRAWS ITSELF stroke by stroke on a
pinned card (path-following reveal on pre-computed stroke polylines), then the
annotations (the cf-big beats) ink in beside it one at a time, right to left, like
marginalia. Ends with the gold closer stamped in case-gold (#b3852f paper-adapted).

## Build plan
- SHEET5_X = SHEET4_X + 2.3; page 760vh -> ~880vh; ch0-3 compress into tt<.68
- Sketch: 3-beat storyboard thumbnails (listen -> build -> details) as rough pencil
  polylines with per-stroke reveal fractions driven by a traveling pencil mesh
- Beats ink as marginalia at probe fonts (Suez 300 30css, Heebo 200 14css subs)
- Camera: travel4 + lock, same grammar
