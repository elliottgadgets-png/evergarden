# CH5 אור + CH6 outro — probe truth + design notes

## Live DOM probe (egprobe5/5b/6, css x2 for canvas)
- ch5 אור panel (data-ch="5"): visual-only except ONE cap line:
  "אתר יפה שאף אחד לא רואה — לא עובד." Heebo 200, 13css, dim, ls 2.34, centered x~195css, baseline y~737css → canvas 26px, ls 4.68, baseline 1475, center x 390.
- ch6 outro (data-ch="6"): pre "היצירה הבאה שיוצאת מהסדנה — שלך.", big "בוא נבנה<br>את שלך.", small "חנויות וורדפרס · דפי נחיתה · אתרי עסק", CTA "דברו איתי ↗" (x103 y494 w184 h53), meta row: "נבנה ביד, פרט אחר פרט" / "הקוד פתוח ↗" / "מההתחלה ↺".
- CTA must stay INERT in proof: phone number awaiting Itamar's approval (release gate from parent).

## CH5 design: the light reveal (distinct action #6)
- A brass banker's lamp stands at the sheet's right edge (base fixed on bench).
- Sequence: stem leans in over the paper (0-.3) → shade dips (.3-.44, settle wobble) →
  CLICK light on (.44-.52: PointLight + bulb warms) → warm pool grows on the sheet
  (.42-.78) revealing a faint pencil browser-window study (the site nobody sees) →
  the cap stamps inside the pool (.55-.85). Dust motes drift in the beam.
- Sheet is otherwise empty by design — the reveal IS the content.
- No wireframe placeholder strokes near y1475 (cap lands there) — strikethrough rule.
- Lamp: base cylinder r.15 + collar + stem .5 + cone shade (brass outer, warm inner) + bulb.
  Stem leans .14→.52 rad, shade counter-rotates to keep cone pointing down at paper.
- Light: PointLight 0xffc46b intensity 0→.9 at (SHEET6_X+.18,.5,-.15); warm pool tint
  radial rgba(255,196,107,.22) on sheet canvas; wire sketch masked destination-in radial.

## Timeline after ch5 (page 1000vh)
- ch0-4 compressed into tt<.63 (t=tt/.63; t-space: ch0-3 t<.68 via u3=t/.68,
  travel4 .68-.815, ch4 .815-1). travel5 .63-.815. ch5 .815-1.
- Lock verification values: ch1 .25, ch2 .31, ch3 .428, ch4 .63, travel5 .72, ch5 .999.

## CH6 outro design (next): the handover across the bench
- Not yet built. Content from probe above. Camera travel6 + final lock on outro sheet;
  handover = the finished work passes across the bench toward the viewer/client side.
