import bpy
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
cam=sc.camera
tgt=Vector((0.315,0.0,0.075))
def look_at(obj,pt):
    dd=pt-obj.location
    obj.rotation_euler=dd.to_track_quat('-Z','Y').to_euler()
cam.animation_data_clear()
steps=[(0,(0.35,-0.47,0.09)),(20,(0.346,-0.452,0.089)),(34,(0.342,-0.44,0.088)),(48,(0.338,-0.425,0.087)),(60,(0.334,-0.41,0.086)),(71,(0.330,-0.398,0.085))]
for f,loc in steps:
    sc.frame_set(f); cam.location=loc; look_at(cam,tgt)
    cam.keyframe_insert('location'); cam.keyframe_insert('rotation_euler')
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("LOCK DONE")
