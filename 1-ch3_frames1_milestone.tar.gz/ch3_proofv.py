import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
sc.render.engine='CYCLES'; sc.cycles.device='CPU'; sc.cycles.samples=16; sc.cycles.use_denoising=True
sc.render.resolution_x=390; sc.render.resolution_y=844; sc.render.resolution_percentage=100
for f in (71,20,48,34,60,25):
    sc.frame_set(f)
    sc.render.filepath=f'/tmp/ch3_f{f:03d}.png'
    bpy.ops.render.render(write_still=True)
print("PROOF DONE")
