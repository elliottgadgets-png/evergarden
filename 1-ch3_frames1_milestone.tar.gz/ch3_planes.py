import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
INFO={'frame1':('tex_sushimi.png',18),'frame2':('tex_soundroom.png',32),'frame3':('tex_video.png',46)}
W,H=0.052,0.068
for name,(tex,L) in INFO.items():
    old=bpy.data.objects[name+'_scr']
    mat=old.data.materials[0]
    # capture world transform
    wt=old.matrix_world.copy()
    root=bpy.data.objects[name]
    bpy.data.objects.remove(old, do_unlink=True)
    bpy.ops.mesh.primitive_plane_add(size=2, rotation=(math.pi/2,0,0))
    p=bpy.context.active_object; p.name=name+'_scr'
    p.scale=(W/2,H/2,1)
    bpy.ops.object.transform_apply(scale=True, rotation=False)
    # move to old screen's front face (2mm toward camera = -y)
    c=wt.translation
    p.location=(c.x, c.y-0.0026, c.z)
    p.data.materials.append(mat)
    p.parent=root
    p.matrix_parent_inverse=root.matrix_world.inverted()
# point textures back to originals and rebuild emission with mapping sanity
for name,(tex,L) in INFO.items():
    m=bpy.data.objects[name+'_scr'].data.materials[0]
    for n in m.node_tree.nodes:
        if n.type=='TEX_IMAGE':
            n.image=bpy.data.images.load(f'/home/sandbox/evergarden-cine/{tex}')
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("PLANES DONE")
