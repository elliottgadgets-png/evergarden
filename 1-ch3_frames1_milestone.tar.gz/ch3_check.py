import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
sc.frame_set(71)
deps=bpy.context.evaluated_depsgraph_get()
for name in ('frame1','frame2','frame3'):
    p=bpy.data.objects[name+'_scr']
    print(name+'_scr', [round(v,4) for v in p.evaluated_get(deps).matrix_world.translation], "polys", len(p.data.polygons))
