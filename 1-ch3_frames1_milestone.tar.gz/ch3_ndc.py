import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
cam=sc.camera
print("lens",cam.data.lens,"sensor_fit",cam.data.sensor_fit,"sensor_width",cam.data.sensor_width)
for f in (0,71):
    sc.frame_set(f)
    print("f",f,"cam loc",[round(x,3) for x in cam.location])
    for n in ('frame1','frame2','frame3'):
        o=bpy.data.objects[n]
        ndc=world_to_camera_view(sc,cam,o.matrix_world.translation)
        print(" ",n,"ndc x",round(ndc.x,3),"y",round(ndc.y,3))
