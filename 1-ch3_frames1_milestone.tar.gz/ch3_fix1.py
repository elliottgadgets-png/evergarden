import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
cam=sc.camera
cam.data.lens=38
# tighten trio: frame1 0.26, frame2 0.315, frame3 0.37
for n,x in (('frame1',0.26),('frame2',0.315),('frame3',0.37)):
    r=bpy.data.objects[n]
    dx=x-r.location.x
    r.location.x=x
    for c in r.children:
        c.matrix_world.translation += Vector((dx,0,0))
tgt=Vector((0.315,0.0,0.062))
def look_at(obj,pt):
    d=pt-obj.location
    obj.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
cam.animation_data_clear()
for f,loc in ((0,(0.345,-0.46,0.145)),(36,(0.335,-0.43,0.138)),(71,(0.325,-0.395,0.13))):
    sc.frame_set(f)
    cam.location=loc
    look_at(cam,tgt)
    cam.keyframe_insert('location'); cam.keyframe_insert('rotation_euler')
cam.data.dof.aperture_fstop=4.5
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("FIX DONE")
