import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
MAP={'frame1_scr':'tex_sushimi_r.png','frame2_scr':'tex_soundroom_r.png','frame3_scr':'tex_video_r.png'}
for obj,tex in MAP.items():
    m=bpy.data.objects[obj].data.materials[0]
    for n in m.node_tree.nodes:
        if n.type=='TEX_IMAGE':
            n.image=bpy.data.images.load(f'/home/sandbox/evergarden-cine/{tex}')
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("TEXFIX DONE")
