import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
LAND={'frame1':18,'frame2':32,'frame3':46}
for name,L in LAND.items():
    m=bpy.data.objects[name+'_scr'].data.materials[0]
    nt=m.node_tree
    if nt.animation_data: nt.animation_data_clear()
    sock=nt.nodes['Principled BSDF'].inputs['Emission Strength']
    flick=[(0,0.0),(L-1,0.0),(L,0.7),(L+1,0.1),(L+2,1.35),(L+3,0.45),(L+4,1.05),(L+6,1.0),(71,1.0)]
    for f,v in flick:
        sc.frame_set(f); sock.default_value=v
        sock.keyframe_insert('default_value')
    if nt.animation_data and nt.animation_data.action:
        for fc in nt.animation_data.action.fcurves:
            for kp in fc.keyframe_points: kp.interpolation='CONSTANT'
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("EMIT DONE")
