import bpy, math
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
sc.frame_start=0; sc.frame_end=71

CZ=0.069
def land(name, L, tilt0=8.0):
    r=bpy.data.objects[name]
    cz=r.location.z
    def key(f,z,rz):
        sc.frame_set(f)
        r.location.z=z; r.rotation_euler=(0,0,math.radians(rz))
        r.keyframe_insert('location'); r.keyframe_insert('rotation_euler')
    key(L-14,cz+0.35,tilt0)
    key(L,cz,0.0)
    key(L+2,cz+0.009,-1.5)
    key(L+4,cz+0.002,0.6)
    key(L+6,cz,0.0)
    key(71,cz,0.0)
    # screen emission ramp: 0 until L, full by L+7
    scr=bpy.data.objects[name+'_scr'].data.materials[0]
    b=scr.node_tree.nodes['Principled BSDF']
    sock=b.inputs['Emission Strength']
    for f,v in ((L-1,0.0),(L+7,2.6)):
        sc.frame_set(f); sock.default_value=v
        sock.keyframe_insert('default_value')
    sc.frame_set(0); sock.default_value=0.0; sock.keyframe_insert('default_value')

land('frame1',18)
land('frame2',32)
land('frame3',46)

# camera: wide-ish 3/4, slow push-in
cam=sc.camera
cam.data.lens=50
def look_at(obj,pt):
    d=pt-obj.location
    obj.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
from mathutils import Vector
tgt=(Vector((0.315,0.0,0.075)))
for f,loc in ((0,(0.40,-0.36,0.16)),(36,(0.385,-0.335,0.15)),(71,(0.36,-0.30,0.135))):
    sc.frame_set(f)
    cam.location=loc
    look_at(cam,tgt)
    cam.keyframe_insert('location'); cam.keyframe_insert('rotation_euler')
# focus target
fo=bpy.data.objects['focus']
for f,p in ((0,tgt),(71,tgt)):
    sc.frame_set(f); fo.location=p; fo.keyframe_insert('location')
cam.data.dof.focus_object=fo
cam.data.dof.aperture_fstop=4.0
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("ANIM DONE")
