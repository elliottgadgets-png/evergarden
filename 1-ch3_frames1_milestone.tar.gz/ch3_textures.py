from PIL import Image, ImageDraw, ImageFont
HE='/usr/share/fonts/truetype/noto/NotoSansHebrew-Bold.ttf'
HE2='/usr/share/fonts/truetype/noto/NotoSansHebrew-Regular.ttf'
def R(s): return s[::-1]  # RTL reverse for PIL
def label_strip(d, W, H, bg=(10,10,12)):
    d.rectangle([0,H-64,W,H], fill=bg)
    f=ImageFont.truetype(HE2, 30)
    t=R("דמו אינטראקטיבי לעסק פיקטיבי")
    bb=d.textbbox((0,0),t,font=f)
    d.text(((W-(bb[2]-bb[0]))/2, H-50), t, font=f, fill=(235,235,235))

W,H=512,672

# 1. SUSHIMI - warm food app
im=Image.new('RGB',(W,H),(255,244,230)); d=ImageDraw.Draw(im)
d.rectangle([0,0,W,110], fill=(200,60,40))
f=ImageFont.truetype(HE,64)
t=R("סושימי"); bb=d.textbbox((0,0),t,font=f)
d.text(((W-(bb[2]-bb[0]))/2,22),t,font=f,fill=(255,255,255))
# menu cards with roll icons
for i,(y,name) in enumerate([(150,"מגורים סלמון"),(300,"דרגון רול"),(450,"סASHIמי מיקס".replace('ASHI','ש'))]):
    d.rounded_rectangle([30,y,W-30,y+120], radius=18, fill=(255,255,255), outline=(220,200,180), width=3)
    d.ellipse([55,y+25,125,y+95], fill=(240,140,90), outline=(180,80,50), width=4)
    d.ellipse([72,y+42,108,y+78], fill=(250,230,210))
    fn=ImageFont.truetype(HE2,40)
    d.text((W-60-d.textlength(R(name),font=fn), y+38), R(name), font=fn, fill=(60,40,30))
label_strip(d,W,H)
im.save('tex_sushimi.png')

# 2. THE SOUND ROOM - dark blue audio
im=Image.new('RGB',(W,H),(12,18,38)); d=ImageDraw.Draw(im)
f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',44)
t="THE SOUND ROOM"; bb=d.textbbox((0,0),t,font=f)
d.text(((W-(bb[2]-bb[0]))/2,40),t,font=f,fill=(120,200,255))
# waveform bars
import math,random
random.seed(7)
for i in range(40):
    x=30+i*11.3
    h=40+120*abs(math.sin(i*0.7))*random.uniform(0.5,1.0)
    d.rounded_rectangle([x,300-h/2,x+7,300+h/2], radius=3, fill=(60,150,255))
# play button
d.ellipse([W/2-55,420,W/2+55,530], fill=(60,150,255))
d.polygon([(W/2-15,450),(W/2-15,500),(W/2+28,475)], fill=(12,18,38))
# track rows
for y in (570,615):
    d.rounded_rectangle([30,y,W-30,y+32], radius=8, fill=(25,35,60))
    d.rounded_rectangle([30,y,30+(W-60)*random.uniform(0.3,0.9),y+32], radius=8, fill=(50,110,200))
label_strip(d,W,H,bg=(6,10,22))
im.save('tex_soundroom.png')

# 3. VIDEO EDITOR - purple timeline
im=Image.new('RGB',(W,H),(28,22,36)); d=ImageDraw.Draw(im)
f=ImageFont.truetype(HE,52)
t=R("עורך וידאו"); bb=d.textbbox((0,0),t,font=f)
d.text(((W-(bb[2]-bb[0]))/2,24),t,font=f,fill=(220,180,255))
# preview pane
d.rounded_rectangle([24,110,W-24,360], radius=10, fill=(45,35,60), outline=(120,90,160), width=3)
d.polygon([(W/2-25,200),(W/2-25,270),(W/2+35,235)], fill=(200,160,240))
# timeline tracks
cols=[(150,90,220),(220,120,160),(120,200,140),(240,170,80)]
for tr,y in enumerate((400,455,510)):
    d.rectangle([24,y,W-24,y+40], fill=(38,30,50))
    x=30
    random.seed(tr+1)
    while x<W-70:
        wseg=random.randint(50,130)
        d.rounded_rectangle([x,y+4,min(x+wseg,W-30),y+36], radius=6, fill=cols[(tr)%4] if random.random()>0.3 else cols[(tr+1)%4])
        x+=wseg+8
# playhead
d.rectangle([W//2-2,395,W//2+2,556], fill=(255,90,90))
label_strip(d,W,H,bg=(18,14,26))
im.save('tex_video.png')
print("TEXTURES DONE")
