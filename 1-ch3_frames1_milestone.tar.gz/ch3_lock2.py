import bpy
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
cam=sc.camera
tgt=Vector((0.315,0.0,0.075))
def look_at(obj,pt):
    dd=pt-obj.location
    obj.rotation_euler=dd.to_track_quat('-Z','Y').to_euler()
cam.animation_data_clear()
steps=[(0,(0.35,-0.47,0.09)),(20,(0.344,-0.452,0.089)),(34,(0.338,-0.44,0.088)),(48,(0.330,-0.43,0.087)),(60,(0.321,-0.42,0.086)),(71,(0.315,-0.412,0.085))]
for f,loc in steps:
    sc.frame_set(f); cam.location=loc; look_at(cam,tgt)
    cam.keyframe_insert('location'); cam.keyframe_insert('rotation_euler')
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("LOCK2 DONE")
