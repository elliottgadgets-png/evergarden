import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
sc.frame_set(71)
deps=bpy.context.evaluated_depsgraph_get()
for name in ('frame1','frame2','frame3'):
    root=bpy.data.objects[name]
    rw=root.evaluated_get(deps).matrix_world.translation
    p=bpy.data.objects[name+'_scr']
    p.parent=None
    p.location=(rw.x, -0.0027, rw.z)
    p.parent=root
    p.matrix_parent_inverse=root.matrix_world.inverted()
    print(name, "root world", [round(v,4) for v in rw], "plane", [round(v,4) for v in p.location])
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("PLANES2 DONE")
