import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
cam=sc.camera
tgt=Vector((0.315,0.0,0.085))
def look_at(obj,pt):
    d=pt-obj.location
    obj.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
cam.animation_data_clear()
for f,loc in ((0,(0.35,-0.47,0.105)),(36,(0.34,-0.44,0.10)),(71,(0.328,-0.35,0.095))):
    sc.frame_set(f)
    cam.location=loc
    look_at(cam,tgt)
    cam.keyframe_insert('location'); cam.keyframe_insert('rotation_euler')
cam.data.dof.aperture_fstop=5.0
# focus target follows
fo=bpy.data.objects['focus']
if fo.animation_data: fo.animation_data_clear()
for f in (0,71):
    sc.frame_set(f); fo.location=tgt; fo.keyframe_insert('location')
# warm wall wash behind-right of trio (banker-lamp foreshadow position)
bpy.ops.object.light_add(type='AREA', location=(0.55,0.75,0.45))
w=bpy.context.active_object; w.name='wallwash'
w.data.energy=14; w.data.shape='DISK'; w.data.size=0.5
w.data.color=(1.0,0.72,0.45)
d=(Vector((0.45,1.2,0.25))-w.location)
w.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
w.visible_camera=False
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("FIX2 DONE")
