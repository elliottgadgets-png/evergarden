import bpy, sys, time, os
start, end = int(sys.argv[-2]), int(sys.argv[-1])
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc = bpy.context.scene
sc.render.engine='CYCLES'; sc.cycles.device='CPU'; sc.cycles.samples=64; sc.cycles.use_denoising=True; sc.cycles.use_adaptive_sampling=True; sc.cycles.adaptive_threshold=0.02; sc.cycles.adaptive_min_samples=16
sc.render.resolution_x=390; sc.render.resolution_y=844; sc.render.resolution_percentage=100
sc.render.image_settings.file_format='PNG'
os.makedirs('/home/sandbox/evergarden-cine/frames_ch3', exist_ok=True)
for f in range(start, end+1):
    p = f'/home/sandbox/evergarden-cine/frames_ch3/f{f:03d}.png'
    if os.path.exists(p): continue
    sc.frame_set(f); sc.render.filepath=p
    t0=time.time(); bpy.ops.render.render(write_still=True)
    print('FRAME', f, round(time.time()-t0,1))
print('BATCH_DONE')
