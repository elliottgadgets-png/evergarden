import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
sc=bpy.context.scene

# 1. hide caliper + slab from render (parked out of this chapter)
for o in sc.objects:
    if o.name.startswith('cal_') or o.name=='slab':
        o.hide_render=True

# 2. clear camera animation
cam=sc.camera
if cam.animation_data: cam.animation_data_clear()
fo=bpy.data.objects.get('focus')
if fo and fo.animation_data: fo.animation_data_clear()

# 3. materials
def mat_principled(name,color,rough=0.4,metal=0.0,emit=None,estr=0.0):
    m=bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes=True
    b=m.node_tree.nodes['Principled BSDF']
    b.inputs['Base Color'].default_value=(*color,1)
    b.inputs['Roughness'].default_value=rough
    b.inputs['Metallic'].default_value=metal
    if emit:
        b.inputs['Emission Color'].default_value=(*emit,1)
        b.inputs['Emission Strength'].default_value=estr
    return m
alu=mat_principled('frame_alu',(0.16,0.17,0.18),rough=0.3,metal=0.9)
scr_sushimi=mat_principled('scr1',(0.02,0.02,0.02),rough=0.25,emit=(0.85,0.45,0.2),estr=0.0)
scr_sound=mat_principled('scr2',(0.02,0.02,0.02),rough=0.25,emit=(0.25,0.5,0.9),estr=0.0)
scr_video=mat_principled('scr3',(0.02,0.02,0.02),rough=0.25,emit=(0.55,0.3,0.75),estr=0.0)

# 4. frame builder: portrait frame standing on bench (bench top z=0.03)
def make_frame(name, x, scr_mat):
    W,H,D=0.052,0.068,0.004  # 52x68mm screen area
    BZ=0.005  # bezel width
    coll=[]
    # bezel: 4 bars
    def bar(n,loc,scale):
        bpy.ops.mesh.primitive_cube_add(location=loc)
        o=bpy.context.active_object; o.name=n; o.scale=scale
        bpy.ops.object.transform_apply(scale=True)
        o.data.materials.append(alu); coll.append(o); return o
    z0=0.03  # bench top
    cx,cz=x, z0+H/2+BZ
    bar(name+'_top',(cx,0,cz+H/2+BZ/2),((W+2*BZ)/2,BZ/2,BZ/2))
    bar(name+'_bot',(cx,0,cz-H/2-BZ/2),((W+2*BZ)/2,BZ/2,BZ/2))
    bar(name+'_L',(cx-W/2-BZ/2,0,cz),(BZ/2,BZ/2,H/2))
    bar(name+'_R',(cx+W/2+BZ/2,0,cz),(BZ/2,BZ/2,H/2))
    # screen
    bpy.ops.mesh.primitive_cube_add(location=(cx,0,cz))
    s=bpy.context.active_object; s.name=name+'_scr'; s.scale=(W/2,0.0012,H/2)
    bpy.ops.object.transform_apply(scale=True)
    s.data.materials.append(scr_mat); coll.append(s)
    # easel back leg
    bpy.ops.mesh.primitive_cube_add(location=(cx,0.028,cz-0.01))
    e=bpy.context.active_object; e.name=name+'_easel'; e.scale=(0.004,0.0015,0.045)
    e.rotation_euler=(math.radians(-22),0,0)
    bpy.ops.object.transform_apply(scale=True)
    e.data.materials.append(alu); coll.append(e)
    # parent all to an empty for animation
    bpy.ops.object.empty_add(location=(cx,0,cz))
    root=bpy.context.active_object; root.name=name
    for o in coll:
        o.parent=root
        o.matrix_parent_inverse=root.matrix_world.inverted()
    return root

f1=make_frame('frame1',0.24,scr_sushimi)   # סושימי warm
f2=make_frame('frame2',0.315,scr_sound)    # Sound Room blue
f3=make_frame('frame3',0.39,scr_video)     # video editor purple

bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("BUILT", [o.name for o in sc.objects if o.name.startswith('frame')])
