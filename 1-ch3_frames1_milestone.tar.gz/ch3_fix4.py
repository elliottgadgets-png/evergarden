import bpy
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
w=bpy.data.objects['wallwash']
w.data.energy=16
d=(Vector((0.38,1.65,0.55))-w.location)
w.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("FIX4 DONE")
