import bpy
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene
# wall albedo lift
m=bpy.data.materials['wall']
for n in m.node_tree.nodes:
    if n.type=='BSDF_PRINCIPLED':
        n.inputs['Base Color'].default_value=(0.014,0.010,0.008,1)
# wallwash reposition/boost, aimed at wall behind trio
w=bpy.data.objects['wallwash']
w.location=(0.5,0.85,0.32)
w.data.energy=30; w.data.size=0.45
d=(Vector((0.38,1.65,0.30))-w.location)
w.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
# camera: slightly lower, target slightly lower
cam=sc.camera
tgt=Vector((0.315,0.0,0.075))
def look_at(obj,pt):
    dd=pt-obj.location
    obj.rotation_euler=dd.to_track_quat('-Z','Y').to_euler()
cam.animation_data_clear()
for f,loc in ((0,(0.35,-0.47,0.09)),(36,(0.34,-0.44,0.087)),(71,(0.328,-0.35,0.083))):
    sc.frame_set(f)
    cam.location=loc
    look_at(cam,tgt)
    cam.keyframe_insert('location'); cam.keyframe_insert('rotation_euler')
fo=bpy.data.objects['focus']
if fo.animation_data: fo.animation_data_clear()
for f in (0,71):
    sc.frame_set(f); fo.location=tgt; fo.keyframe_insert('location')
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("FIX3 DONE")
