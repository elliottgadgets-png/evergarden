import bpy
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
sc=bpy.context.scene

TEX={'frame1':'tex_sushimi.png','frame2':'tex_soundroom.png','frame3':'tex_video.png'}
LAND={'frame1':18,'frame2':32,'frame3':46}

for name,tex in TEX.items():
    scr=bpy.data.objects[name+'_scr']
    m=scr.data.materials[0]
    nt=m.node_tree
    b=nt.nodes['Principled BSDF']
    # remove old anim on emission strength
    if nt.animation_data: nt.animation_data_clear()
    img=bpy.data.images.load(f'/home/sandbox/evergarden-cine/{tex}')
    t=nt.nodes.new('ShaderNodeTexImage'); t.image=img
    nt.links.new(t.outputs['Color'], b.inputs['Emission Color'])
    # subtle base so unlit screen reads dark glass
    b.inputs['Base Color'].default_value=(0.01,0.012,0.015,1)
    b.inputs['Roughness'].default_value=0.2
    sock=b.inputs['Emission Strength']
    L=LAND[name]
    flick=[(0,0.0),(L-1,0.0),(L,0.9),(L+1,0.12),(L+2,1.7),(L+3,0.5),(L+4,1.35),(L+6,1.3),(71,1.3)]
    for f,v in flick:
        sc.frame_set(f); sock.default_value=v
        sock.keyframe_insert('default_value')
    # steppy flicker: constant interpolation
    if nt.animation_data and nt.animation_data.action:
        for fc in nt.animation_data.action.fcurves:
            for kp in fc.keyframe_points: kp.interpolation='CONSTANT'

# staged push-in
cam=sc.camera
tgt=Vector((0.315,0.0,0.075))
def look_at(obj,pt):
    dd=pt-obj.location
    obj.rotation_euler=dd.to_track_quat('-Z','Y').to_euler()
cam.animation_data_clear()
steps=[(0,(0.35,-0.47,0.09)),(20,(0.346,-0.452,0.089)),(34,(0.342,-0.435,0.088)),(48,(0.336,-0.41,0.086)),(60,(0.331,-0.375,0.084)),(71,(0.328,-0.35,0.083))]
for f,loc in steps:
    sc.frame_set(f); cam.location=loc; look_at(cam,tgt)
    cam.keyframe_insert('location'); cam.keyframe_insert('rotation_euler')

# bigger easel pegs
for name in TEX:
    e=bpy.data.objects[name+'_easel']
    e.scale.x*=1.6; e.scale.y*=1.6
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/frames1.blend")
print("FINAL1 DONE")
