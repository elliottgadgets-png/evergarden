import bpy, sys
bpy.ops.wm.open_mainfile(filepath='outro1.blend')
sc=bpy.context.scene
sc.render.engine='CYCLES'
sc.cycles.samples=16
sc.cycles.use_denoising=True
sc.render.resolution_x=390; sc.render.resolution_y=844
frames=[int(x) for x in sys.argv[sys.argv.index('--')+1:]] if '--' in sys.argv else [0,8,16,19,21,24,40,71]
import os
os.makedirs('/tmp/ch6b',exist_ok=True)
for f in frames:
    sc.frame_set(f)
    sc.render.filepath='/tmp/ch6b/f%03d.png'%f
    bpy.ops.render.render(write_still=True)
    print('STILL', f)
