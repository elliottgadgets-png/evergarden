import bpy
from mathutils import Matrix
bpy.ops.wm.open_mainfile(filepath='lamp1.blend')
sc=bpy.context.scene
sc.frame_start=0; sc.frame_end=71; sc.render.fps=24

# ---- freeze CH5 end state: lights constant at end values ----
END={'key':1.2,'fill':0.3,'top':0.5,'practical':0.35,'rim':2.0,'wallwash':24.0,'lamp_glow':2.2,'lamp_pool':20.0}
for n,e in END.items():
    ob=bpy.data.objects[n]
    if ob.data.animation_data: ob.data.animation_data_clear()
    ob.data.energy=e
# emissions constant at end state
for matname,stren in [('lamp_green',0.65),('lamp_bulbmat',4.0)]:
    m=bpy.data.materials[matname]
    if m.node_tree.animation_data: m.node_tree.animation_data_clear()
    m.node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value=stren
# chain static, camera/focus anims cleared
ch=bpy.data.objects['lamp_chain_root']
if ch.animation_data: ch.animation_data_clear()
ch.rotation_euler=(0,0,0)
cam=bpy.data.objects['Camera']
if cam.animation_data: cam.animation_data_clear()
tgt=bpy.data.objects['focus']
if tgt.animation_data: tgt.animation_data_clear()

# ---- page slide ----
paper=bpy.data.objects['paper']
# parent strokes to paper (both world-baked, paper at origin -> identity parentinv)
for o in bpy.data.objects:
    if o.name.startswith('stroke'):
        if o.animation_data: o.animation_data_clear()
        if o.data.animation_data: o.data.animation_data_clear()
        o.data.bevel_factor_end=1.0
        o.parent=paper
        o.matrix_parent_inverse=Matrix.Identity(4)
# pencil parked right of paper, static
pr=bpy.data.objects['pencil_root']
if pr.animation_data: pr.animation_data_clear()
pr.location=(0.185,-0.37,0.0334); pr.rotation_euler=(0.0,1.5359,0.6)
# slide: rest f0-10, glide f10-40 (bezier ease), tiny settle rock f40-48, hold to 71
DX,DY=-0.265,-0.30
for f,loc in [(0,(0,0,0)),(10,(0,0,0)),(40,(DX,DY,0)),(71,(DX,DY,0))]:
    paper.location=loc; paper.keyframe_insert('location',frame=f)
for f,rx in [(0,0.0),(10,0.0),(25,-0.035),(40,0.0),(44,0.012),(48,0.0),(71,0.0)]:
    paper.rotation_euler=(rx,0,0); paper.keyframe_insert('rotation_euler',frame=f)
# lamp spill: warm area light over the work area (motivated by the lit lamp)
sp=bpy.data.lights.new('lamp_spill','AREA'); sp.energy=10.0; sp.color=(1.0,0.7,0.4); sp.shape='DISK'; sp.size=0.35
spo=bpy.data.objects.new('lamp_spill',sp); bpy.context.collection.objects.link(spo)
spo.location=(0.1,-0.05,0.5); spo.rotation_euler=(0,0,0)
# freeze screens lit from f0 (CH5 continuity): kill inherited CH3 ignition fcurves
for mn in ['scr1','scr2','scr3']:
    m=bpy.data.materials.get(mn)
    if m and m.use_nodes:
        if m.node_tree.animation_data: m.node_tree.animation_data_clear()
        for nd in m.node_tree.nodes:
            if nd.type=='BSDF_PRINCIPLED' and nd.inputs.get('Emission Strength'):
                nd.inputs['Emission Strength'].default_value=1.0
lcd=bpy.data.materials.get('lcd')
if lcd and lcd.use_nodes:
    if lcd.node_tree.animation_data: lcd.node_tree.animation_data_clear()
    for nd in lcd.node_tree.nodes:
        if nd.type=='MAPPING':
            nd.inputs[1].default_value[0]=0.5
# camera: medium on paper -> eases with the arriving page, background keeps screens+lamp
for f,cloc,tloc in [(0,(0.24,-0.50,0.28),(0.30,0.0,0.035)),
                    (10,(0.24,-0.50,0.28),(0.30,0.0,0.035)),
                    (40,(0.06,-0.76,0.40),(0.03,-0.08,0.02)),
                    (71,(0.06,-0.76,0.40),(0.03,-0.08,0.02))]:
    cam.location=cloc; cam.keyframe_insert('location',frame=f)
    tgt.location=tloc; tgt.keyframe_insert('location',frame=f)
cam.data.lens=46
bpy.ops.wm.save_mainfile(filepath='outro1.blend')
print('SAVED outro1.blend')
