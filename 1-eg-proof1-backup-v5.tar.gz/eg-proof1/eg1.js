/* EVERGARDEN eg-v1 — THE BUILDER'S WORKBENCH (hero slot, world scaffold).
   World: one long walnut workbench in a sunlit workshop. Warm plaster wall,
   paned window (daylight key), shelf of colored ink bottles, hanging tools,
   green-enamel shop lamps. On the bench: cutting mat, pencil cup, ruler,
   eraser, succulent, ink bottle. The hero page is a bone sheet on the bench:
   faint pencil wireframe underneath, ink draws over it as you scroll (RTL wipe).
   Palette from the live evergarden CSS: ink #14100c, bone #ece9e2, dim #8a877e,
   ember #e8862e, case #ffd28a, gold #D9A441 — rebalanced to DAYLIGHT per Itamar:
   color and life, no dark minimalism.
   Hero DOM truth (eg-live-ch0.png, x1.071): headline Suez One 900 30css=60px
   baselines ~1250/1335 centered; sub Heebo 300 28px ls 1.68 baseline ~1410;
   hint ember baseline ~1490; wordmark top-right. Light-sheet ink adaptation
   disclosed: sub #C4BCAB-on-black becomes #6b655a on bone. */
import * as THREE from './vendor/three.module.js';

const INK = '#14100c', BONE = '#f2ede3', DIM = '#6b655a', MID = '#55504a', EMBER = '#c05f1a', GOLD = '#b3852f';
/* PLACEHOLDER demo number - swap this one line for the real number on Itamar's approval */
const CTA_PHONE = '050-000-0000';
/* bidi fix (critic, chain-wide): canvas paragraph direction defaults to LTR, which parks
   sentence-final weak punctuation of Hebrew lines at the visual line START. Any string
   containing Hebrew forces its context to RTL paragraph direction. */
const _fillText = CanvasRenderingContext2D.prototype.fillText;
CanvasRenderingContext2D.prototype.fillText = function (text, x, y, mw) {
  if (/[\u0590-\u05FF]/.test(text) && this.direction !== 'rtl') this.direction = 'rtl';
  return _fillText.call(this, text, x, y, mw);
};
const PAPER = '#f2ede3', PENCIL = 'rgba(96,106,122,.5)';

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
document.getElementById('stage').appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xe4d8c2);
const camera = new THREE.PerspectiveCamera(54, innerWidth / innerHeight, .05, 80);

/* ---------- canvas helpers ---------- */
function ctex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}
function drawSpaced(g, text, cx, cy, spacing) {
  const ch = [...text];
  const ws = ch.map(c => g.measureText(c).width);
  const total = ws.reduce((a, b) => a + b, 0) + spacing * (ch.length - 1);
  let x = cx + total / 2;
  const prev = g.textAlign; g.textAlign = 'right';
  for (let i = 0; i < ch.length; i++) { g.fillText(ch[i], x, cy); x -= ws[i] + spacing; }
  g.textAlign = prev;
}
function drawSpacedLTR(g, text, cx, cy, spacing) {
  const ch = [...text];
  const ws = ch.map(c => g.measureText(c).width);
  const total = ws.reduce((a, b) => a + b, 0) + spacing * (ch.length - 1);
  let x = cx - total / 2;
  const prev = g.textAlign; g.textAlign = 'left';
  for (let i = 0; i < ch.length; i++) { g.fillText(ch[i], x, cy); x += ws[i] + spacing; }
  g.textAlign = prev;
}
function spacedW(g, text, spacing) {
  return [...text].reduce((a, c) => a + g.measureText(c).width, 0) + spacing * (text.length - 1);
}
const clamp01 = t => Math.min(1, Math.max(0, t));
const easeInOut = t => t * t * (3 - 2 * t);

async function loadFonts() {
  await Promise.all([
    document.fonts.load("900 60px 'Suez One'", 'האתר הזה נבנה מול'),
    document.fonts.load("300 28px 'Heebo'", 'לא תבנית דרג'),
    document.fonts.load("200 22px 'Heebo'", 'SEED 005'),
    document.fonts.load("400 26px 'Heebo'", 'גלול והעבודה מתחילה'),
  ]);
  await document.fonts.ready;
}

/* ---------- lighting: daylight + shop lamps ---------- */
scene.add(new THREE.AmbientLight(0xf0e4d0, .55));
{
  const envC = document.createElement('canvas'); envC.width = 256; envC.height = 128;
  const eg = envC.getContext('2d');
  const gr = eg.createLinearGradient(0, 0, 0, 128);
  gr.addColorStop(0, '#f5ead2'); gr.addColorStop(.55, '#cbb694'); gr.addColorStop(1, '#5f4a30');
  eg.fillStyle = gr; eg.fillRect(0, 0, 256, 128);
  const win = eg.createRadialGradient(64, 44, 4, 64, 44, 34);
  win.addColorStop(0, 'rgba(255,252,240,1)'); win.addColorStop(1, 'rgba(255,252,240,0)');
  eg.fillStyle = win; eg.fillRect(0, 0, 256, 128);
  const envTex = new THREE.CanvasTexture(envC);
  envTex.mapping = THREE.EquirectangularReflectionMapping;
  envTex.colorSpace = THREE.SRGBColorSpace;
  scene.environment = envTex;
}
const sun = new THREE.DirectionalLight(0xfff2dc, 2.6);
sun.position.set(-6, 5.2, 2.4); sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -9; sun.shadow.camera.right = 9;
sun.shadow.camera.top = 6; sun.shadow.camera.bottom = -4;
sun.shadow.bias = -.002; sun.shadow.radius = 7; scene.add(sun);
const fill = new THREE.DirectionalLight(0xdfe8f0, .5);   /* cool bounce off the wall */
fill.position.set(4, 2.5, 4); scene.add(fill);

/* green-enamel shop lamp */
const lamps = [];
function shopLamp(x, z, drop) {
  const g = new THREE.Group();
  const ceilY = 3.4;
  const cord = new THREE.Mesh(new THREE.CylinderGeometry(.008, .008, drop, 6),
    new THREE.MeshStandardMaterial({ color: 0x2b2622, roughness: .8 }));
  cord.position.set(0, ceilY - drop / 2, 0); g.add(cord);
  const shade = new THREE.Mesh(new THREE.ConeGeometry(.22, .17, 28, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x2e5b4a, roughness: .16, metalness: .35, side: THREE.DoubleSide, envMapIntensity: 1.2 }));
  shade.position.set(0, ceilY - drop, 0); shade.castShadow = true; g.add(shade);
  const bulbY = ceilY - drop - .04;
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(.032, 12, 12),
    new THREE.MeshBasicMaterial({ color: 0xffe2b0 }));
  bulb.position.set(0, bulbY, 0); g.add(bulb);
  const pt = new THREE.PointLight(0xffd9a0, 4.2, 8, 2);
  pt.position.set(0, bulbY - .02, 0); pt.castShadow = true;
  pt.shadow.mapSize.set(512, 512); pt.shadow.bias = -.004; pt.shadow.radius = 5; g.add(pt);
  g.position.set(x, 0, z); scene.add(g);
  lamps.push(pt);
}
shopLamp(-4.5, -1.1, 1.95);   /* over the hero sheet, behind it */
shopLamp(-2.2, -1.1, 1.95);
shopLamp(-6.9, -1.1, 1.95);

/* ---------- the bench: warm walnut, visible grain ---------- */
function woodTex() {
  return ctex(2048, 384, (g, w, h) => {
    g.fillStyle = '#6f4c2b'; g.fillRect(0, 0, w, h);
    for (let p = 0; p < 4; p++) {                       /* planks across z */
      const y0 = p * h / 4;
      g.fillStyle = ['#77522f', '#664423', '#7d5733', '#5f3f20'][p];
      g.fillRect(0, y0, w, h / 4);
      g.fillStyle = 'rgba(60,38,20,.55)'; g.fillRect(0, y0, w, 3);
    }
    for (let i = 0; i < 340; i++) {                     /* grain streaks */
      const y = Math.random() * h, x = Math.random() * w, len = 90 + Math.random() * 420;
      g.strokeStyle = `rgba(${52 + Math.random() * 30 | 0},${34 + Math.random() * 18 | 0},16,${.08 + Math.random() * .14})`;
      g.lineWidth = .8 + Math.random() * 1.8;
      g.beginPath(); g.moveTo(x, y);
      g.bezierCurveTo(x + len * .3, y + (Math.random() - .5) * 6, x + len * .7, y + (Math.random() - .5) * 6, x + len, y + (Math.random() - .5) * 4);
      g.stroke();
    }
    for (let i = 0; i < 46; i++) {                      /* scratches + use marks */
      const x = Math.random() * w, y = Math.random() * h, a = (Math.random() - .5) * .5;
      const l = 12 + Math.random() * 90;
      g.strokeStyle = Math.random() < .5 ? `rgba(230,205,165,${.06 + Math.random() * .1})` : `rgba(42,26,12,${.08 + Math.random() * .12})`;
      g.lineWidth = .6 + Math.random() * 1.1;
      g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke();
    }
    {                                                    /* coffee ring */
      const cx = w * .82, cy = h * .3;
      g.strokeStyle = 'rgba(58,36,16,.22)'; g.lineWidth = 5;
      g.beginPath(); g.arc(cx, cy, 26, 0, 7); g.stroke();
      g.strokeStyle = 'rgba(58,36,16,.1)'; g.lineWidth = 9;
      g.beginPath(); g.arc(cx, cy, 27, .6, 4.4); g.stroke();
    }
    for (let i = 0; i < 14; i++) {                      /* knots */
      const x = Math.random() * w, y = Math.random() * h;
      const gr = g.createRadialGradient(x, y, 1, x, y, 12 + Math.random() * 10);
      gr.addColorStop(0, 'rgba(48,30,14,.7)'); gr.addColorStop(1, 'rgba(48,30,14,0)');
      g.fillStyle = gr; g.beginPath(); g.arc(x, y, 24, 0, 7); g.fill();
    }
  });
}
const bench = new THREE.Mesh(
  new THREE.BoxGeometry(26, .16, 3.6),
  new THREE.MeshStandardMaterial({ map: woodTex(), roughness: .74, metalness: .02 }));
bench.position.set(-2, -.08, 0); bench.receiveShadow = true; bench.castShadow = true;
scene.add(bench);
/* bench front edge (apron) */
const apron = new THREE.Mesh(new THREE.BoxGeometry(26, .5, .1),
  new THREE.MeshStandardMaterial({ color: 0x6e4a26, roughness: .8 }));
apron.position.set(-2, -.38, 1.76); scene.add(apron);
/* legs hint */
for (const lx of [-12.5, 8.5]) {
  const leg = new THREE.Mesh(new THREE.BoxGeometry(.18, 2.2, .18),
    new THREE.MeshStandardMaterial({ color: 0x5f3f21, roughness: .85 }));
  leg.position.set(lx, -1.4, 1.5); scene.add(leg);
}

/* ---------- floor + wall ---------- */
const floor = new THREE.Mesh(new THREE.PlaneGeometry(90, 60),
  new THREE.MeshStandardMaterial({ color: 0x9c8468, roughness: .95 }));
floor.rotation.x = -Math.PI / 2; floor.position.y = -2.5; scene.add(floor);

const wallTex = ctex(1024, 512, (g, w, h) => {
  g.fillStyle = '#e9dfc9'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 40; i++) {                         /* large soft tonal blotches */
    const x = Math.random() * w, y = Math.random() * h, r = 40 + Math.random() * 130;
    const bg = g.createRadialGradient(x, y, 0, x, y, r);
    const tone = Math.random() < .5 ? '150,128,96' : '235,226,205';
    bg.addColorStop(0, `rgba(${tone},${.05 + Math.random() * .06})`); bg.addColorStop(1, `rgba(${tone},0)`);
    g.fillStyle = bg; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  for (let i = 0; i < 3800; i++) {                       /* plaster stipple */
    g.fillStyle = `rgba(${120 + Math.random() * 60 | 0},${100 + Math.random() * 50 | 0},70,${.04 + Math.random() * .07})`;
    g.fillRect(Math.random() * w, Math.random() * h, 2.2, 2.2);
  }
  const ao = g.createLinearGradient(0, h * .72, 0, h);   /* ambient occlusion toward the bench */
  ao.addColorStop(0, 'rgba(90,70,45,0)'); ao.addColorStop(1, 'rgba(90,70,45,.18)');
  g.fillStyle = ao; g.fillRect(0, h * .72, w, h * .28);
});
const wall = new THREE.Mesh(new THREE.PlaneGeometry(60, 16),
  new THREE.MeshStandardMaterial({ map: wallTex, roughness: .96 }));
wall.position.set(-2, 4.5, -2.6); scene.add(wall);

/* paned window with daylight glow */
function windowUnit(wx, wy) {
  const g = new THREE.Group();
  const viewTex = ctex(512, 640, (c2, w, h) => {
    const gr = c2.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, '#dfeaf0'); gr.addColorStop(.35, '#fdf3d8'); gr.addColorStop(.62, '#f5e3b8'); gr.addColorStop(1, '#e8cf9a');
    c2.fillStyle = gr; c2.fillRect(0, 0, w, h);
    for (let x = -20; x < w + 20; x += 30) {                 /* distant tree blobs, soft */
      const r = 30 + (x * 7919 % 21);
      const yy = h * .76 - (x * 104729 % 26);
      const tg = c2.createRadialGradient(x, yy, r * .2, x, yy, r);
      tg.addColorStop(0, 'rgba(120,148,82,.75)'); tg.addColorStop(1, 'rgba(120,148,82,0)');
      c2.fillStyle = tg; c2.beginPath(); c2.arc(x, yy, r, 0, 7); c2.fill();
    }
    const fg = c2.createLinearGradient(0, h * .8, 0, h);
    fg.addColorStop(0, 'rgba(98,126,66,.75)'); fg.addColorStop(1, 'rgba(80,104,54,.85)');
    c2.fillStyle = fg; c2.fillRect(0, h * .8, w, h * .2);
    c2.fillStyle = 'rgba(255,246,220,.35)'; c2.fillRect(0, 0, w, h * .3);  /* high light haze */
  });
  const sky = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 2.7),
    new THREE.MeshBasicMaterial({ map: viewTex }));
  g.add(sky);
  const frameMat = new THREE.MeshStandardMaterial({ color: 0x6b4f2e, roughness: .7 });
  const bars = [[0, 0, 2.24, .09], [0, 1.42, 2.24, .09], [0, -1.42, 2.24, .09],
                [-1.08, 0, .09, 2.94], [1.08, 0, .09, 2.94], [0, 0, .07, 2.84], [0, .71, 2.14, .06], [0, -.71, 2.14, .06]];
  for (const [x, y, bw, bh] of bars) {
    const b = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, .05), frameMat);
    b.position.set(x, y, .02); g.add(b);
  }
  g.position.set(wx, wy, -2.56); scene.add(g);
}
windowUnit(-5.5, 2.45);

/* shelf with colored ink bottles */
{
  const shelf = new THREE.Mesh(new THREE.BoxGeometry(3.4, .07, .34),
    new THREE.MeshStandardMaterial({ color: 0x7a5636, roughness: .75 }));
  shelf.position.set(-1.0, 2.62, -2.4); shelf.castShadow = true; scene.add(shelf);
  const glass = ['#c46a1e', '#2f7a72', '#b03a2e', '#3d6b35', '#2e4f8a', '#8a4b78'];
  glass.forEach((col, i) => {
    const b = new THREE.Mesh(new THREE.CylinderGeometry(.09, .1, .3 + (i % 3) * .07, 14),
      new THREE.MeshStandardMaterial({ color: col, roughness: .15, metalness: .1, transparent: true, opacity: .88 }));
    b.position.set(-2.35 + i * .5, 2.83 + (i % 3) * .035, -2.4); b.castShadow = true; scene.add(b);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(.05, .05, .06, 10),
      new THREE.MeshStandardMaterial({ color: 0x3a2c1c, roughness: .6 }));
    cap.position.set(-2.35 + i * .5, 3.02 + (i % 3) * .07, -2.4); scene.add(cap);
  });
}
/* hanging tools on the wall (simple silhouettes, warm steel) */
function hangTool(x, y, kind) {
  const mat = new THREE.MeshStandardMaterial({ color: 0x6e6a63, roughness: .45, metalness: .7 });
  const g = new THREE.Group();
  if (kind === 'hammer') {
    const head = new THREE.Mesh(new THREE.BoxGeometry(.34, .12, .08), mat); head.position.y = .42; g.add(head);
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(.025, .032, .7, 8),
      new THREE.MeshStandardMaterial({ color: 0x8a5f36, roughness: .8 })); g.add(handle);
  } else if (kind === 'square') {
    const a = new THREE.Mesh(new THREE.BoxGeometry(.06, .8, .03), mat); g.add(a);
    const b = new THREE.Mesh(new THREE.BoxGeometry(.5, .06, .03), mat); b.position.set(.22, -.37, 0); g.add(b);
  } else { /* brush */
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(.028, .028, .5, 8),
      new THREE.MeshStandardMaterial({ color: 0x3d6b35, roughness: .7 })); handle.position.y = .12; g.add(handle);
    const br = new THREE.Mesh(new THREE.CylinderGeometry(.045, .06, .22, 8),
      new THREE.MeshStandardMaterial({ color: 0xc9a96e, roughness: .9 })); br.position.y = -.26; g.add(br);
  }
  g.position.set(x, y, -2.52); scene.add(g);
}
hangTool(-3.9, 2.95, 'hammer'); hangTool(-3.0, 2.85, 'square'); hangTool(-2.2, 2.9, 'brush');

/* ---------- bench props around the hero slot ---------- */
const HERO_X = -4.46;
/* banker's desk lamp: brass arm, green glass shade, warm bulb */
{
  const brassMat = new THREE.MeshStandardMaterial({ color: 0xa8843e, roughness: .2, metalness: .95, envMapIntensity: 1.3 });
  const g = new THREE.Group();
  const base = new THREE.Mesh(new THREE.CylinderGeometry(.14, .16, .035, 20), brassMat);
  base.position.y = .018; g.add(base);
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(.016, .016, .5, 10), brassMat);
  stem.position.set(0, .27, 0); g.add(stem);
  const arm = new THREE.Mesh(new THREE.CylinderGeometry(.013, .013, .34, 10), brassMat);
  arm.position.set(0, .52, -.14); arm.rotation.x = Math.PI / 2.25; g.add(arm);
  const shade = new THREE.Mesh(new THREE.SphereGeometry(.13, 18, 10, 0, Math.PI * 2, 0, Math.PI * .55),
    new THREE.MeshStandardMaterial({ color: 0x2e6b4f, roughness: .25, metalness: .15, side: THREE.DoubleSide, emissive: 0x1d4a33, emissiveIntensity: .35 }));
  shade.position.set(0, .62, -.3); shade.rotation.x = Math.PI * .62; g.add(shade);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(.035, 10, 10),
    new THREE.MeshBasicMaterial({ color: 0xffe6b8 }));
  bulb.position.set(0, .58, -.33); g.add(bulb);
  const pt = new THREE.PointLight(0xffd9a0, 3.4, 4.5, 2);
  pt.position.set(0, .56, -.33); pt.castShadow = true; pt.shadow.mapSize.set(512, 512); pt.shadow.bias = -.004; pt.shadow.radius = 5;
  g.add(pt);
  g.position.set(HERO_X + .62, 0, -1.28); g.rotation.y = .35;
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  scene.add(g);
}
/* green cutting mat with faint grid */
{
  const matTex = ctex(512, 320, (g, w, h) => {
    g.fillStyle = '#3e6b4f'; g.fillRect(0, 0, w, h);
    g.strokeStyle = 'rgba(240,240,225,.14)'; g.lineWidth = 1;
    for (let x = 0; x < w; x += 32) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); }
    for (let y = 0; y < h; y += 32) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
  });
  const m = new THREE.Mesh(new THREE.BoxGeometry(1.7, .012, 1.15),
    new THREE.MeshStandardMaterial({ map: matTex, roughness: .85 }));
  m.position.set(HERO_X - 1.9, .006, .55); m.receiveShadow = true; m.castShadow = true; scene.add(m);
}
/* pencil cup with colored pencils */
{
  const cup = new THREE.Mesh(new THREE.CylinderGeometry(.11, .095, .24, 18),
    new THREE.MeshStandardMaterial({ color: 0xb34a2e, roughness: .5 }));
  cup.position.set(HERO_X + 1.55, .12, -.55); cup.castShadow = true; scene.add(cup);
  const cols = [0xd23b2e, 0xe8a13a, 0x2e6fb0, 0x3d8a4a, 0x8a4b78];
  cols.forEach((c, i) => {
    const p = new THREE.Mesh(new THREE.CylinderGeometry(.012, .012, .34, 6),
      new THREE.MeshStandardMaterial({ color: c, roughness: .6 }));
    p.position.set(HERO_X + 1.55 + (i - 2) * .035, .3, -.55 + ((i % 2) - .5) * .05);
    p.rotation.z = (i - 2) * .09; p.castShadow = true; scene.add(p);
  });
}
/* steel ruler */
{
  const rulerTex = ctex(512, 40, (g2, w2, h2) => {
    g2.fillStyle = '#9aa0a6'; g2.fillRect(0, 0, w2, h2);
    g2.fillStyle = 'rgba(40,42,46,.65)';
    for (let x = 8; x < w2; x += 10) {
      const tall = (x - 8) % 50 === 0;
      g2.fillRect(x, 0, 1.5, tall ? 18 : 9);
    }
    for (let i = 0; i < 120; i++) {
      g2.fillStyle = `rgba(255,255,255,${.02 + Math.random() * .04})`;
      g2.fillRect(Math.random() * w2, Math.random() * h2, 8 + Math.random() * 30, .8);
    }
  });
  const r = new THREE.Mesh(new THREE.BoxGeometry(1.15, .008, .09),
    new THREE.MeshStandardMaterial({ map: rulerTex, roughness: .38, metalness: .8, envMapIntensity: 1.1 }));
  r.position.set(HERO_X + 1.3, .004, .62); r.rotation.y = .16; r.castShadow = true; scene.add(r);
}
/* pink eraser */
{
  const e = new THREE.Mesh(new THREE.BoxGeometry(.14, .05, .07),
    new THREE.MeshStandardMaterial({ color: 0xd98a8f, roughness: .9 }));
  e.position.set(HERO_X - 1.25, .025, -.62); e.rotation.y = -.3; e.castShadow = true; scene.add(e);
}
/* succulent in terracotta pot (the everGARDEN wink) */
{
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(.09, .07, .14, 14),
    new THREE.MeshStandardMaterial({ color: 0xa85c38, roughness: .8 }));
  pot.position.set(-6.9, .07, -.62); pot.castShadow = true; scene.add(pot);
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x4d7a4a, roughness: .7 });
  for (let i = 0; i < 7; i++) {
    const leaf = new THREE.Mesh(new THREE.SphereGeometry(.045, 8, 6), leafMat);
    const a = i / 7 * Math.PI * 2;
    leaf.position.set(-6.9 + Math.cos(a) * .045, .19 + Math.sin(i) * .015, -.62 + Math.sin(a) * .045);
    leaf.scale.set(.6, 1.5, .6); leaf.rotation.z = Math.cos(a) * .5; scene.add(leaf);
  }
}
/* amber ink bottle near the sheet */
{
  const b = new THREE.Mesh(new THREE.CylinderGeometry(.068, .076, .16, 14),
    new THREE.MeshStandardMaterial({ color: 0x8a4a12, roughness: .08, metalness: .05, transparent: true, opacity: .92, envMapIntensity: 1.3 }));
  b.position.set(HERO_X + 1.15, .08, -.68); b.castShadow = true; scene.add(b);
  const cork = new THREE.Mesh(new THREE.CylinderGeometry(.038, .042, .05, 10),
    new THREE.MeshStandardMaterial({ color: 0x6e5334, roughness: .95 }));
  cork.position.set(HERO_X + 1.15, .185, -.68); cork.castShadow = true; scene.add(cork);
}

/* soft contact shadows (radial gradient planes just above the bench) */
let contactTex = null;
function contactShadow(x, z, sx, sz, alpha) {
  if (!contactTex) {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const g2 = c.getContext('2d');
    const gr = g2.createRadialGradient(64, 64, 8, 64, 64, 62);
    gr.addColorStop(0, 'rgba(30,20,10,.85)'); gr.addColorStop(.6, 'rgba(30,20,10,.32)'); gr.addColorStop(1, 'rgba(30,20,10,0)');
    g2.fillStyle = gr; g2.fillRect(0, 0, 128, 128);
    contactTex = new THREE.CanvasTexture(c);
  }
  const m = new THREE.Mesh(new THREE.PlaneGeometry(sx, sz),
    new THREE.MeshBasicMaterial({ map: contactTex, transparent: true, opacity: alpha, depthWrite: false }));
  m.rotation.x = -Math.PI / 2; m.position.set(x, .0025, z); scene.add(m);
  return m;
}

/* ---------- the hero sheet: bone paper, pencil wireframe, ink wipe ---------- */
const SHEET_W = .98, SHEET_D = 2.12;                /* portrait page: width across bench, length into the bench */
let paperTex, inkCanvas, inkCtx, wipeCanvas, wipeCtx, wipeTex;

function drawPaperBase(g, w, h) {
  g.fillStyle = PAPER; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 1500; i++) {                   /* paper tooth */
    g.fillStyle = `rgba(120,100,70,${.02 + Math.random() * .04})`;
    g.fillRect(Math.random() * w, Math.random() * h, 1.5, 1.5);
  }
  for (let i = 0; i < 260; i++) {                    /* long fibers */
    const x = Math.random() * w, y = Math.random() * h, a = Math.random() * Math.PI, l = 6 + Math.random() * 22;
    g.strokeStyle = `rgba(${140 + Math.random() * 40 | 0},${120 + Math.random() * 30 | 0},88,${.05 + Math.random() * .07})`;
    g.lineWidth = .7 + Math.random() * .8;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke();
  }
  g.strokeStyle = 'rgba(150,128,92,.28)';            /* deckled edges */
  for (const [horiz, fixed] of [[true, 3], [true, h - 3], [false, 3], [false, w - 3]]) {
    g.lineWidth = 2 + Math.random() * 3;
    g.beginPath();
    for (let d = 0; d <= (horiz ? w : h); d += 14) {
      const off = fixed + (Math.random() - .5) * 3;
      if (d === 0) g.moveTo(horiz ? d : off, horiz ? off : d);
      else g.lineTo(horiz ? d : off, horiz ? off : d);
    }
    g.stroke();
  }
  const v = g.createRadialGradient(w / 2, h / 2, h * .3, w / 2, h / 2, h * .75);
  v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(90,70,40,.12)');
  g.fillStyle = v; g.fillRect(0, 0, w, h);
}
function drawWireframe(g, w, h) {
  g.strokeStyle = PENCIL; g.lineWidth = 2; g.lineCap = 'round';
  const j = n => n + (Math.random() - .5) * 5;        /* hand wobble */
  /* browser chrome sketch around the hero block */
  g.strokeRect(j(70), j(1120), 640, 400);
  g.beginPath(); g.arc(j(100), j(1145), 6, 0, 7); g.stroke();
  g.beginPath(); g.arc(j(125), j(1145), 6, 0, 7); g.stroke();
  g.beginPath(); g.moveTo(j(70), j(1170)); g.lineTo(j(710), j(1170)); g.stroke();
  /* headline + sub placeholder strokes */
  for (const [y, x0, x1] of [[1252, 120, 660], [1335, 260, 520], [1410, 180, 600], [1490, 300, 480]]) {
    g.beginPath(); g.moveTo(j(x0), y); g.lineTo(j(x1), y + (Math.random() - .5) * 4); g.stroke();
  }
  /* wordmark + tag boxes */
  g.strokeRect(j(560), j(40), 150, 60);
  g.strokeRect(j(600), j(110), 110, 22);
  /* sprouting branch, pencil study — the garden on the bench */
  g.save(); g.translate(390, 700); g.lineWidth = 2.5;
  g.beginPath(); g.moveTo(0, 240);
  g.bezierCurveTo(-18, 150, 22, 90, -6, 10);
  g.stroke();
  const leaf = (x, y, r, rot) => {
    g.save(); g.translate(x, y); g.rotate(rot);
    g.beginPath(); g.ellipse(0, 0, r, r * .42, 0, 0, Math.PI * 2); g.stroke();
    g.beginPath(); g.moveTo(-r, 0); g.lineTo(r, 0); g.stroke();
    g.restore();
  };
  leaf(-52, 130, 46, -.5); leaf(48, 96, 42, .45); leaf(-44, 44, 38, -.65); leaf(40, 6, 34, .35); leaf(-10, -34, 36, -1.35);
  g.beginPath(); g.moveTo(-58, 240); g.lineTo(58, 240); g.lineTo(44, 320); g.lineTo(-44, 320); g.closePath(); g.stroke();  /* pot */
  g.restore();
}
function drawInk(g, w, h) {
  /* wordmark */
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 44px 'Suez One'";
  g.fillText('נבנה ביד', 726, 84);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  drawSpacedLTR(g, 'SEED 005', 683, 124, 6);
  /* headline, two lines */
  g.textAlign = 'center';
  g.fillStyle = INK;
  const L1 = 'האתר הזה נבנה מול העיניים', L2 = 'שלך.';
  let fs = 60;                                   /* probe: 30css x2, line1 666px wide */
  g.font = `900 ${fs}px 'Suez One'`;
  while (g.measureText(L1).width > 700 && fs > 40) { fs -= 2; g.font = `900 ${fs}px 'Suez One'`; }
  g.fillText(L1, 390, 1250);
  g.fillText(L2, 390, 1318);
  /* sub */
  g.fillStyle = DIM; g.font = "300 28px 'Heebo'";
  drawSpaced(g, 'לא תבנית. לא דרג-אנד-דרופ. נבנה ביד.', 390, 1403, 1.68);
  /* scroll hint — probe truth: cap Heebo 200 13px ls 2.34, color dim (not ember) */
  g.fillStyle = '#8a877e'; g.font = "200 26px 'Heebo'";
  drawSpaced(g, 'גלול — והעבודה מתחילה ↓', 390, 1483, 4.68);
}

function addInkBleed(src) {
  const c = document.createElement('canvas'); c.width = src.width; c.height = src.height;
  const g = c.getContext('2d');
  g.filter = 'blur(1.4px)'; g.globalAlpha = .38;
  g.drawImage(src, .6, .8);
  g.filter = 'none'; g.globalAlpha = 1;
  g.drawImage(src, 0, 0);
  return c;
}
function buildSheet() {
  const W = 780, H = 1688;
  paperTex = ctex(W, H, drawPaperBase);
  /* wireframe lives on its own canvas under the paper shading */
  const wireC = document.createElement('canvas'); wireC.width = W; wireC.height = H;
  const wg = wireC.getContext('2d'); drawPaperBase(wg, W, H); drawWireframe(wg, W, H);
  const wireTex = new THREE.CanvasTexture(wireC); wireTex.colorSpace = THREE.SRGBColorSpace; wireTex.anisotropy = 8;
  /* ink prerendered, wiped into wipeCanvas by scroll */
  const rawInk = document.createElement('canvas'); rawInk.width = W; rawInk.height = H;
  drawInk(rawInk.getContext('2d'), W, H);
  inkCanvas = addInkBleed(rawInk);
  inkCtx = inkCanvas.getContext('2d');
  wipeCanvas = document.createElement('canvas'); wipeCanvas.width = W; wipeCanvas.height = H;
  wipeCtx = wipeCanvas.getContext('2d');
  wipeCtx.drawImage(wireC, 0, 0);
  wipeTex = new THREE.CanvasTexture(wipeCanvas); wipeTex.colorSpace = THREE.SRGBColorSpace; wipeTex.anisotropy = 8;

  const geo = new THREE.BoxGeometry(SHEET_W, .024, SHEET_D);
  const edge = new THREE.MeshStandardMaterial({ color: 0xd8d0bf, roughness: .85 });
  const face = new THREE.MeshBasicMaterial({ map: wipeTex });
  const sheet = new THREE.Mesh(geo, [edge, edge, face, edge, edge, edge]);
  sheet.castShadow = true; sheet.receiveShadow = true;
  sheet.position.set(HERO_X, .028, 0);
  sheet.rotation.y = -.012;                            /* laid down casually, not aligned */
  scene.add(sheet);
  /* a pencil resting on the bench by the sheet */
  const pencil = new THREE.Mesh(new THREE.CylinderGeometry(.014, .014, .5, 6),
    new THREE.MeshStandardMaterial({ color: 0xe8a13a, roughness: .6 }));
  pencil.rotation.z = Math.PI / 2; pencil.rotation.y = .24;
  pencil.position.set(HERO_X - .78, .014, .35); pencil.castShadow = true; scene.add(pencil);
}

let lastWipe = -1;
function setWipe(t) {                                  /* 0=wireframe only, 1=fully inked */
  t = clamp01(t);
  if (Math.abs(t - lastWipe) < .004) return;
  lastWipe = t;
  const W = 780, H = 1688;
  wipeCtx.clearRect(0, 0, W, H);
  wipeCtx.drawImage(inkCanvas, 0, 0);                  /* ink exists under… */
  /* …a mask that uncovers right-to-left (RTL draw direction) */
  const xEdge = W + 80 - easeInOut(t) * (W + 160);   /* t0: off right, t1: off left */
  wipeCtx.globalCompositeOperation = 'destination-out';
  wipeCtx.fillStyle = '#000';
  wipeCtx.fillRect(0, 0, Math.min(W, Math.max(0, xEdge - 70)), H);
  const fx0 = Math.max(0, xEdge - 70), fx1 = Math.min(W, xEdge + 10);
  if (fx1 > fx0) {
    const gr = wipeCtx.createLinearGradient(xEdge - 70, 0, xEdge + 10, 0);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    wipeCtx.fillStyle = gr; wipeCtx.fillRect(fx0, 0, fx1 - fx0, H);
  }
  wipeCtx.globalCompositeOperation = 'destination-over';
  wipeCtx.globalAlpha = 1 - .55 * t;
  wipeCtx.drawImage(wireBackup, 0, 0);
  wipeCtx.globalAlpha = 1;
  wipeTex.needsUpdate = true;
}
let wireBackup;                                        /* kept for the composite */

/* ---------- chapter 1 sheet (חוויה): letterpress deboss ----------
   Live DOM truth (egprobe1, css x2): marker 'פרק 01 — חוויה' dim, centered,
   Heebo 200 11css baseline ~1218 ls .4em; kicker 'אתר טוב לא נקרא. הוא מורגש.'
   Suez One ~24css bone baseline ~1314; frag 2 lines Heebo 15css bone
   baselines ~1398/1434; micro 'געו במסך — החומר מרגיש אתכם' Heebo 12css dim
   baseline ~1516. On-paper adaptations: bone→ink (kicker) / blind deboss (frag). */
const SHEET2_X = HERO_X + 2.3;
let dieGroup = null;
const DIE_REST = { x: SHEET2_X + .62, y: .05, z: -.95 };
const DIE_HOVER = { x: SHEET2_X, y: .5, z: .62 };
const DIE_PRESS = { x: SHEET2_X, y: .052, z: .62 };
function drawDeboss(g, text, cx, cy, font, opts = {}) {
  g.font = font; g.textAlign = 'center'; g.textBaseline = 'alphabetic';
  const d = opts.depth || 2;
  g.fillStyle = 'rgba(90,70,45,.55)';                      /* pressed shadow, upper edge */
  g.fillText(text, cx, cy - d * .7);
  g.fillStyle = 'rgba(255,252,244,.95)';                   /* paper lift, lower edge */
  g.fillText(text, cx, cy + d * .9);
  if (opts.ink) {
    g.fillStyle = opts.ink;
    g.fillText(text, cx, cy);
  } else {
    g.fillStyle = 'rgba(104,84,54,.58)';                   /* blind deboss readable bed */
    g.fillText(text, cx, cy);
  }
}
function drawWireframe2(g, w, h) {
  g.strokeStyle = PENCIL; g.lineWidth = 2; g.lineCap = 'round';
  const j = n => n + (Math.random() - .5) * 5;
  g.strokeRect(j(70), j(1120), 640, 420);
  g.beginPath(); g.arc(j(100), j(1145), 6, 0, 7); g.stroke();
  g.beginPath(); g.arc(j(125), j(1145), 6, 0, 7); g.stroke();
  g.beginPath(); g.moveTo(j(70), j(1170)); g.lineTo(j(710), j(1170)); g.stroke();
  for (const [y, x0, x1] of [[1218, 280, 500], [1314, 130, 650], [1398, 110, 670], [1434, 160, 620], [1516, 220, 560]]) {
    g.beginPath(); g.moveTo(j(x0), y); g.lineTo(j(x1), y + (Math.random() - .5) * 4); g.stroke();
  }
  g.strokeRect(j(560), j(40), 150, 60);
  g.strokeRect(j(600), j(110), 110, 22);
  /* fingerprint study, pencil — touch */
  g.save(); g.translate(390, 640);
  for (let r = 14; r <= 98; r += 14) {
    g.beginPath();
    for (let a = 0; a <= Math.PI * 2 + .1; a += .12) {
      const rr = r + Math.sin(a * 3 + r) * 3.5;
      const x = Math.cos(a) * rr * .82, y = Math.sin(a) * rr;
      if (a === 0) g.moveTo(x, y); else g.lineTo(x, y);
    }
    g.stroke();
  }
  g.restore();
}
function drawInk2(g, w, h) {
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 44px 'Suez One'";
  g.fillText('נבנה ביד', 726, 84);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  drawSpacedLTR(g, 'SEED 005', 683, 124, 6);
  g.fillStyle = '#8a877e'; g.font = "200 22px 'Heebo'";
  drawSpaced(g, 'פרק 01 — חוויה', 390, 1218, 3.2);
  /* the kicker, inked deboss */
  drawDeboss(g, 'אתר טוב לא נקרא. הוא מורגש.', 390, 1314, "900 48px 'Suez One'", { ink: INK, depth: 3 });
  /* the frag, blind deboss — felt before it is read */
  drawDeboss(g, 'כל גלילה מתוכננת · כל ריחוף עונה ·', 390, 1398, "300 30px 'Heebo'", { depth: 1.6 });
  drawDeboss(g, 'כל מעבר מספר משהו', 390, 1434, "300 30px 'Heebo'", { depth: 1.6 });
  /* micro line, flat dim */
  g.fillStyle = '#8a877e'; g.font = "300 24px 'Heebo'"; g.textAlign = 'center';
  g.fillText('געו במסך — החומר מרגיש אתכם', 390, 1516);
}
let sheet2Tex, sheet2Canvas, sheet2Ctx, sheet2Wire, sheet2InkFull, lastPress = -1;
function buildSheet2() {
  const W = 780, H = 1688;
  sheet2Wire = document.createElement('canvas'); sheet2Wire.width = W; sheet2Wire.height = H;
  const wg = sheet2Wire.getContext('2d'); drawPaperBase(wg, W, H); drawWireframe2(wg, W, H);
  const rawInk = document.createElement('canvas'); rawInk.width = W; rawInk.height = H;
  const ig = rawInk.getContext('2d');
  drawPaperBase(ig, W, H);
  ig.globalAlpha = .55; ig.drawImage(sheet2Wire, 0, 0); ig.globalAlpha = 1;   /* ghost of the sketch stays */
  {                                                                          /* the press leaves an impression */
    const imp = ig.createRadialGradient(390, 1370, 60, 390, 1370, 330);
    imp.addColorStop(0, 'rgba(96,76,48,.14)'); imp.addColorStop(.75, 'rgba(96,76,48,.07)'); imp.addColorStop(1, 'rgba(96,76,48,0)');
    ig.fillStyle = imp;
    ig.save(); ig.translate(390, 1370); ig.scale(1.25, .8); ig.translate(-390, -1370);
    ig.fillRect(0, 900, W, 940); ig.restore();
  }
  drawInk2(ig, W, H);
  sheet2InkFull = addInkBleed(rawInk);
  sheet2Canvas = document.createElement('canvas'); sheet2Canvas.width = W; sheet2Canvas.height = H;
  sheet2Ctx = sheet2Canvas.getContext('2d');
  sheet2Ctx.drawImage(sheet2Wire, 0, 0);
  sheet2Tex = new THREE.CanvasTexture(sheet2Canvas); sheet2Tex.colorSpace = THREE.SRGBColorSpace; sheet2Tex.anisotropy = 8;
  const geo = new THREE.BoxGeometry(SHEET_W, .024, SHEET_D);
  const edge = new THREE.MeshStandardMaterial({ color: 0xd8d0bf, roughness: .85 });
  const face = new THREE.MeshBasicMaterial({ map: sheet2Tex });
  const sheet = new THREE.Mesh(geo, [edge, edge, face, edge, edge, edge]);
  sheet.castShadow = true; sheet.receiveShadow = true;
  sheet.position.set(SHEET2_X, .028, 0);
  sheet.rotation.y = .014;
  scene.add(sheet);
  /* the press die: steel block + wood handle, on a movable group for the press action */
  dieGroup = new THREE.Group();
  const dieFaceTex = ctex(256, 152, (g2, w2, h2) => {
    g2.fillStyle = '#6b7076'; g2.fillRect(0, 0, w2, h2);
    g2.save(); g2.translate(w2 / 2, h2 / 2 + 8); g2.scale(-1, 1);          /* reversed, as a real die */
    g2.font = "900 44px 'Suez One'"; g2.textAlign = 'center'; g2.textBaseline = 'middle';
    g2.fillStyle = 'rgba(255,255,255,.5)'; g2.fillText('נבנה ביד', 1.5, 1.5);
    g2.fillStyle = '#43474c'; g2.fillText('נבנה ביד', 0, 0);
    g2.restore();
  });
  const steelSide = new THREE.MeshStandardMaterial({ color: 0x7d8288, roughness: .3, metalness: .9, envMapIntensity: 1.1 });
  const steelFace = new THREE.MeshStandardMaterial({ map: dieFaceTex, roughness: .28, metalness: .9, envMapIntensity: 1.1 });
  const die = new THREE.Mesh(new THREE.BoxGeometry(.34, .1, .2),
    [steelSide, steelSide, steelSide, steelFace, steelSide, steelSide]);
  die.castShadow = true; dieGroup.add(die);
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(.045, .05, .16, 12),
    new THREE.MeshStandardMaterial({ color: 0x7a5636, roughness: .7 }));
  handle.position.y = .12; handle.castShadow = true; dieGroup.add(handle);
  dieGroup.position.set(SHEET2_X + .62, .05, -.95);
  dieGroup.rotation.y = -.2;
  scene.add(dieGroup);
  contactShadow(SHEET2_X + .06, .04, SHEET_W * 1.35, SHEET_D * 1.12, .5);
  contactShadow(SHEET2_X + .62, -.95, .5, .34, .5);
}

function setPress(u) {
  u = clamp01(u);
  if (Math.abs(u - lastPress) < .004) return;
  lastPress = u;
  const W = 780, H = 1688, g = sheet2Ctx;
  g.clearRect(0, 0, W, H);
  g.drawImage(sheet2InkFull, 0, 0);
  g.globalCompositeOperation = 'destination-in';
  const r = easeInOut(u) * 1500;
  if (r > 1) {
    const gr = g.createRadialGradient(390, 1370, Math.max(0, r - 60), 390, 1370, r);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
  } else {
    g.clearRect(0, 0, W, H);
  }
  g.globalCompositeOperation = 'destination-over';
  g.globalAlpha = 1 - .3 * u;
  g.drawImage(sheet2Wire, 0, 0);
  g.globalAlpha = 1;
  sheet2Tex.needsUpdate = true;
}

/* ---------- chapter 2 sheet (דיוק): scribed precision ----------
   Live DOM truth (egprobe2, css x2): cap 'הפיקסל האחרון הוא ההבדל בין מוצר ליצירה.'
   Heebo 200 13css dim ls 2.34 baseline ~877; proof cells centered, val Suez One 900
   22css bone baselines ~1000/1192/1384, key Heebo 200 11css bone baselines ~1068/1260/1452.
   Action (A storyboard): a caliper SCRIBES each value — engraved thin strokes,
   not letterpress. Wireframe layer: machinist's square + dimension lines. */
const SHEET3_X = SHEET2_X + 2.3;
function drawWireframe3(g, w, h) {
  g.strokeStyle = PENCIL; g.lineWidth = 2; g.lineCap = 'round';
  const j = n => n + (Math.random() - .5) * 5;
  /* machinist's square study */
  g.save(); g.translate(390, 500); g.lineWidth = 2.5;
  g.beginPath(); g.moveTo(-160, 120); g.lineTo(-160, -120); g.lineTo(-120, -120); g.lineTo(-120, 80); g.lineTo(160, 80); g.lineTo(160, 120); g.closePath(); g.stroke();
  for (let x = -110; x <= 150; x += 20) { g.beginPath(); g.moveTo(x, 80); g.lineTo(x, x % 100 === -10 + 100 * Math.round((x + 10) / 100) ? 60 : 68); g.stroke(); }
  g.restore();
  /* dimension lines between the future cells */
  for (const y of [1000, 1192, 1384]) {
    g.beginPath(); g.moveTo(120, y - 14); g.lineTo(120, y + 48); g.stroke();
    g.beginPath(); g.moveTo(114, y - 14); g.lineTo(126, y - 14); g.stroke();
    g.beginPath(); g.moveTo(114, y + 48); g.lineTo(126, y + 48); g.stroke();
  }
  for (const [y, x0, x1] of [[877, 110, 670]]) {
    g.beginPath(); g.moveTo(j(x0), y); g.lineTo(j(x1), y + (Math.random() - .5) * 4); g.stroke();
  }
}
function drawScribed(g, text, cx, cy, font, color) {
  /* burin-scored stroke: bright scratch above, dark scored line at center */
  g.font = font; g.textAlign = 'center'; g.textBaseline = 'alphabetic';
  g.fillStyle = 'rgba(255,252,244,.7)';
  g.fillText(text, cx, cy - 1.2);
  g.fillStyle = color;
  g.fillText(text, cx, cy);
}
const CELLS3 = [['מתחת לשנייה', 'זמן טעינה'], ['100', 'בליבת הנגישות'], ['מושלם', 'RTL']];
function drawInk3Base(g) {
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 44px 'Suez One'";
  g.fillText('נבנה ביד', 726, 84);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  drawSpacedLTR(g, 'SEED 005', 683, 124, 6);
  g.fillStyle = '#8a877e'; g.font = "200 26px 'Heebo'"; g.textAlign = 'center';
  drawSpaced(g, 'הפיקסל האחרון הוא ההבדל בין מוצר ליצירה.', 390, 877, 4.68);
}
function drawCell3(g, i) {
  const [val, key] = CELLS3[i];
  const yv = 1000 + i * 192, yk = 1068 + i * 192;
  drawScribed(g, val, 390, yv, "900 44px 'Suez One'", '#3d3a35');
  g.fillStyle = '#8a877e'; g.font = "200 22px 'Heebo'"; g.textAlign = 'center';
  g.fillText(key, 390, yk);
}
let sheet3Tex, sheet3Canvas, sheet3Ctx, sheet3Wire, sheet3Base, cell3Can = [], lastScribe = -1, calGroup;
function setScribe(f0, f1, f2) {
  const key = f0 * 9 + f1 * 3 + f1 + f2;               /* cheap change detect */
  if (Math.abs(f0 + f1 + f2 - lastScribe) < .004) return;
  lastScribe = f0 + f1 + f2;
  const W = 780, H = 1688, g = sheet3Ctx, fs = [f0, f1, f2];
  g.clearRect(0, 0, W, H);
  g.drawImage(sheet3Base, 0, 0);
  const avgF = (f0 + f1 + f2) / 3;
  g.globalAlpha = 1 - .45 * avgF;                       /* the plan fades as the work completes */
  g.drawImage(sheet3Wire, 0, 0);
  g.globalAlpha = 1;
  fs.forEach((f, i) => {
    if (f <= 0) return;
    const yv = 1000 + i * 192, yk = 1068 + i * 192;
    const clipX = 760 - 720 * easeInOut(f);             /* scribed right to left */
    g.save();
    g.beginPath(); g.rect(clipX, yv - 80, 780 - clipX, yk + 40 - (yv - 80)); g.clip();
    g.drawImage(cell3Can[i], 0, 0);
    g.restore();
  });
  sheet3Tex.needsUpdate = true;
}
function buildSheet3() {
  const W = 780, H = 1688;
  sheet3Wire = document.createElement('canvas'); sheet3Wire.width = W; sheet3Wire.height = H;
  const wg = sheet3Wire.getContext('2d'); drawWireframe3(wg, W, H);
  const baseRaw = document.createElement('canvas'); baseRaw.width = W; baseRaw.height = H;
  const ig = baseRaw.getContext('2d');
  drawPaperBase(ig, W, H);
  drawInk3Base(ig);
  sheet3Base = addInkBleed(baseRaw);
  for (let i = 0; i < 3; i++) {
    const cc = document.createElement('canvas'); cc.width = W; cc.height = H;
    const cg = cc.getContext('2d'); drawCell3(cg, i);
    cell3Can.push(addInkBleed(cc));
  }
  sheet3Canvas = document.createElement('canvas'); sheet3Canvas.width = W; sheet3Canvas.height = H;
  sheet3Ctx = sheet3Canvas.getContext('2d');
  sheet3Tex = new THREE.CanvasTexture(sheet3Canvas); sheet3Tex.colorSpace = THREE.SRGBColorSpace; sheet3Tex.anisotropy = 8;
  const geo = new THREE.BoxGeometry(SHEET_W, .024, SHEET_D);
  const edge = new THREE.MeshStandardMaterial({ color: 0xd8d0bf, roughness: .85 });
  const face = new THREE.MeshBasicMaterial({ map: sheet3Tex });
  const sheet = new THREE.Mesh(geo, [edge, edge, face, edge, edge, edge]);
  sheet.castShadow = true; sheet.receiveShadow = true;
  sheet.position.set(SHEET3_X, .028, 0);
  sheet.rotation.y = -.01;
  scene.add(sheet);
  /* a caliper resting by the sheet — the tool for this section's action */
  const calMat = new THREE.MeshStandardMaterial({ color: 0xb0b6bc, roughness: .3, metalness: .9, envMapIntensity: 1.2 });
  calGroup = new THREE.Group();
  const beam = new THREE.Mesh(new THREE.BoxGeometry(.62, .012, .045), calMat);
  beam.castShadow = true; calGroup.add(beam);
  const jaw1 = new THREE.Mesh(new THREE.BoxGeometry(.045, .012, .16), calMat);
  jaw1.position.set(-.29, 0, .06); jaw1.castShadow = true; calGroup.add(jaw1);
  const jaw2 = new THREE.Mesh(new THREE.BoxGeometry(.045, .012, .13), calMat);
  jaw2.position.set(.18, 0, .045); jaw2.castShadow = true; calGroup.add(jaw2);
  calGroup.position.set(CAL_REST.x, CAL_REST.y, CAL_REST.z);
  calGroup.rotation.y = CAL_REST.rot;
  scene.add(calGroup);
  contactShadow(SHEET3_X + .06, .04, SHEET_W * 1.35, SHEET_D * 1.12, .5);
  contactShadow(CAL_REST.x, CAL_REST.z, .8, .5, .45);
  /* dressing along the ch1 -> ch2 camera path */
  const pencil3 = new THREE.Mesh(new THREE.CylinderGeometry(.016, .016, .34, 8),
    new THREE.MeshStandardMaterial({ color: 0xcc5533, roughness: .6 }));
  pencil3.rotation.z = Math.PI / 2; pencil3.rotation.y = -.22;
  pencil3.position.set(SHEET2_X + 1.18, .016, .5); pencil3.castShadow = true; scene.add(pencil3);
  contactShadow(SHEET2_X + 1.18, .5, .45, .18, .4);
  const shav = new THREE.Mesh(new THREE.ConeGeometry(.02, .1, 7),
    new THREE.MeshStandardMaterial({ color: 0xd9c9a8, roughness: .9 }));
  shav.rotation.z = 1.2; shav.position.set(SHEET2_X + 1.02, .01, .62); shav.castShadow = true; scene.add(shav);
  setScribe(0, 0, 0);
}
/* caliper scribe choreography: tip tracks the reveal edge of each cell, right to left */
const CAL_REST = { x: SHEET3_X + .62, y: .008, z: .58, rot: .5 };
const cellZ = i => ((1034 + i * 192) / 1688 - .5) * SHEET_D;
const clipToX = cx => SHEET3_X + (cx / 780 - .5) * SHEET_W;
function calPose(s) {
  if (!calGroup) return;
  s = clamp01(s);
  let x = CAL_REST.x, y = CAL_REST.y, z = CAL_REST.z, rot = CAL_REST.rot;
  if (s > 0) {
    const stops = [0, .3, .6];                          /* one per cell */
    let i = s < .3 ? 0 : s < .6 ? 1 : 2;
    const local = clamp01((s - stops[i]) / .3);
    const fi = clamp01((local - .4) / .5);              /* matches setScribe f_i below */
    const hoverY = .055;
    if (s >= .9) {                                      /* home */
      const u = easeInOut(seg(s, .9, 1));
      x = THREE.MathUtils.lerp(clipToX(80), CAL_REST.x, u);
      y = THREE.MathUtils.lerp(hoverY, CAL_REST.y, u);
      z = THREE.MathUtils.lerp(cellZ(2), CAL_REST.z, u);
      rot = THREE.MathUtils.lerp(0, CAL_REST.rot, u);
    } else if (local < .4) {                            /* travel to cell i */
      const u = easeInOut(local / .4);
      const fromX = i === 0 ? CAL_REST.x : clipToX(80), fromZ = i === 0 ? CAL_REST.z : cellZ(i - 1);
      const fromY = i === 0 ? CAL_REST.y : hoverY;
      x = THREE.MathUtils.lerp(fromX, clipToX(760), u);
      y = THREE.MathUtils.lerp(fromY, hoverY, Math.min(u * 1.6, 1)) + Math.sin(u * Math.PI) * .05;
      z = THREE.MathUtils.lerp(fromZ, cellZ(i), u);
      rot = THREE.MathUtils.lerp(i === 0 ? CAL_REST.rot : 0, 0, u);
    } else {                                            /* scribing: tip follows the cut */
      const clipX = 760 - 720 * easeInOut(fi);
      x = clipToX(clipX);
      y = hoverY + Math.sin(fi * Math.PI * 22) * .003;  /* burin chatter */
      z = cellZ(i);
      rot = 0;
    }
  }
  calGroup.position.set(x, y, z);
  calGroup.rotation.y = rot;
}

/* ---------- chapter 3 sheet (עבודות): the finished pieces ----------
   Live DOM truth (egprobe3b/3c, css x2): title 'עבודות' Frank Ruhl 900 28css bone
   ls 3.33 baseline ~760; sub Heebo 100 12css dim 2 lines baselines ~794/830
   (wrap measured at 686 canvas); 3 work-cards x150 w480 h176 tops 1022/1238/1454,
   meta left-aligned x220: name Frank Ruhl 900 15css baseline top+114,
   type Heebo 200 11css baseline top+158. Thumbs: refs/work-{soshimi,verdant,videoeditor}.jpg.
   Action (A storyboard): the finished pieces are physical mini-screens that glide
   in, stand upright behind the sheet, and stamp their label rows onto the sheet. */
const SHEET4_X = SHEET3_X + 2.3;
const CARD4_TOPS = [1022, 1238, 1454];
const ROWS4 = [
  { name: 'סושימי', type: 'אתר מסעדה פרימיום ↗' },
  { name: 'The Sound Room', type: 'חנות אונליין ↗' },
  { name: 'עורך וידאו', type: 'דף נחיתה לפרילנסר ↗' },
];
function drawWireframe4(g, w, h) {
  g.strokeStyle = PENCIL; g.lineWidth = 2; g.lineCap = 'round';
  const j = n => n + (Math.random() - .5) * 5;
  for (let i = 0; i < 3; i++) {                       /* upright frame studies */
    const cx = 390 + (i - 1) * 190, cy = 560;
    g.strokeRect(j(cx - 70), j(cy - 50), 140, 100);
    g.beginPath(); g.moveTo(cx, cy + 50); g.lineTo(cx - 16, cy + 88);
    g.moveTo(cx, cy + 50); g.lineTo(cx + 16, cy + 88); g.stroke();
  }
  for (const [y, x0, x1] of [[770, 500, 680], [800, 120, 660], [830, 180, 600]]) {
    g.beginPath(); g.moveTo(j(x0), y); g.lineTo(j(x1), y + (Math.random() - .5) * 4); g.stroke();
  }
}
function drawInk4Base(g) {
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 44px 'Suez One'";
  g.fillText('נבנה ביד', 726, 84);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  drawSpacedLTR(g, 'SEED 005', 683, 124, 6);
  g.textAlign = 'center';
  g.fillStyle = INK; g.font = "900 56px 'Frank Ruhl Libre'";
  drawSpaced(g, 'עבודות', 390, 770, 6.66);
  g.fillStyle = DIM; g.font = "100 24px 'Heebo'";
  /* live wrap (egprobe3d line boxes): 2 lines, ls 3.6css, baselines ~795/830 */
  drawSpaced(g, 'שלוש יצירות שכבר יצאו מהסדנה. תלחצו,', 390, 795, 7.2);
  drawSpaced(g, 'תגללו, תבדקו אותי.', 390, 831, 7.2);
  g.strokeStyle = 'rgba(20,16,12,.35)'; g.lineWidth = 2;
  for (const top of CARD4_TOPS) { g.beginPath(); g.roundRect(150, top, 480, 176, 10); g.stroke(); }
}
function drawRow4(g, i) {
  const top = CARD4_TOPS[i], { name, type } = ROWS4[i];
  g.textAlign = 'left'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 30px 'Frank Ruhl Libre'";
  g.fillText(name, 220, top + 114);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  g.fillText(type, 220, top + 158);
}
let sheet4Tex, sheet4Canvas, sheet4Ctx, sheet4Base, sheet4Wire, row4Can = [], stampTmp, lastStamp = -1;
function setStamp(f0, f1, f2) {
  const tot = f0 + f1 + f2;
  if (Math.abs(tot - lastStamp) < .004) return;
  lastStamp = tot;
  const W = 780, H = 1688, g = sheet4Ctx, fs = [f0, f1, f2];
  g.clearRect(0, 0, W, H);
  g.drawImage(sheet4Base, 0, 0);
  g.globalAlpha = 1 - .45 * (tot / 3);
  g.drawImage(sheet4Wire, 0, 0);
  g.globalAlpha = 1;
  const tg = stampTmp.getContext('2d');
  fs.forEach((f, i) => {
    if (f <= 0) return;
    const cy = CARD4_TOPS[i] + 136;
    tg.clearRect(0, 0, W, H);
    tg.drawImage(row4Can[i], 0, 0);
    tg.globalCompositeOperation = 'destination-in';
    const r = easeInOut(f) * 320;
    const gr = tg.createRadialGradient(390, cy, Math.max(0, r - 50), 390, cy, r);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    tg.fillStyle = gr; tg.fillRect(0, 0, W, H);
    tg.globalCompositeOperation = 'source-over';
    g.drawImage(stampTmp, 0, 0);
  });
  sheet4Tex.needsUpdate = true;
}
const screens4 = [];
function buildSheet4() {
  const W = 780, H = 1688;
  sheet4Wire = document.createElement('canvas'); sheet4Wire.width = W; sheet4Wire.height = H;
  const wg = sheet4Wire.getContext('2d'); drawWireframe4(wg, W, H);
  const baseRaw = document.createElement('canvas'); baseRaw.width = W; baseRaw.height = H;
  const ig = baseRaw.getContext('2d');
  drawPaperBase(ig, W, H); drawInk4Base(ig);
  sheet4Base = addInkBleed(baseRaw);
  for (let i = 0; i < 3; i++) {
    const cc = document.createElement('canvas'); cc.width = W; cc.height = H;
    const cg = cc.getContext('2d'); drawRow4(cg, i);
    row4Can.push(addInkBleed(cc));
  }
  stampTmp = document.createElement('canvas'); stampTmp.width = W; stampTmp.height = H;
  sheet4Canvas = document.createElement('canvas'); sheet4Canvas.width = W; sheet4Canvas.height = H;
  sheet4Ctx = sheet4Canvas.getContext('2d');
  sheet4Tex = new THREE.CanvasTexture(sheet4Canvas); sheet4Tex.colorSpace = THREE.SRGBColorSpace; sheet4Tex.anisotropy = 8;
  const geo = new THREE.BoxGeometry(SHEET_W, .024, SHEET_D);
  const edge = new THREE.MeshStandardMaterial({ color: 0xd8d0bf, roughness: .85 });
  const face = new THREE.MeshBasicMaterial({ map: sheet4Tex });
  const sheet = new THREE.Mesh(geo, [edge, edge, face, edge, edge, edge]);
  sheet.castShadow = true; sheet.receiveShadow = true;
  sheet.position.set(SHEET4_X, .028, 0);
  sheet.rotation.y = -.008;
  scene.add(sheet);
  contactShadow(SHEET4_X + .06, .04, SHEET_W * 1.35, SHEET_D * 1.12, .5);
  setStamp(0, 0, 0);
}
function buildScreens4() {
  const walnut = new THREE.MeshStandardMaterial({ color: 0x6b4a2e, roughness: .6 });
  /* videoeditor thumb brightened at bake (ffmpeg eq) so the demo never reads as a black box */
  const thumbs = ['refs/work-soshimi.jpg', 'refs/work-verdant.jpg', 'refs/work-videoeditor-lit.jpg'];
  thumbs.forEach((src, i) => {
    const grp = new THREE.Group();
    const frame = new THREE.Mesh(new THREE.BoxGeometry(.24, .162, .014), walnut);   /* +20% (critic) */
    frame.castShadow = true; grp.add(frame);
    const tex = new THREE.TextureLoader().load(src); tex.colorSpace = THREE.SRGBColorSpace;
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(.204, .126), new THREE.MeshBasicMaterial({ map: tex }));
    screen.position.z = .0076; grp.add(screen);
    const glow = new THREE.Mesh(new THREE.PlaneGeometry(.215, .137),
      new THREE.MeshBasicMaterial({ color: 0xfff4e0, transparent: true, opacity: .16, blending: THREE.AdditiveBlending, depthWrite: false }));
    glow.position.z = .0072; grp.add(glow);
    const rest = { x: SHEET4_X + 1.02, y: .012, z: .34 + i * .22 };
    grp.position.set(rest.x, rest.y, rest.z);
    grp.rotation.x = -Math.PI / 2 + .25;
    grp.userData.rest = rest;
    scene.add(grp);
    contactShadow(rest.x, rest.z, .34, .22, .4);
    grp.userData.landShadow = contactShadow(SHEET4_X + (i - 1) * .3, -1.22, .3, .14, 0);
    screens4.push(grp);
  });
}
function landPose(s) {
  s = clamp01(s);
  screens4.forEach((grp, i) => {
    const rest = grp.userData.rest;
    const tx = SHEET4_X + (i - 1) * .3, tz = -1.22, ty = .093;
    const u = seg(s, i * .3, i * .3 + .3);
    if (grp.userData.landShadow) grp.userData.landShadow.material.opacity = .4 * clamp01(u);
    if (u <= 0) {
      grp.position.set(rest.x, rest.y, rest.z);
      grp.rotation.x = -Math.PI / 2 + .25;
    } else if (u < .45) {                             /* glide in behind the sheet */
      const e = easeInOut(u / .45);
      grp.position.set(
        THREE.MathUtils.lerp(rest.x, tx, e),
        rest.y + Math.sin(e * Math.PI) * .1,
        THREE.MathUtils.lerp(rest.z, tz, e));
      grp.rotation.x = -Math.PI / 2 + .25;
    } else if (u < .75) {                             /* tilt upright */
      const e = easeInOut(seg(u, .45, .75));
      grp.position.set(tx, THREE.MathUtils.lerp(rest.y, ty, e), tz);
      grp.rotation.x = THREE.MathUtils.lerp(-Math.PI / 2 + .25, -.1, e);
    } else {                                          /* settle */
      const v = seg(u, .75, 1);
      grp.position.set(tx, ty + Math.sin(v * Math.PI * 2) * .004 * (1 - v), tz);
      grp.rotation.x = -.1;
    }
  });
}

/* ---------- chapter 4 sheet (סיפור): the self-drawing sketch ----------
   Live DOM truth (egprobe4, css x2): marker 'פרק 03 — סיפור' Heebo 11css gold
   rgb(217,164,65); beats Suez One 300 30css lh36 #f2e7d5, subs Heebo 200 14css;
   gold closer. Live is a horizontal filmstrip; on-paper the beats become a
   pinned story-sketch that a pencil DRAWS live, stroke by stroke, with the
   beats inking in as marginalia. Gold adapted to #b3852f on paper. */
const SHEET5_X = SHEET4_X + 2.3;
const ZONE5 = [610, 940, 1270];
const BEATS5 = [
  { big: 'מתחיל בהקשבה.', sub: 'איך נראה פרויקט ראשון איתי' },
  { big: 'ממשיך בבנייה.', sub: 'תהליך שקוף, שלב אחר שלב' },
  { big: 'נגמר בפרטים.', sub: 'הרגע שאתה רואה את האתר שלך חי' },
];
const GOLD5 = '#b3852f';
function roughPts(pts, j = 2.5) { return pts.map(([x, y]) => [x + (Math.random() - .5) * j, y + (Math.random() - .5) * j]); }
function circlePoly(cx, cy, r, n = 30) {
  const p = [];
  for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2; p.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); }
  return roughPts(p);
}
function linePoly(x1, y1, x2, y2, n = 8) {
  const p = [];
  for (let i = 0; i <= n; i++) p.push([x1 + (x2 - x1) * i / n, y1 + (y2 - y1) * i / n]);
  return roughPts(p);
}
function rectPoly(x, y, w, h) {
  return roughPts([[x, y], [x + w, y], [x + w, y + h], [x, y + h], [x, y]]);
}
/* three storyboard studies, stroke lists in canvas coords */
function sketchStrokes(i) {
  if (i === 0) {                                       /* הקשבה: two speech bubbles */
    return [
      rectPoly(270, 500, 170, 95),
      linePoly(300, 595, 285, 630),
      linePoly(300, 595, 330, 600),
      rectPoly(380, 545, 150, 85),
      linePoly(500, 630, 515, 660),
      linePoly(500, 630, 470, 633),
      circlePoly(325, 548, 5, 10), circlePoly(355, 548, 5, 10), circlePoly(385, 548, 5, 10),
    ];
  }
  if (i === 1) {                                       /* בנייה: the bench, a frame rising */
    return [
      linePoly(230, 960, 550, 960, 14),                /* bench top */
      linePoly(260, 960, 250, 1040, 6),
      linePoly(520, 960, 530, 1040, 6),
      rectPoly(320, 860, 140, 100),                    /* the site frame */
      linePoly(320, 885, 460, 885, 6),
      circlePoly(335, 872, 4, 8),
      linePoly(390, 862, 390, 840, 5),                 /* rising arrow */
      linePoly(390, 840, 378, 854, 4), linePoly(390, 840, 402, 854, 4),
    ];
  }
  /* פרטים: magnifier over sparkles */
  return [
    circlePoly(390, 1220, 58),
    linePoly(431, 1261, 490, 1320, 8),
    rectPoly(362, 1196, 14, 14), rectPoly(384, 1196, 14, 14), rectPoly(406, 1196, 14, 14),
    rectPoly(362, 1218, 14, 14), rectPoly(384, 1218, 14, 14), rectPoly(406, 1218, 14, 14),
  ];
}
const SKETCH5 = [sketchStrokes(0), sketchStrokes(1), sketchStrokes(2)];
const SK5_LEN = SKETCH5.map(strokes => strokes.map(pts => {
  let L = 0;
  for (let i = 1; i < pts.length; i++) L += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
  return L;
}));
function drawSketchPartial(g, i, f) {
  /* returns the pencil tip point at reveal fraction f */
  const strokes = SKETCH5[i], lens = SK5_LEN[i];
  const total = lens.reduce((a, b) => a + b, 0);
  let remain = total * clamp01(f), tip = strokes[0][0];
  g.strokeStyle = PENCIL; g.lineWidth = 2.6; g.lineCap = 'round'; g.lineJoin = 'round';
  for (let s = 0; s < strokes.length && remain > 0; s++) {
    const pts = strokes[s], L = lens[s], use = Math.min(remain, L);
    g.save();
    g.setLineDash([use, 1e5]);
    g.beginPath();
    g.moveTo(pts[0][0], pts[0][1]);
    for (let k = 1; k < pts.length; k++) g.lineTo(pts[k][0], pts[k][1]);
    g.stroke();
    g.restore();
    /* tip at the current dash end */
    let acc = 0;
    for (let k = 1; k < pts.length; k++) {
      const segL = Math.hypot(pts[k][0] - pts[k - 1][0], pts[k][1] - pts[k - 1][1]);
      if (acc + segL >= use) {
        const r = (use - acc) / segL;
        tip = [pts[k - 1][0] + (pts[k][0] - pts[k - 1][0]) * r, pts[k - 1][1] + (pts[k][1] - pts[k - 1][1]) * r];
        break;
      }
      acc += segL;
    }
    if (use >= L) tip = pts[pts.length - 1];
    remain -= use;
  }
  return tip;
}
function drawInk5Base(g) {
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 44px 'Suez One'";
  g.fillText('נבנה ביד', 726, 84);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  drawSpacedLTR(g, 'SEED 005', 683, 124, 6);
  g.textAlign = 'center';
  g.fillStyle = GOLD5; g.font = "200 22px 'Heebo'";
  drawSpaced(g, 'פרק 03 — סיפור', 390, 210, 4);
  g.fillStyle = INK; g.font = "300 60px 'Suez One'";
  g.fillText('לכל עסק יש סיפור.', 390, 320);
  g.fillText('האתר שלך הוא היצירה', 390, 392);
  g.fillText('שמספרת אותו.', 390, 464);
}
function drawBeat5(g, i) {
  const yb = [770, 1100, 1430][i], ys = yb + 40;
  g.textAlign = 'center'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "300 60px 'Suez One'";
  g.fillText(BEATS5[i].big, 390, yb);
  g.fillStyle = DIM; g.font = "200 28px 'Heebo'";
  g.fillText(BEATS5[i].sub, 390, ys);
}
function drawCloser5(g) {
  g.textAlign = 'center'; g.textBaseline = 'alphabetic';
  g.fillStyle = GOLD5; g.font = "300 52px 'Suez One'";
  g.fillText('הסיפור שלך יכול להיות הבא.', 390, 1610);
}
function drawWireframe5(g) {
  g.strokeStyle = PENCIL; g.lineWidth = 2; g.lineCap = 'round';
  const j = n => n + (Math.random() - .5) * 5;
  for (const cy of ZONE5) {                            /* sketch frame rects */
    g.strokeRect(j(180), j(cy - 110), 420, 220);
  }
}
let sheet5Tex, sheet5Canvas, sheet5Ctx, sheet5Base, sheet5Wire, beat5Can = [], closer5Can, stamp5Tmp, lastStory = '', pencil5;
function setStory(d0, d1, d2, b0, b1, b2, bc) {
  const key = [d0, d1, d2, b0, b1, b2, bc].map(v => v.toFixed(3)).join(',');
  if (key === lastStory) return '';
  lastStory = key;
  const W = 780, H = 1688, g = sheet5Ctx;
  g.clearRect(0, 0, W, H);
  g.drawImage(sheet5Base, 0, 0);
  const totD = (d0 + d1 + d2) / 3;
  g.globalAlpha = 1 - .5 * totD;                       /* plan fades as the sketch lands */
  g.drawImage(sheet5Wire, 0, 0);
  g.globalAlpha = 1;
  const tip = drawSketchPartial(g, 0, d0);
  let liveTip = tip;
  if (d1 > 0) liveTip = drawSketchPartial(g, 1, d1);
  if (d2 > 0) liveTip = drawSketchPartial(g, 2, d2);
  const tg = stamp5Tmp.getContext('2d');
  const stamps = [[b0, 770], [b1, 1100], [b2, 1430], [bc, 1610]];
  stamps.forEach(([f, cy], i) => {
    if (f <= 0) return;
    tg.clearRect(0, 0, W, H);
    tg.drawImage(i < 3 ? beat5Can[i] : closer5Can, 0, 0);
    tg.globalCompositeOperation = 'destination-in';
    const r = easeInOut(f) * 330;
    const gr = tg.createRadialGradient(390, cy, Math.max(0, r - 50), 390, cy, r);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    tg.fillStyle = gr; tg.fillRect(0, 0, W, H);
    tg.globalCompositeOperation = 'source-over';
    g.drawImage(stamp5Tmp, 0, 0);
  });
  sheet5Tex.needsUpdate = true;
  return (d2 > 0 || d1 > 0 || d0 > 0) && (d0 < 1 || d1 < 1 || d2 < 1) ? liveTip : '';
}
function buildSheet5() {
  const W = 780, H = 1688;
  sheet5Wire = document.createElement('canvas'); sheet5Wire.width = W; sheet5Wire.height = H;
  const wg = sheet5Wire.getContext('2d'); drawWireframe5(wg);
  const baseRaw = document.createElement('canvas'); baseRaw.width = W; baseRaw.height = H;
  const ig = baseRaw.getContext('2d');
  drawPaperBase(ig, W, H); drawInk5Base(ig);
  sheet5Base = addInkBleed(baseRaw);
  for (let i = 0; i < 3; i++) {
    const cc = document.createElement('canvas'); cc.width = W; cc.height = H;
    const cg = cc.getContext('2d'); drawBeat5(cg, i);
    beat5Can.push(addInkBleed(cc));
  }
  closer5Can = document.createElement('canvas'); closer5Can.width = W; closer5Can.height = H;
  drawCloser5(closer5Can.getContext('2d'));
  closer5Can = addInkBleed(closer5Can);
  stamp5Tmp = document.createElement('canvas'); stamp5Tmp.width = W; stamp5Tmp.height = H;
  sheet5Canvas = document.createElement('canvas'); sheet5Canvas.width = W; sheet5Canvas.height = H;
  sheet5Ctx = sheet5Canvas.getContext('2d');
  sheet5Tex = new THREE.CanvasTexture(sheet5Canvas); sheet5Tex.colorSpace = THREE.SRGBColorSpace; sheet5Tex.anisotropy = 8;
  const geo = new THREE.BoxGeometry(SHEET_W, .024, SHEET_D);
  const edge = new THREE.MeshStandardMaterial({ color: 0xd8d0bf, roughness: .85 });
  const face = new THREE.MeshBasicMaterial({ map: sheet5Tex });
  const sheet = new THREE.Mesh(geo, [edge, edge, face, edge, edge, edge]);
  sheet.castShadow = true; sheet.receiveShadow = true;
  sheet.position.set(SHEET5_X, .028, 0);
  sheet.rotation.y = .012;
  scene.add(sheet);
  contactShadow(SHEET5_X - .04, .04, SHEET_W * 1.35, SHEET_D * 1.12, .5);
  setStory(0, 0, 0, 0, 0, 0, 0);
}
function buildPencil5() {
  pencil5 = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CylinderGeometry(.017, .017, .3, 8),
    new THREE.MeshStandardMaterial({ color: 0xcc5533, roughness: .6 }));
  body.position.y = .18; body.castShadow = true; pencil5.add(body);
  const wood = new THREE.Mesh(new THREE.ConeGeometry(.016, .05, 8),
    new THREE.MeshStandardMaterial({ color: 0xd9c9a8, roughness: .85 }));
  wood.rotation.x = Math.PI; wood.position.y = .005; pencil5.add(wood);
  const lead = new THREE.Mesh(new THREE.ConeGeometry(.005, .018, 6),
    new THREE.MeshStandardMaterial({ color: 0x3a3a3c, roughness: .5 }));
  lead.rotation.x = Math.PI; lead.position.y = -.02; pencil5.add(lead);
  pencil5.position.set(SHEET5_X + .35, .02, 1.22);
  pencil5.rotation.z = 1.35; pencil5.rotation.y = .4;
  scene.add(pencil5);
  contactShadow(SHEET5_X + .35, 1.22, .3, .16, .4);
}
const P5_REST = { x: SHEET5_X + .35, y: .02, z: 1.22 };
let p5Hop = null;
const c2w5 = (px, py) => [SHEET5_X + (px / 780 - .5) * SHEET_W, (py / 1688 - .5) * SHEET_D];
function drawPose(s, tip) {
  if (!pencil5) return;
  s = clamp01(s);
  if (s <= 0 || !tip) {
    if (s <= 0) { pencil5.position.set(P5_REST.x, P5_REST.y, P5_REST.z); pencil5.rotation.z = 1.35; }
    else if (s > .93) {                              /* the work is signed: pencil goes home */
      const u = easeInOut(seg(s, .93, 1));
      pencil5.position.x = THREE.MathUtils.lerp(pencil5.position.x, P5_REST.x, u);
      pencil5.position.y = THREE.MathUtils.lerp(pencil5.position.y, P5_REST.y, u);
      pencil5.position.z = THREE.MathUtils.lerp(pencil5.position.z, P5_REST.z, u);
      pencil5.rotation.z = THREE.MathUtils.lerp(pencil5.rotation.z, 1.35, u);
      pencil5.rotation.x = THREE.MathUtils.lerp(pencil5.rotation.x, 0, u);
    }
    return;
  }
  const [wx, wz] = c2w5(tip[0], tip[1]);
  const tx = wx + .035, tz = wz + .045;
  const jumped = Math.hypot(pencil5.position.x - tx, pencil5.position.z - tz) > .18
    && Math.abs(pencil5.position.y - .045) < .01;
  if (jumped && !p5Hop) p5Hop = { fx: pencil5.position.x, fz: pencil5.position.z, t0: performance.now() };
  if (p5Hop) {
    const u = Math.min((performance.now() - p5Hop.t0) / 260, 1);
    if (u >= 1) p5Hop = null;
    else {
      const e = easeInOut(u);
      pencil5.position.set(THREE.MathUtils.lerp(p5Hop.fx, tx, e), .045 + Math.sin(u * Math.PI) * .06, THREE.MathUtils.lerp(p5Hop.fz, tz, e));
      pencil5.rotation.z = .5; pencil5.rotation.x = -.3;
      return;
    }
  }
  pencil5.position.set(tx, .045, tz);
  pencil5.rotation.z = .5; pencil5.rotation.x = -.3;    /* writing tilt */
}

/* ---------- chapter 5 sheet (אור): the light reveal ----------
   Live DOM truth (egprobe5/5b, css x2): the אור panel carries ONE cap:
   'אתר יפה שאף אחד לא רואה — לא עובד.' Heebo 200 13css dim ls2.34,
   centered, baseline ~1475 canvas. The live panel is otherwise a light visual.
   Action (distinct #6): a brass banker's lamp arcs over the sheet, clicks on,
   and a warm light pool reveals the faint site-sketch nobody was seeing;
   the cap stamps inside the pool. */
const SHEET6_X = SHEET5_X + 2.3;
function drawWireframe6(g) {
  g.strokeStyle = '#6b665c'; g.lineWidth = 2.6; g.lineCap = 'round';   /* critic: visible pencil, delta 25-35+ */

  const j = n => n + (Math.random() - .5) * 5;
  /* the unseen site: a browser window study */
  g.strokeRect(j(160), j(720), 460, 320);
  g.beginPath(); g.moveTo(160, 762); g.lineTo(620, 762); g.stroke();
  circleStrokeAt(g, 185, 741, 6); circleStrokeAt(g, 209, 741, 6); circleStrokeAt(g, 233, 741, 6);
  g.strokeRect(j(200), j(800), 180, 22);
  g.strokeRect(j(200), j(850), 380, 14); g.strokeRect(j(200), j(878), 340, 14); g.strokeRect(j(200), j(906), 370, 14);
  g.strokeRect(j(200), j(950), 110, 60); g.strokeRect(j(340), j(950), 110, 60); g.strokeRect(j(480), j(950), 110, 60);
  /* no placeholder strokes near y1475: the light-reveal cap lands there */
}
function circleStrokeAt(g, cx, cy, r) {
  g.beginPath(); g.arc(cx + (Math.random() - .5) * 3, cy + (Math.random() - .5) * 3, r, 0, Math.PI * 2); g.stroke();
}
function drawInk6Base(g) {
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 44px 'Suez One'";
  g.fillText('נבנה ביד', 726, 84);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  drawSpacedLTR(g, 'SEED 005', 683, 124, 6);
}
let sheet6Tex, sheet6Canvas, sheet6Ctx, sheet6Base, sheet6Wire, cap6Can, stamp6Tmp, lastLight = '';
let lampGroup, lampShade, lampLight, motes, motePos;
function setLight(pool, capF) {
  const key = pool.toFixed(3) + ',' + capF.toFixed(3);
  if (key === lastLight) return;
  lastLight = key;
  const W = 780, H = 1688, g = sheet6Ctx;
  g.clearRect(0, 0, W, H);
  g.drawImage(sheet6Base, 0, 0);
  const cx = 420, cy = 960;                         /* pool biased toward the lamp */
  if (pool > 0) {
    const pe = easeInOut(pool);
    const r = pe * 500;
    const tg = stamp6Tmp.getContext('2d');
    /* dim everything OUTSIDE the light pool */
    tg.clearRect(0, 0, W, H);
    tg.fillStyle = 'rgba(46,40,32,' + (.34 * pe).toFixed(3) + ')';
    tg.fillRect(0, 0, W, H);
    tg.globalCompositeOperation = 'destination-out';
    const gr0 = tg.createRadialGradient(cx, cy, 0, cx, cy, r);
    gr0.addColorStop(0, 'rgba(0,0,0,1)'); gr0.addColorStop(.65, 'rgba(0,0,0,.85)'); gr0.addColorStop(1, 'rgba(0,0,0,0)');
    tg.fillStyle = gr0; tg.fillRect(0, 0, W, H);
    tg.globalCompositeOperation = 'source-over';
    g.drawImage(stamp6Tmp, 0, 0);
    /* the sketch appears where the light lands */
    tg.clearRect(0, 0, W, H);
    tg.drawImage(sheet6Wire, 0, 0);
    tg.globalCompositeOperation = 'destination-in';
    const gr = tg.createRadialGradient(cx, cy, 0, cx, cy, r);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(.7, 'rgba(0,0,0,.8)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    tg.fillStyle = gr; tg.fillRect(0, 0, W, H);
    tg.globalCompositeOperation = 'source-over';
    g.drawImage(stamp6Tmp, 0, 0);
    /* pronounced warm pool on the paper */
    const gr2 = g.createRadialGradient(cx, cy, 0, cx, cy, r);
    gr2.addColorStop(0, 'rgba(255,172,56,.56)'); gr2.addColorStop(.6, 'rgba(255,190,92,.3)'); gr2.addColorStop(1, 'rgba(255,196,107,0)');
    g.fillStyle = gr2; g.fillRect(0, 0, W, H);
  }
  if (capF > 0) {
    const tg = stamp6Tmp.getContext('2d');
    tg.clearRect(0, 0, W, H);
    tg.drawImage(cap6Can, 0, 0);
    tg.globalCompositeOperation = 'destination-in';
    const r = easeInOut(capF) * 330;
    const gr = tg.createRadialGradient(390, 1475, Math.max(0, r - 40), 390, 1475, r);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(.85, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    tg.fillStyle = gr; tg.fillRect(0, 0, W, H);
    tg.globalCompositeOperation = 'source-over';
    g.drawImage(stamp6Tmp, 0, 0);
  }
  sheet6Tex.needsUpdate = true;
}
/* banker's lamp: base fixed at bench right, stem leans in over the sheet,
   shade counter-rotates to keep the cone pointing down at the paper */
const LAMP_BASE_POS = { x: SHEET6_X + SHEET_W / 2, z: -.28 };   /* rim fully in frame (critic carry-forward) */
const LAMP_REST = { stem: .14, shadeTilt: 0 };
const LAMP_OVER = { stem: .88, shadeTilt: -.12 };   /* base moved in .02: same shade landing zone */  /* deep lean: shade low over empty upper-center, clears maker-mark (perspective pushes it right) */
function buildSheet6() {
  const W = 780, H = 1688;
  sheet6Wire = document.createElement('canvas'); sheet6Wire.width = W; sheet6Wire.height = H;
  drawWireframe6(sheet6Wire.getContext('2d'));
  const baseRaw = document.createElement('canvas'); baseRaw.width = W; baseRaw.height = H;
  const ig = baseRaw.getContext('2d');
  drawPaperBase(ig, W, H); drawInk6Base(ig);
  sheet6Base = addInkBleed(baseRaw);
  cap6Can = document.createElement('canvas'); cap6Can.width = W; cap6Can.height = H;
  const cg = cap6Can.getContext('2d');
  cg.textAlign = 'center'; cg.textBaseline = 'alphabetic';
  cg.fillStyle = INK; cg.font = "400 26px 'Heebo'";   /* critic: mid-dark ink, delta 60-80+ */

  drawSpaced(cg, 'אתר יפה שאף אחד לא רואה — לא עובד.', 390, 1475, 4.68);
  cap6Can = addInkBleed(cap6Can);
  stamp6Tmp = document.createElement('canvas'); stamp6Tmp.width = W; stamp6Tmp.height = H;
  sheet6Canvas = document.createElement('canvas'); sheet6Canvas.width = W; sheet6Canvas.height = H;
  sheet6Ctx = sheet6Canvas.getContext('2d');
  sheet6Tex = new THREE.CanvasTexture(sheet6Canvas); sheet6Tex.colorSpace = THREE.SRGBColorSpace; sheet6Tex.anisotropy = 8;
  const geo = new THREE.BoxGeometry(SHEET_W, .024, SHEET_D);
  const edge = new THREE.MeshStandardMaterial({ color: 0xd8d0bf, roughness: .85 });
  const face = new THREE.MeshBasicMaterial({ map: sheet6Tex });
  const sheet = new THREE.Mesh(geo, [edge, edge, face, edge, edge, edge]);
  sheet.castShadow = true; sheet.receiveShadow = true;
  sheet.position.set(SHEET6_X, .028, 0);
  sheet.rotation.y = .009;
  scene.add(sheet);
  contactShadow(SHEET6_X + .05, .04, SHEET_W * 1.35, SHEET_D * 1.12, .5);
  setLight(0, 0);
}
function buildLamp() {
  const brass = new THREE.MeshStandardMaterial({ color: 0xb3852f, roughness: .32, metalness: .85, envMapIntensity: 1.2 });
  lampGroup = new THREE.Group();
  const base = new THREE.Mesh(new THREE.CylinderGeometry(.11, .13, .03, 20), brass);
  base.position.y = .015; base.castShadow = true; lampGroup.add(base);
  const collar = new THREE.Mesh(new THREE.SphereGeometry(.035, 12, 8), brass);
  collar.position.y = .045; lampGroup.add(collar);
  const arm = new THREE.Mesh(new THREE.CylinderGeometry(.014, .018, .5, 10), brass);
  arm.geometry.translate(0, .25, 0);
  arm.position.y = .05; arm.castShadow = true; lampGroup.add(arm);
  lampShade = new THREE.Group();
  const shade = new THREE.Mesh(new THREE.ConeGeometry(.085, .11, 20, 1, true), brass);
  shade.castShadow = true; lampShade.add(shade);
  const shadeInner = new THREE.Mesh(new THREE.ConeGeometry(.08, .105, 20, 1, true),
    new THREE.MeshStandardMaterial({ color: 0xfff3d8, roughness: .6, side: THREE.BackSide }));
  lampShade.add(shadeInner);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(.026, 10, 8),
    new THREE.MeshBasicMaterial({ color: 0xd8d0c0 }));
  bulb.position.y = -.04; lampShade.add(bulb);
  lampShade.position.y = .5;
  arm.add(lampShade);
  lampGroup.userData.arm = arm;
  lampGroup.userData.bulb = bulb;
  lampGroup.position.set(LAMP_BASE_POS.x, 0, LAMP_BASE_POS.z);
  arm.rotation.z = LAMP_REST.stem;
  lampShade.rotation.z = -LAMP_REST.stem + LAMP_REST.shadeTilt;
  scene.add(lampGroup);
  lampGroup.userData.restShadow = contactShadow(LAMP_BASE_POS.x, LAMP_BASE_POS.z, .42, .36, .45);
  lampLight = new THREE.PointLight(0xffc46b, 0, 3.2, 1.6);
  lampLight.position.set(SHEET6_X + .12, .5, -.12);
  scene.add(lampLight);
  /* dust motes in the beam */
  const N = 14, arr = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) {
    arr[i * 3] = SHEET6_X + (Math.random() - .5) * .5;
    arr[i * 3 + 1] = .1 + Math.random() * .5;
    arr[i * 3 + 2] = -.5 + (Math.random() - .5) * .6;
  }
  const mg = new THREE.BufferGeometry();
  mg.setAttribute('position', new THREE.BufferAttribute(arr, 3));
  motes = new THREE.Points(mg, new THREE.PointsMaterial({ color: 0xffe6b8, size: .008, transparent: true, opacity: 0 }));
  scene.add(motes);
  motePos = arr;
}
function lampPose(s) {
  if (!lampGroup) return;
  s = clamp01(s);
  const arm = lampGroup.userData.arm;
  const lean = easeInOut(seg(s, 0, .3));               /* stem leans in over the sheet */
  const dip = easeInOut(seg(s, .3, .44));              /* shade dips toward the paper */
  const wob = s > .44 && s < .54 ? Math.sin((s - .44) * 60) * .012 * (1 - seg(s, .44, .54)) : 0;
  const stem = THREE.MathUtils.lerp(LAMP_REST.stem, LAMP_OVER.stem, lean) + wob;
  arm.rotation.z = stem;
  lampShade.rotation.z = -stem + THREE.MathUtils.lerp(LAMP_REST.shadeTilt, LAMP_OVER.shadeTilt, dip) + wob;
  const on = seg(s, .44, .52);                         /* click: light on */
  lampLight.intensity = on * 1.5;
  lampGroup.userData.bulb.material.color.setHex(on > .5 ? 0xfff2d0 : 0xd8d0c0);
  motes.material.opacity = on * .85;
  if (on > 0) {                                        /* mote drift */
    for (let i = 0; i < motePos.length / 3; i++) {
      motePos[i * 3 + 1] += .0006;
      if (motePos[i * 3 + 1] > .62) motePos[i * 3 + 1] = .1;
    }
    motes.geometry.attributes.position.needsUpdate = true;
  }
}

/* ---------- chapter 6 sheet (outro): the handover ----------
   Live DOM truth (egprobe6, css x2): pre 'היצירה הבאה שיוצאת מהסדנה — שלך.',
   big 'בוא נבנה' / 'את שלך.' (two lines), small 'חנויות וורדפרס · דפי נחיתה · אתרי עסק',
   CTA 'דברו איתי ↗' (x103 y494 w184 h53 -> canvas w368 h106), meta row
   'נבנה ביד, פרט אחר פרט' / 'הקוד פתוח ↗' / 'מההתחלה ↺'.
   Action (distinct #7): the handover - the finished piece slides across the
   bench toward the viewer/client side and settles at the near edge.
   CTA stays INERT in the proof: phone number awaiting Itamar's approval. */
const SHEET7_X = SHEET6_X + 2.3;
let sheet7Tex, sheet7Canvas, sheet7Ctx, sheet7Mesh, sheet7Shadow, lastHand = -1;
function drawInk7(g) {
  const W = 780;
  g.textAlign = 'right'; g.textBaseline = 'alphabetic';
  g.fillStyle = INK; g.font = "900 44px 'Suez One'";
  g.fillText('נבנה ביד', 726, 84);
  g.fillStyle = DIM; g.font = "200 22px 'Heebo'";
  drawSpacedLTR(g, 'SEED 005', 683, 124, 6);
  g.textAlign = 'center';
  g.fillStyle = MID; g.font = "400 26px 'Heebo'";
  g.fillText('היצירה הבאה שיוצאת מהסדנה — שלך.', 390, 460);
  g.fillStyle = INK; g.font = "900 116px 'Suez One'";
  g.fillText('בוא נבנה', 390, 620);
  g.fillText('את שלך.', 390, 780);
  g.fillStyle = MID; g.font = "400 24px 'Heebo'";
  g.fillText('חנויות וורדפרס · דפי נחיתה · אתרי עסק', 390, 880);
  /* the inert CTA: gold-outlined stamp button */
  g.strokeStyle = GOLD; g.lineWidth = 4;
  g.beginPath();
  const bx = 390 - 184, by = 980, bw = 368, bh = 106, br = 53;
  g.moveTo(bx + br, by); g.lineTo(bx + bw - br, by); g.arc(bx + bw - br, by + br, br, -Math.PI / 2, Math.PI / 2);
  g.lineTo(bx + br, by + bh); g.arc(bx + br, by + br, br, Math.PI / 2, Math.PI * 1.5);
  g.closePath(); g.stroke();
  g.fillStyle = GOLD; g.font = "900 44px 'Suez One'";
  g.fillText('דברו איתי ↗', 390, 1046);
  /* demo number under the pill, clearly a placeholder */
  g.fillStyle = MID; g.font = "400 30px 'Heebo'";
  drawSpacedLTR(g, CTA_PHONE, 390, 1120, 4);
  /* meta row: one centered line (live spreads 3 items; adapted - the handover
     slide brings the sheet closer, spread items clip at the frame edges) */
  g.fillStyle = MID; g.font = "400 19px 'Heebo'";
  g.textAlign = 'center';
  g.fillText('נבנה ביד, פרט אחר פרט · הקוד פתוח ↗ · מההתחלה ↺', 390, 1400);
}
function setHandover(h) {
  if (h === lastHand || !sheet7Mesh) return;
  lastHand = h;
  const e = h < 1 ? 1 + 2.2 * Math.pow(h - 1, 3) + 1.2 * Math.pow(h - 1, 2) : 1; /* ease-out-back */
  const z = e * .42;
  sheet7Mesh.position.z = z;
  sheet7Mesh.position.y = .028 + Math.sin(Math.min(h, 1) * Math.PI) * .012;
  sheet7Mesh.rotation.y = .009 - Math.min(h, 1) * .015;
  if (sheet7Shadow) {
    sheet7Shadow.position.z = .04 + z;
    sheet7Shadow.material.opacity = .5 - Math.sin(Math.min(h, 1) * Math.PI) * .12;
  }
}
function buildSheet7() {
  const W = 780, H = 1688;
  const baseRaw = document.createElement('canvas'); baseRaw.width = W; baseRaw.height = H;
  const ig = baseRaw.getContext('2d');
  drawPaperBase(ig, W, H); drawInk7(ig);
  sheet7Canvas = addInkBleed(baseRaw);
  sheet7Tex = new THREE.CanvasTexture(sheet7Canvas); sheet7Tex.colorSpace = THREE.SRGBColorSpace; sheet7Tex.anisotropy = 8;
  const geo = new THREE.BoxGeometry(SHEET_W, .024, SHEET_D);
  const edge = new THREE.MeshStandardMaterial({ color: 0xd8d0bf, roughness: .85 });
  const face = new THREE.MeshBasicMaterial({ map: sheet7Tex });
  sheet7Mesh = new THREE.Mesh(geo, [edge, edge, face, edge, edge, edge]);
  sheet7Mesh.castShadow = true; sheet7Mesh.receiveShadow = true;
  sheet7Mesh.position.set(SHEET7_X, .028, 0);
  sheet7Mesh.rotation.y = .009;
  scene.add(sheet7Mesh);
  sheet7Shadow = contactShadow(SHEET7_X + .05, .04, SHEET_W * 1.35, SHEET_D * 1.12, .5);
  setHandover(0);
}

/* ---------- camera + scroll ---------- */
const camCurve = t => {
  /* approach: from the left end of the bench, settle over the hero sheet */
  const x = THREE.MathUtils.lerp(-6.35, HERO_X, easeInOut(t));
  return x;
};
function camTravel(u) {                                /* hero lock -> ch1 lock */
  const e = easeInOut(u);
  const x = THREE.MathUtils.lerp(HERO_X, SHEET2_X, e);
  camera.position.set(x, 1.44 + Math.sin(e * Math.PI) * .12, 1.9);
  camera.lookAt(x, -.05, .3);
}
function camSheet2Lock() {
  camera.position.set(SHEET2_X, 1.44, 1.9);
  camera.lookAt(SHEET2_X, -.05, .3);
}
function camTravel2(u) {                               /* ch1 lock -> ch2 lock */
  const e = easeInOut(u);
  const x = THREE.MathUtils.lerp(SHEET2_X, SHEET3_X, e);
  camera.position.set(x, 1.44 + Math.sin(e * Math.PI) * .12, 1.9);
  camera.lookAt(x, -.05, .3);
}
function camSheet3Lock() {
  camera.position.set(SHEET3_X, 1.44, 1.9);
  camera.lookAt(SHEET3_X, -.05, .3);
}
function camTravel3(u) {                               /* ch2 lock -> ch3 lock */
  const e = easeInOut(u);
  const x = THREE.MathUtils.lerp(SHEET3_X, SHEET4_X, e);
  camera.position.set(x, 1.44 + Math.sin(e * Math.PI) * .12, 1.9);
  camera.lookAt(x, -.05, .3);
}
function camSheet4Lock() {
  camera.position.set(SHEET4_X, 1.44, 1.9);
  camera.lookAt(SHEET4_X, -.05, .3);
}
function camTravel4(u) {                               /* ch3 lock -> ch4 lock */
  const e = easeInOut(u);
  const x = THREE.MathUtils.lerp(SHEET4_X, SHEET5_X, e);
  camera.position.set(x, 1.44 + Math.sin(e * Math.PI) * .12, 1.9);
  camera.lookAt(x, -.05, .3);
}
function camSheet5Lock() {
  camera.position.set(SHEET5_X, 1.44, 1.9);
  camera.lookAt(SHEET5_X, -.05, .3);
}
function camTravel5(u) {                               /* ch4 lock -> ch5 lock */
  const e = easeInOut(u);
  const x = THREE.MathUtils.lerp(SHEET5_X, SHEET6_X, e);
  camera.position.set(x, 1.44 + Math.sin(e * Math.PI) * .12, 1.9);
  camera.lookAt(x, -.05, .3);
}
function camSheet6Lock() {
  camera.position.set(SHEET6_X, 1.44, 1.9);
  camera.lookAt(SHEET6_X, -.05, .3);
}
function camTravel6(u) {                               /* ch5 lock -> ch6 lock */
  const e = easeInOut(u);
  const x = THREE.MathUtils.lerp(SHEET6_X, SHEET7_X, e);
  camera.position.set(x, 1.44 + Math.sin(e * Math.PI) * .12, 1.9);
  camera.lookAt(x, -.05, .3);
}
function camSheet7Lock() {
  camera.position.set(SHEET7_X, 1.44, 1.9);
  camera.lookAt(SHEET7_X, -.05, .3);
}
function seg(t, a, b) { return clamp01((t - a) / (b - a)); }
function diePose(t) {
  if (!dieGroup) return;
  let p;
  if (t < .5) p = DIE_REST;
  else if (t < .62) {                              /* lift + glide over the sheet */
    const u = easeInOut(seg(t, .5, .62));
    p = { x: THREE.MathUtils.lerp(DIE_REST.x, DIE_HOVER.x, u),
          y: THREE.MathUtils.lerp(DIE_REST.y, DIE_HOVER.y, u),
          z: THREE.MathUtils.lerp(DIE_REST.z, DIE_HOVER.z, u) };
  } else if (t < .7) {                             /* the fall */
    const u = seg(t, .62, .7); const e = u * u;
    p = { x: DIE_HOVER.x, y: THREE.MathUtils.lerp(DIE_HOVER.y, DIE_PRESS.y, e), z: DIE_HOVER.z };
  } else if (t < .8) {                             /* dwell on the sheet, tiny settle */
    const u = seg(t, .7, .8);
    p = { x: DIE_PRESS.x, y: DIE_PRESS.y + Math.sin(u * Math.PI * 2) * .004 * (1 - u), z: DIE_PRESS.z };
  } else if (t < .92) {                            /* lift away and home */
    const u = easeInOut(seg(t, .8, .92));
    p = { x: THREE.MathUtils.lerp(DIE_PRESS.x, DIE_REST.x, u),
          y: THREE.MathUtils.lerp(DIE_PRESS.y, DIE_REST.y, u) + Math.sin(u * Math.PI) * .3,
          z: THREE.MathUtils.lerp(DIE_PRESS.z, DIE_REST.z, u) };
  } else p = DIE_REST;
  dieGroup.position.set(p.x, p.y, p.z);
  dieGroup.rotation.y = THREE.MathUtils.lerp(-.2, 0, seg(t, .5, .62)) + (t >= .92 || t < .5 ? -.0 : 0);
}
function updateCam(t) {
  const x = camCurve(t);
  const lift = Math.sin(Math.PI * clamp01(t)) * .1;
  const settle = easeInOut(t);
  camera.position.set(x, 1.62 - .18 * settle + lift, 1.62 + .28 * settle);
  camera.lookAt(x, THREE.MathUtils.lerp(.92, -.05, settle), THREE.MathUtils.lerp(-2.45, .3, settle));
}

/* ---------- boot ---------- */
(async () => {
  await loadFonts();
  buildSheet();
  buildSheet2();
  buildSheet3();
  buildSheet4();
  buildScreens4();
  buildSheet5();
  buildPencil5();
  buildSheet6();
  buildLamp();
  buildSheet7();
  wireBackup = (() => { const c = document.createElement('canvas'); c.width = 780; c.height = 1688;
    const g = c.getContext('2d'); drawPaperBase(g, 780, 1688); drawWireframe(g, 780, 1688); return c; })();
  setWipe(0);
  contactShadow(HERO_X + .06, .04, SHEET_W * 1.35, SHEET_D * 1.12, .5);
  contactShadow(HERO_X + .62, -1.24, .55, .45, .55);
  contactShadow(HERO_X + 1.55, -.55, .5, .4, .5);
  contactShadow(-6.9, -.62, .42, .36, .5);
  contactShadow(HERO_X + 1.15, -.68, .3, .26, .45);
  let scrollT = 0, scrollC = 0;
  const onScroll = () => {
    const max = document.getElementById('scroll').offsetHeight - innerHeight;
    scrollT = max > 0 ? scrollY / max : 0;
  };
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });
  window.__focusSheet7 = () => { window.__f7 = true; };
  window.__focusSheet6 = () => { window.__f6 = true; };
  window.__focusSheet5 = () => { window.__f5 = true; };
  window.__focusSheet4 = () => { window.__f4 = true; };
  window.__focusSheet3 = () => { window.__f3 = true; };
  window.__focusSheet2 = () => { window.__f2 = true; };
  function tick() {
    requestAnimationFrame(tick);
    if (window.__f7) {
      camera.position.set(SHEET7_X, 1.44, 1.9);
      camera.lookAt(SHEET7_X, -.05, .3);
    } else if (window.__f6) {
      camera.position.set(SHEET6_X, 1.44, 1.9);
      camera.lookAt(SHEET6_X, -.05, .3);
    } else if (window.__f5) {
      camera.position.set(SHEET5_X, 1.44, 1.9);
      camera.lookAt(SHEET5_X, -.05, .3);
    } else if (window.__f4) {
      camera.position.set(SHEET4_X, 1.44, 1.9);
      camera.lookAt(SHEET4_X, -.05, .3);
    } else if (window.__f3) {
      camera.position.set(SHEET3_X, 1.44, 1.9);
      camera.lookAt(SHEET3_X, -.05, .3);
    } else if (window.__f2) {
      camera.position.set(SHEET2_X, 1.44, 1.9);
      camera.lookAt(SHEET2_X, -.05, .3);
    } else {
      scrollC += (scrollT - scrollC) * .12;
      const tt = clamp01(scrollC);
      const t = tt < .68 ? tt / .68 : tt;            /* ch0-5 chain compressed into tt<.68 */
      if (tt < .68) {
        if (t < .63) {                               /* ch0-4 within the compressed chain */
          const u4 = t / .63;
          if (u4 < .68) {                            /* ch0-3 */
            const u3 = u4 / .68;
            if (u3 < .73) {                          /* ch0-2 */
              const u2 = u3 / .73;
              if (u2 < .8) {                         /* hero + ch1 chain, remapped */
                const u = u2 / .8;
                if (u < .3) {                        /* hero: approach + ink */
                  const th = u / .3;
                  updateCam(Math.min(th / .5, 1));
                  setWipe((th - .3) / .6);
                  setPress(0);
                } else if (u < .5) {                 /* hero -> ch1 travel */
                  camTravel(seg(u, .3, .5));
                } else {                             /* ch1: the press + lock */
                  camSheet2Lock();
                }
                diePose(u);
                setPress(u < .5 ? 0 : seg(u, .66, .8));
                calPose(0); setScribe(0, 0, 0);
              } else if (u2 < .9) {                  /* ch1 -> ch2 travel */
                diePose(1); setPress(1);
                camTravel2(seg(u2, .8, .9));
                calPose(0); setScribe(0, 0, 0);
              } else {                               /* ch2: the scribe + lock */
                diePose(1); setPress(1);
                camSheet3Lock();
                const sc = seg(u2, .9, 1);
                calPose(sc);
                const f = i => clamp01((clamp01((sc - i * .3) / .3) - .4) / .5);
                setScribe(f(0), f(1), f(2));
              }
            } else if (u3 < .865) {                  /* ch2 -> ch3 travel */
              diePose(1); setPress(1); calPose(0); setScribe(1, 1, 1);
              landPose(0); setStamp(0, 0, 0);
              camTravel3(seg(u3, .73, .865));
            } else {                                 /* ch3: the landing + lock */
              diePose(1); setPress(1); calPose(0); setScribe(1, 1, 1);
              camSheet4Lock();
              const ls = seg(u3, .865, 1);
              landPose(ls);
              const sf = i => seg(ls, i * .3 + .16, i * .3 + .27);
              setStamp(sf(0), sf(1), sf(2));
            }
          } else if (u4 < .815) {                    /* ch3 -> ch4 travel */
            diePose(1); setPress(1); calPose(0); setScribe(1, 1, 1);
            landPose(1); setStamp(1, 1, 1);
            drawPose(0, ''); setStory(0, 0, 0, 0, 0, 0, 0);
            camTravel4(seg(u4, .68, .815));
          } else {                                   /* ch4: the live sketch + lock */
            diePose(1); setPress(1); calPose(0); setScribe(1, 1, 1);
            landPose(1); setStamp(1, 1, 1);
            camSheet5Lock();
            const st = seg(u4, .815, 1);
            const d = i => seg(st, .08 + i * .26, .08 + i * .26 + .17);
            const bf = i => seg(st, .08 + i * .26 + .17, .08 + i * .26 + .23);
            const tip = setStory(d(0), d(1), d(2), bf(0), bf(1), bf(2), seg(st, .86, .97));
            drawPose(st, tip);
          }
        } else if (t < .815) {                       /* ch4 -> ch5 travel */
          diePose(1); setPress(1); calPose(0); setScribe(1, 1, 1);
          landPose(1); setStamp(1, 1, 1);
          drawPose(0, ''); setStory(1, 1, 1, 1, 1, 1, 1);
          lampPose(0); setLight(0, 0);
          camTravel5(seg(t, .63, .815));
        } else {                                     /* ch5: the light reveal + lock */
          diePose(1); setPress(1); calPose(0); setScribe(1, 1, 1);
          landPose(1); setStamp(1, 1, 1);
          drawPose(0, ''); setStory(1, 1, 1, 1, 1, 1, 1);
          camSheet6Lock();
          const lt = seg(t, .815, 1);
          lampPose(lt);
          setLight(seg(lt, .42, .78), seg(lt, .55, .85));
        }
      } else if (tt < .815) {                        /* ch5 -> ch6 travel */
        diePose(1); setPress(1); calPose(0); setScribe(1, 1, 1);
        landPose(1); setStamp(1, 1, 1);
        drawPose(0, ''); setStory(1, 1, 1, 1, 1, 1, 1);
        lampPose(1); setLight(1, 1);
        setHandover(0);
        camTravel6(seg(tt, .68, .815));
      } else {                                       /* ch6: the handover + final lock */
        diePose(1); setPress(1); calPose(0); setScribe(1, 1, 1);
        landPose(1); setStamp(1, 1, 1);
        drawPose(0, ''); setStory(1, 1, 1, 1, 1, 1, 1);
        lampPose(1); setLight(1, 1);
        camSheet7Lock();
        setHandover(seg(tt, .815, .94));
      }
    }
    renderer.render(scene, camera);
  }
  tick();
  window.__setProgress = p => { scrollT = scrollC = clamp01(p); };
})();
