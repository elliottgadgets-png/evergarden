import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='draw1.blend')
sc=bpy.context.scene
sc.frame_start=0; sc.frame_end=71
sc.render.fps=24

# ---- 1. unhide the world ----
for ob in bpy.data.objects:
    ob.hide_render=False

# ---- 2. freeze animations: strokes finished, pencil at rest, frames re-dressed ----
for ob in bpy.data.objects:
    if ob.name.startswith('stroke'):
        if ob.animation_data: ob.animation_data_clear()
        ob.data.bevel_factor_end=1.0
pr=bpy.data.objects['pencil_root']
if pr.animation_data: pr.animation_data_clear()
pr.location=(0.27,-0.096,0.0334); pr.rotation_euler=(0.0,1.5359,0.1396)
# camera anim clear (new move below)
cam=bpy.data.objects['Camera']
if cam.animation_data: cam.animation_data_clear()
# frames: clear anim, stand in back-left row facing camera
fpos={'frame1':(-0.16,0.52,0.03),'frame2':(-0.02,0.52,0.03),'frame3':(0.12,0.52,0.03)}
for name,p in fpos.items():
    e=bpy.data.objects[name]
    if e.animation_data: e.animation_data_clear()
    e.location=p; e.rotation_euler=(0,0,0)
# caliper: leave at its CH2 home (around x -0.05..0, y 0) - static
for name in ('cal_beam','cal_jaw_fixed','cal_jaw_slide','cal_slider','cal_rod','cal_thumbwheel','cal_disp','cal_lcd'):
    ob=bpy.data.objects.get(name)
    if ob and ob.animation_data: ob.animation_data_clear()

# ---- 3. banker lamp ----
def mat_principled(name,color,metallic=0.0,rough=0.4,emit=None,estr=0.0):
    m=bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF')
    bs.inputs['Base Color'].default_value=(*color,1)
    bs.inputs['Metallic'].default_value=metallic
    bs.inputs['Roughness'].default_value=rough
    if emit:
        bs.inputs['Emission Color'].default_value=(*emit,1)
        bs.inputs['Emission Strength'].default_value=estr
    return m
brass=mat_principled('lamp_brass',(0.30,0.20,0.07),metallic=0.85,rough=0.45)
green=mat_principled('lamp_green',(0.015,0.22,0.08),metallic=0.1,rough=0.3,emit=(0.05,0.5,0.16),estr=0.0)
LX,LY=-0.30,0.44   # base position on bench (bench top z~0.03)
BZ=0.03
# base
bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=0.048,depth=0.014,location=(LX,LY,BZ+0.007))
base=bpy.context.object; base.name='lamp_base'; base.data.materials.append(brass)
bpy.ops.object.shade_smooth()
bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=0.030,depth=0.010,location=(LX,LY,BZ+0.019))
b2=bpy.context.object; b2.name='lamp_base2'; b2.data.materials.append(brass); bpy.ops.object.shade_smooth()
# stem: curve from base up and arcing forward
cu=bpy.data.curves.new('lamp_stem_cu','CURVE'); cu.dimensions='3D'; cu.bevel_depth=0.0055; cu.bevel_resolution=3
sp=cu.splines.new('BEZIER'); sp.bezier_points.add(2)
pts=[(LX,LY,BZ+0.02),(LX,LY,BZ+0.135),(LX,LY-0.075,BZ+0.150)]
for bp,co in zip(sp.bezier_points,pts):
    bp.co=co; bp.handle_left_type='AUTO'; bp.handle_right_type='AUTO'
stem=bpy.data.objects.new('lamp_stem',cu); bpy.context.collection.objects.link(stem)
stembrass=mat_principled('lamp_stembrass',(0.17,0.11,0.032),metallic=0.4,rough=0.72)
stem.data.materials.append(stembrass)
SHC=Vector((LX,LY-0.075,BZ+0.150))  # shade center
# shade: half-cylinder shell, axis x, opening down
import bmesh
L=0.17; R=0.048; NR=10; NA=16
verts=[]; faces=[]
for i in range(NR+1):
    x=-L/2+L*i/NR
    for j in range(NA+1):
        a=math.pi*j/NA  # upper half
        verts.append((x, R*math.cos(a), R*math.sin(a)))
for i in range(NR):
    for j in range(NA):
        a=i*(NA+1)+j; faces.append((a,a+1,a+NA+2,a+NA+1))
me=bpy.data.meshes.new('lamp_shade_me'); me.from_pydata(verts,[],faces); me.update()
shade=bpy.data.objects.new('lamp_shade',me); bpy.context.collection.objects.link(shade)
shade.location=SHC; shade.data.materials.append(green)
sol=shade.modifiers.new('sol','SOLIDIFY'); sol.thickness=0.0025
for p in me.polygons: p.use_smooth=True
# bulb
bpy.ops.mesh.primitive_uv_sphere_add(segments=24,radius=0.016,location=SHC+Vector((0,0,-0.012)))
bulb=bpy.context.object; bulb.name='lamp_bulb'
bm=mat_principled('lamp_bulbmat',(1,0.8,0.5),rough=0.3,emit=(1.0,0.62,0.28),estr=0.0)
bulb.data.materials.append(bm)
# pull chain: beads hanging from shade right end
bpy.ops.object.empty_add(type='PLAIN_AXES',location=SHC+Vector((L/2-0.01,-R*0.55,R*0.2)))
chroot=bpy.context.object; chroot.name='lamp_chain_root'
beadmat=brass
prev=None
for i in range(9):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12,radius=0.0021,location=(0,0,-0.006*(i+1)))
    bd=bpy.context.object; bd.name='lamp_bead%d'%i; bd.data.materials.append(beadmat); bd.parent=chroot
bpy.ops.mesh.primitive_uv_sphere_add(segments=16,radius=0.005,location=(0,0,-0.060))
pull=bpy.context.object; pull.name='lamp_pull'; pull.data.materials.append(brass); pull.parent=chroot
# lamp light
lt=bpy.data.lights.new('lamp_glow','POINT'); lt.energy=0.0; lt.color=(1.0,0.58,0.26); lt.shadow_soft_size=0.06
lo=bpy.data.objects.new('lamp_glow',lt); bpy.context.collection.objects.link(lo); lo.location=SHC+Vector((0,0,-0.05))
lt2=bpy.data.lights.new('lamp_pool','AREA'); lt2.energy=0.0; lt2.color=(1.0,0.66,0.34); lt2.shape='DISK'; lt2.size=0.16
lo2=bpy.data.objects.new('lamp_pool',lt2); bpy.context.collection.objects.link(lo2)
lo2.location=SHC+Vector((0,-0.06,-0.10)); lo2.rotation_euler=(0,0,0)

# ---- 4. lighting states + animation ----
def energy_key(name,pairs):
    ob=bpy.data.objects[name]
    for f,e in pairs:
        ob.data.energy=e; ob.data.keyframe_insert('energy',frame=f)
    for fc in ob.data.animation_data.action.fcurves:
        for k in fc.keyframe_points: k.interpolation='LINEAR'
# dim start (f0), lamp clicks on f20 (ramp f19-21), gentle warm takeover
energy_key('key',[(0,0.0),(19,0.0),(23,1.2),(71,1.2)])
energy_key('fill',[(0,0.0),(19,0.0),(23,0.3),(71,0.3)])
energy_key('top',[(0,0.0),(19,0.0),(23,0.5),(71,0.5)])
energy_key('practical',[(0,0.0),(19,0.0),(23,0.3),(71,0.35)])
energy_key('rim',[(0,2.0),(71,2.0)])
ww=bpy.data.objects['wallwash']; ww.location=(-0.38,0.85,0.35)
energy_key('wallwash',[(0,4.0),(19,4.0),(21,22.0),(71,24.0)])
energy_key('lamp_glow',[(0,0.0),(19,0.0),(21,2.0),(71,2.2)])
energy_key('lamp_pool',[(0,0.0),(19,0.0),(21,18.0),(71,20.0)])
# shade + bulb emission on
def emit_key(mat,pairs):
    bs=mat.node_tree.nodes.get('Principled BSDF')
    for f,s in pairs:
        bs.inputs['Emission Strength'].default_value=s
        bs.inputs['Emission Strength'].keyframe_insert('default_value',frame=f)
    for fc in mat.node_tree.animation_data.action.fcurves:
        for k in fc.keyframe_points: k.interpolation='LINEAR'
emit_key(green,[(0,0.0),(19,0.0),(21,0.6),(71,0.65)])
emit_key(bm,[(0,0.0),(19,0.0),(21,4.0),(71,4.0)])
# chain pull: swing f14-36 damped pendulum, starts the click
for f,ang in [(0,0.0),(14,0.0),(17,0.38),(21,-0.30),(25,0.20),(29,-0.12),(33,0.06),(37,-0.02),(41,0.0),(71,0.0)]:
    chroot.rotation_euler=(ang,0,ang*0.4); chroot.keyframe_insert('rotation_euler',frame=f)
for fc in chroot.animation_data.action.fcurves:
    for k in fc.keyframe_points: k.interpolation='BEZIER'

# dim the CH1 background glow panel for the off register
bg=bpy.data.objects.get('bg_glow')
if bg:
    for slot in bg.material_slots:
        m=slot.material
        if m and m.use_nodes:
            bs=m.node_tree.nodes.get('Principled BSDF')
            if bs: bs.inputs['Emission Strength'].default_value=0.15
sc.world.color=(0.03,0.03,0.03)
# world background strength via nodes
if sc.world and sc.world.use_nodes:
    for nd in sc.world.node_tree.nodes:
        if nd.type=='BACKGROUND':
            nd.inputs['Color'].default_value=(0.03,0.03,0.03,1)

# ---- 5. camera: wide front, slow push after the click ----
tgt=bpy.data.objects.get('focus')
if tgt.animation_data: tgt.animation_data_clear()
tgt.location=(0.20,0.22,0.05)
# remove old constraints, add track-to
for c in list(cam.constraints): cam.constraints.remove(c)
ct=cam.constraints.new('TRACK_TO'); ct.target=tgt; ct.track_axis='TRACK_NEGATIVE_Z'; ct.up_axis='UP_Y'
cam.data.lens=48
cam.data.dof.aperture_fstop=6.3
for f,loc,tloc in [(0,(-0.10,-0.40,0.27),(-0.24,0.30,0.07)),
                   (20,(-0.10,-0.40,0.27),(-0.24,0.30,0.07)),
                   (71,(-0.11,-0.35,0.25),(-0.25,0.33,0.075))]:
    cam.location=loc; cam.keyframe_insert('location',frame=f)
    tgt.location=tloc; tgt.keyframe_insert('location',frame=f)
for ob in (cam,tgt):
    for fc in ob.animation_data.action.fcurves:
        for k in fc.keyframe_points: k.interpolation='LINEAR'
bpy.ops.wm.save_mainfile(filepath='lamp1.blend')
print('SAVED lamp1.blend')
