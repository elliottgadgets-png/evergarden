import bpy, math
from mathutils import Vector, Euler
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/press_final4.blend")
sc=bpy.context.scene
press_names=["base","colL","colR","bridge","inkdisk","inkface","bed","die","platen_hinge","handle_pivot","flywheel","flyhub","bolt","bolt.001","bolt.002","bolt.003","bolt.004","bolt.005","crank","con_rod","die_relief"]
for n in press_names:
    o=bpy.data.objects.get(n)
    if o:
        o.animation_data_clear()
        o.location.x += 0.42; o.location.y += 0.22   # park press back-right on bench
# remove chapter-1-specific things
for n in ["sheet","sheet_stamped","rake","rake_target","sheet_fill","set_sep"]:
    o=bpy.data.objects.get(n)
    if o: bpy.data.objects.remove(o, do_unlink=True)
cam=bpy.data.objects["Camera"]; cam.animation_data_clear()
foc=bpy.data.objects["focus"]; foc.animation_data_clear()

def mat_principled(name, color, metallic=0.0, rough=0.5):
    m=bpy.data.materials.new(name); m.use_nodes=True
    b=m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value=(*color,1)
    b.inputs["Metallic"].default_value=metallic
    b.inputs["Roughness"].default_value=rough
    return m
steel=mat_principled("caliper_steel",(0.62,0.64,0.66),0.95,0.28)
steel.inputs if False else None
black=mat_principled("caliper_black",(0.02,0.02,0.022),0.1,0.4)
glassm=mat_principled("slab_glass",(0.015,0.02,0.018),0.4,0.12)
bglass=glassm.node_tree.nodes["Principled BSDF"]; bglass.inputs["Coat Weight"].default_value=0.6
lcdm=mat_principled("lcd",(0.05,0.09,0.07),0.0,0.35)
# lcd texture
img=bpy.data.images.load("/home/sandbox/evergarden-cine/lcd.png")
nt=lcdm.node_tree; tex=nt.nodes.new("ShaderNodeTexImage"); tex.image=img
em=nt.nodes.new("ShaderNodeEmission"); nt.links.new(tex.outputs["Color"], em.inputs["Color"]); em.inputs["Strength"].default_value=1.6
out=nt.nodes["Material Output"]; nt.links.new(em.outputs[0], out.inputs["Surface"])

def box(name, loc, scale, mat, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    o=bpy.context.object; o.name=name
    o.scale=(scale[0]/2, scale[1]/2, scale[2]/2)
    bpy.ops.object.transform_apply(scale=True)
    if mat: o.data.materials.append(mat)
    if bevel>0:
        mod=o.modifiers.new("bev","BEVEL"); mod.width=bevel; mod.segments=2
    return o

z0=0.0335
# main beam along X
box("cal_beam",(0.0,0.0,z0+0.002),(0.17,0.02,0.004),steel,0.0006)
# jaw depth (upright part height)
jh=0.032
# fixed jaw at left end
box("cal_jaw_fixed",(-0.082,0.0,z0+jh/2),(0.005,0.02,jh),steel,0.0006)
box("cal_tip_fixed",(-0.0775,0.0,z0+jh-0.003),(0.006,0.016,0.006),steel,0.0005)  # tip extends +x
# slider assembly (animated in X)
sx0=-0.030  # open
sl=box("cal_slider",(sx0,0.0,z0+0.004),(0.028,0.024,0.009),black,0.0012)
box("cal_jaw_slide",(sx0-0.012,0.0,z0+jh/2),(0.005,0.02,jh),steel,0.0006).parent=sl
tip=box("cal_tip_slide",(sx0-0.0065,0.0,z0+jh-0.003),(0.006,0.016,0.006),steel,0.0005); tip.parent=sl
# display housing + LCD on slider
box("cal_disp",(sx0+0.004,-0.002,z0+0.010),(0.020,0.018,0.006),black,0.001).parent=sl
lcd=box("cal_lcd",(sx0+0.004,-0.002,z0+0.0132),(0.016,0.012,0.0006),lcdm,0.0003); lcd.parent=sl
# thumbwheel
bpy.ops.mesh.primitive_cylinder_add(radius=0.006, depth=0.006, location=(sx0+0.016,0.010,z0+0.006), rotation=(math.pi/2,0,0))
tw=bpy.context.object; tw.name="cal_thumbwheel"; tw.data.materials.append(steel); tw.parent=sl
# depth rod at right end
box("cal_rod",(0.095,0.0,z0+0.002),(0.02,0.003,0.002),steel,0.0004)
# measured slab lying flat, left of beam, between jaw tips (its right edge at -0.066)
slab=box("slab",(-0.081,-0.05,z0+0.0025),(0.05,0.034,0.005),glassm,0.001)
# parent slider children keep world pos
bpy.context.view_layer.update()
for ch in sl.children: ch.matrix_parent_inverse = sl.matrix_world.inverted()
# slider animation: open f0-20, glide to contact f45, settle f50
sl.keyframe_insert("location", frame=0)
sl.keyframe_insert("location", frame=20)
# contact: tip face at slab right edge: tip left face = sx-0.0095 ; slab right edge at -0.056 -> sx_contact = -0.0465
sl.location.x = -0.0465+0.030+sx0 - sx0  # compute delta
sl.location.x = sx0 + (-0.056 - (sx0-0.0095))
sl.keyframe_insert("location", frame=45)
sl.keyframe_insert("location", frame=71)
# camera: macro 3/4 from front-right, low
cam.data.lens=60
def camkey(f, loc, tgt):
    cam.location=loc
    d=(Vector(tgt)-Vector(loc)); cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
    cam.keyframe_insert("location", frame=f); cam.keyframe_insert("rotation_euler", frame=f)
    foc.location=tgt; foc.keyframe_insert("location", frame=f)
camkey(0,(0.05,-0.26,0.13),(-0.045,-0.01,0.045))
camkey(45,(0.02,-0.22,0.11),(-0.055,-0.01,0.05))
camkey(71,(-0.02,-0.20,0.12),(-0.055,-0.01,0.048))
# lights: reuse key/rim/fill/top/practical; aim key at caliper area? key likely static area light over press - move key target area slightly left
key=bpy.data.objects.get("key")
if key: key.location=(-0.05,-0.12,0.35)
sc.frame_start=0; sc.frame_end=71
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
print("SAVED")
