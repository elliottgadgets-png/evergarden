import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
sc=bpy.context.scene
# delete tip boxes
for n in ["cal_tip_fixed","cal_tip_slide"]:
    o=bpy.data.objects.get(n)
    if o: bpy.data.objects.remove(o, do_unlink=True)
# slab between jaw faces: fixed jaw right face at -0.0795
slab=bpy.data.objects["slab"]
slab.dimensions=(0.005,0.034,0.05)
bpy.context.view_layer.update()
slab.location=(-0.077, 0.0, 0.0335+0.025)
slab.rotation_euler=(0,0,math.radians(2))
# slab material: dim glowing screen
m=bpy.data.materials["slab_glass"]; nt=m.node_tree
b=nt.nodes["Principled BSDF"]
b.inputs["Base Color"].default_value=(0.02,0.05,0.042,1)
b.inputs["Roughness"].default_value=0.1
b.inputs["Emission Color"].default_value=(0.03,0.16,0.12,1)
b.inputs["Emission Strength"].default_value=1.2
# slider contact stays -0.060 (jaw left face sx-0.0145 = -0.0745 = slab right face)
# camera reframe (aim further left, slightly further back)
cam=bpy.data.objects["Camera"]; foc=bpy.data.objects["focus"]
cam.animation_data_clear(); foc.animation_data_clear()
def camkey(f, loc, tgt):
    cam.location=loc
    d=(Vector(tgt)-Vector(loc)); cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
    cam.keyframe_insert("location", frame=f); cam.keyframe_insert("rotation_euler", frame=f)
    foc.location=tgt; foc.keyframe_insert("location", frame=f)
camkey(0,(0.09,-0.24,0.125),(-0.062,0,0.05))
camkey(45,(-0.005,-0.22,0.11),(-0.072,0,0.055))
camkey(71,(-0.045,-0.19,0.10),(-0.066,-0.002,0.050))
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
print("SAVED")
