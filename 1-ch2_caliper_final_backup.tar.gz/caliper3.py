import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
sc=bpy.context.scene
slab=bpy.data.objects["slab"]
slab.location=(-0.0665,0.0,0.0335+0.0025)
slab.scale=(0.008,0.017,0.0025)  # cube already applied 1m -> but we applied transform; set dimensions directly
slab.dimensions=(0.016,0.034,0.005)
bpy.context.view_layer.update()
sl=bpy.data.objects["cal_slider"]
sl.location.x=-0.049
sl.keyframe_insert("location", frame=45)
sl.keyframe_insert("location", frame=71)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
print("SAVED", slab.dimensions[:])
