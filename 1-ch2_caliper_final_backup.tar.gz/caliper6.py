import bpy
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
sc=bpy.context.scene
sc.render.resolution_x=390; sc.render.resolution_y=844; sc.render.resolution_percentage=100
# steel tone-down (blown white under key)
m=bpy.data.materials["caliper_steel"]; b=m.node_tree.nodes["Principled BSDF"]
b.inputs["Base Color"].default_value=(0.30,0.32,0.34,1); b.inputs["Roughness"].default_value=0.36
# slab: smaller, darker glass
slab=bpy.data.objects["slab"]
slab.dimensions=(0.005,0.024,0.036)
bpy.context.view_layer.update()
slab.location=(-0.077,0.0,0.0335+0.018)
g=bpy.data.materials["slab_glass"].node_tree.nodes["Principled BSDF"]
g.inputs["Base Color"].default_value=(0.012,0.03,0.026,1)
g.inputs["Emission Strength"].default_value=0.7
# thumbwheel smaller + darker already black; shrink
tw=bpy.data.objects["cal_thumbwheel"]; tw.scale=(0.7,0.7,0.7)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
print("SAVED")
