import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
sc=bpy.context.scene
slab=bpy.data.objects["slab"]
slab.dimensions=(0.005,0.034,0.05)
bpy.context.view_layer.update()
slab.location=(-0.072, 0.0, 0.0335+0.025)
slab.rotation_euler=(0,0,math.radians(2))
sl=bpy.data.objects["cal_slider"]
sl.animation_data_clear()
sl.location.x=-0.030
sl.keyframe_insert("location", frame=0)
sl.keyframe_insert("location", frame=20)
sl.location.x=-0.060
sl.keyframe_insert("location", frame=45)
sl.keyframe_insert("location", frame=71)
cam=bpy.data.objects["Camera"]; foc=bpy.data.objects["focus"]
cam.animation_data_clear(); foc.animation_data_clear()
def camkey(f, loc, tgt):
    cam.location=loc
    d=(Vector(tgt)-Vector(loc)); cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
    cam.keyframe_insert("location", frame=f); cam.keyframe_insert("rotation_euler", frame=f)
    foc.location=tgt; foc.keyframe_insert("location", frame=f)
camkey(0,(0.07,-0.20,0.11),(-0.05,0,0.05))
camkey(45,(-0.005,-0.19,0.10),(-0.066,0,0.056))
camkey(71,(-0.03,-0.17,0.095),(-0.052,-0.004,0.050))
img=bpy.data.images["lcd.png"]; img.reload()
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
print("SAVED")
