import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
sc=bpy.context.scene; z0=0.0335
# --- slab: rotate so glowing face catches camera ---
slab=bpy.data.objects["slab"]
slab.location=(-0.068,0.0,z0+0.004+0.018)
slab.rotation_euler=(0,0,math.radians(60))
g=bpy.data.materials["slab_glass"].node_tree.nodes["Principled BSDF"]
g.inputs["Emission Color"].default_value=(0.10,0.50,0.44,1)
g.inputs["Emission Strength"].default_value=2.0
g.inputs["Base Color"].default_value=(0.010,0.026,0.022,1)
# --- slider contact keys: right edge of rotated slab ~ -0.0564, tip face sx-0.0095 ---
sl=bpy.data.objects["cal_slider"]
for fc in sl.animation_data.action.fcurves:
    if fc.data_path=="location" and fc.array_index==0:
        for kp in fc.keyframe_points:
            if kp.co.x in (45.0,71.0): kp.co.y=-0.0469; kp.handle_left.y=-0.0469; kp.handle_right.y=-0.0469
# --- display + LCD tilt toward camera ---
disp=bpy.data.objects["cal_disp"]; lcd=bpy.data.objects["cal_lcd"]
sx=sl.location.x  # current (whatever frame) - use key at 0: read fcurve
for fc in sl.animation_data.action.fcurves:
    if fc.data_path=="location" and fc.array_index==0:
        sx=[kp.co.y for kp in fc.keyframe_points if kp.co.x==0.0][0]
disp.rotation_euler=(-0.4,0,0)
lcd.rotation_euler=(-0.4,0,0)
lcd.location=(sx+0.004,-0.002+0.00128,z0+0.010+0.00304)
# --- LCD texture: 0.00 -> 5.00 swap at contact (f45) ---
lcdm=bpy.data.materials["lcd"]; nt=lcdm.node_tree
tex=[n for n in nt.nodes if n.type=='TEX_IMAGE'][0]
tex.image=bpy.data.images.load("/home/sandbox/evergarden-cine/lcd2.png")
mp=nt.nodes.new("ShaderNodeMapping"); tc=nt.nodes.new("ShaderNodeTexCoord")
mp.inputs["Scale"].default_value=(0.5,1,1)
nt.links.new(tc.outputs["Generated"],mp.inputs["Vector"]); nt.links.new(mp.outputs["Vector"],tex.inputs["Vector"])
mp.inputs["Location"].default_value=(0,0,0)
mp.inputs["Location"].keyframe_insert("default_value",frame=0)
mp.inputs["Location"].keyframe_insert("default_value",frame=44)
mp.inputs["Location"].default_value=(0.5,0,0)
mp.inputs["Location"].keyframe_insert("default_value",frame=45)
mp.inputs["Location"].keyframe_insert("default_value",frame=71)
for fc in nt.animation_data.action.fcurves:
    for kp in fc.keyframe_points: kp.interpolation='CONSTANT'
# --- camera reframe ---
cam=bpy.data.objects["Camera"]; foc=bpy.data.objects.get("cam_focus") or None
cam.animation_data_clear()
if foc: foc.animation_data_clear()
def camkey(f, loc, tgt):
    cam.location=loc
    d=(Vector(tgt)-Vector(loc)); cam.rotation_euler=d.to_track_quat('-Z','Y').to_euler()
    cam.keyframe_insert("location", frame=f); cam.keyframe_insert("rotation_euler", frame=f)
    if foc: foc.location=tgt; foc.keyframe_insert("location", frame=f)
camkey(0,(0.05,-0.27,0.15),(-0.05,-0.005,0.05))
camkey(45,(0.0,-0.24,0.14),(-0.058,-0.005,0.052))
camkey(71,(-0.015,-0.235,0.14),(-0.062,-0.005,0.052))
sc.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath="/home/sandbox/evergarden-cine/caliper1.blend")
print("SAVED sx0=",sx)
